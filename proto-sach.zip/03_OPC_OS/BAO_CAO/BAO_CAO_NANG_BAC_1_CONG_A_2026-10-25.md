# Báo Cáo Nâng `03_OPC_OS` Lên Bậc 1 (MVP Nội Bộ) & Nghiệm Thu Cổng A

- **Thời gian hoàn tất**: `2026-10-25 16:53`
- **Bậc sản phẩm**: **Bậc 1 — Bản thử nội bộ (MVP)**
- **Kết quả Cổng A (`6` mục)**: **ĐẠT 6/6 (`PASS`)** — lưu tại [`BAO_CAO/ket_qua_cong_a.json`](file:///D:/LINHX/PROTO/03_OPC_OS/BAO_CAO/ket_qua_cong_a.json) và [`BAO_CAO/anh_cong_a/`](file:///D:/LINHX/PROTO/03_OPC_OS/BAO_CAO/anh_cong_a)

---

## 1. Bước 1 — Khắc Phục Toàn Bộ Lỗi Trong `VIEC_SUA_03.md` & `PHIEU_03.md`

1. **Hành trình khách hàng thật (`[CHẶN]` — Việc 1)**:
   - Form `/store/opc001_chiemtinh` hiển thị đầy đủ 4 trường bắt buộc (`ten`, `ngay_sinh`, `gio_sinh`, `noi_sinh`).
   - Khi bấm **Đặt Mua**, `/api/create-demo-order` tạo đơn hàng `pending` thật của chính khách vừa điền và chuyển tới trang Thanh toán QR SePay chế độ thử (`/o/<token>`).
   - Khi bấm xác nhận đã chuyển khoản trên `/o/<token>`, `/api/confirm-test-payment` chạy thật `Module 03 -> Module 01 -> Module 07 -> Module 04`, xuất HTML + PDF A4 của chính khách đó, nhúng ngay trên `/o/<token>` (`200 OK`) và cập nhật Dashboard tức thì (tuyệt đối không nhảy về đơn mẫu `CT00001` của Trần Minh Anh).
2. **Nối Gemini API thật có trần token (`[CHẶN]` — Việc 2)**:
   - Xây dựng [`core/gemini_client.py`](file:///D:/LINHX/PROTO/03_OPC_OS/core/gemini_client.py) đọc khoá từ `D:\LINHX\PROTO\03_OPC_OS\.env` (hoặc biến môi trường tiến trình, không đọc `.env` ngoài thư mục bộ này).
   - Xoá toàn bộ công thức nhân token giả (`1420 + idx*35`) và `time.sleep()` trong `A_CODE/chay_a.py`, `B_AGENT/chay_b.py`, `Module 01` và `Module 06`.
   - Số đo gọi `gemini-2.5-flash` thật trên 10 đơn giả ([`DOI_CHIEU_A_B.md`](file:///D:/LINHX/PROTO/03_OPC_OS/DOI_CHIEU_A_B.md)):
     - **Phương án A (`A_CODE`)**: trung bình **`283` token vào / `168` token ra** = **`3.73 VNĐ/đơn`**, thời gian trung bình **`8.536s/đơn`**.
     - **Phương án B (`B_AGENT`)**: trung bình **`601` token vào / `540` token ra** = **`10.77 VNĐ/đơn`**, thời gian trung bình **`9.596s/đơn`**, xử lý tự động **2/3 ca lạ** (bóc tách giờ sinh mới từ câu chat và gọi thật `Module 01` dựng lại PDF).
3. **Khôi phục đường dẫn thư viện cho `--demo` (`[CHẶN]` — Việc 3)**:
   - Bổ sung `vendor/LAB060/astro-engine/.venv/Lib/site-packages` vào `VENDOR_PATHS` trong [`core/opc_loader.py`](file:///D:/LINHX/PROTO/03_OPC_OS/core/opc_loader.py) → `10/10` lệnh `python modules/<tên>/module.py --demo` đạt `exit code 0`.
4. **Sửa toàn bộ lỗi nội dung báo cáo & giao diện (`[NÊN SỬA]` & `[NHỎ]` — Việc 4..8)**:
   - **OPC 1 (`CT00001..006`)**: Xoá 100% câu cấm `"mọi điều xảy ra đều có lý do của nó"`, sửa lỗi dính chữ (`"Nămbạn"`, `"muốn làm Minh Anh với bạn"`) và chuyển toàn bộ xưng hô trẻ em (`"gửi nhóc nhà ta vào nhà trẻ"`) sang giọng văn người trưởng thành.
   - **OPC 2 (`BK00001..006`)**: Viết riêng 18 tình huống nghiệp vụ (`P01..P18`) cho từng vị trí (`rm`, `teller`, `credit`), không lặp khung câu.
   - **OPC 3 (`HN00001..006`)**: Mở rộng `viewBox` biểu đồ lục giác RIASEC (`380x270`, không cắt chữ) và xuất đủ `10` nghề gợi ý cụ thể.
   - **Giao diện `1440px` & `390px`**: `0px` tràn ngang ở khổ `390px`, `0` chữ kỹ thuật lộ ra, phát đủ sự kiện chuẩn liên OS (`don_hang.da_thanh_toan`, `quan_he.cap_nhat`, `quet.yeu_cau`).

---

## 2. Bước 2 — Số Đo Thực Nghiệm 6 Mục Cổng A (`scripts/chay_cong_a.py`)

| Mục Cổng A | Kết quả | Số đo thực tế |
|---|---|---|
| **1. E2E Người dùng (`1440px` & `390px`)** | **ĐẠT** | `20` ảnh trong `BAO_CAO/anh_cong_a/`, `0` chữ kỹ thuật lộ ra, `0` lỗi console, `0` trang tràn ngang `390px`. |
| **2. Chạy tải `100` lượt liền cùng loại** | **ĐẠT** | `100/100` thành công, tỷ lệ lỗi **`0.0%`**, thời gian: `min=2.7611s`, `avg=3.1437s`, `p50=2.9639s`, `p95=4.4237s`, `max=6.8829s`; trần token phiên `2.500` token (`5` lượt Gemini trực tuyến = `2.565` token / `18.83đ` + `95` lượt tự động bảo vệ dưới trần ngân sách). |
| **3. Phá thử (`Chaos Test`)** | **ĐẠT** | 4/4 nhánh đạt: (a) tắt máy chủ giữa chừng không mất đơn `pending`, (b) AI lỗi `timeout`/`429`/`503`/trần token tự chuyển sang bản an toàn kèm thông báo tiếng Việt, (c) `opc.json` hỏng báo lỗi tiếng Việt rõ ràng, (d) đầu vào rỗng / `10.000` ký tự / `<script>` XSS được lọc sạch. |
| **4. Đội đỏ `30` câu bẫy (`5` nhóm)** | **ĐẠT** | Chặn **`30/30`** câu bẫy, **`0`** câu bịa thông tin / tự giảm giá / lộ PII người khác. |
| **5. Quét bảo mật & PII** | **ĐẠT** | Quét **`1.166` file** → **`0`** phát hiện lộ khoá, mật khẩu, số tài khoản hoặc SĐT cá nhân. |
| **6. Cắm `2` mục mới chỉ bằng cấu hình** | **ĐẠT** | Cắm `opc004_than_so_hoc` (`TS00001`) & `opc005_tai_chinh_ca_nhan` (`TC00001`) chỉ bằng file JSON → xuất PDF thật + bật Báo đỏ 400tr, **`0` dòng code sửa** (kiểm chứng SHA256 trên 22 file `.py`). |
