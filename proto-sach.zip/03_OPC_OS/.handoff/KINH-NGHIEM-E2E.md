# Kinh Nghiệm Thực Chiến Kiểm Thử E2E 3 Vòng (`KINH-NGHIEM-E2E.md`)

> **Dự án**: `03_OPC_OS` · **Checkpoint**: [`.handoff/e2e-checkpoint.json`](file:///D:/LINHX/PROTO/03_OPC_OS/.handoff/e2e-checkpoint.json) (`Round 1: 5.00` → `Round 2: 9.10` → `Round 3: 9.65/10.0`)

---

## 1. Bẫy `<embed type="application/pdf">` Hiện Hộp Đen `"Couldn't load plugin."` Trên Trình Duyệt Không Bật PDF Viewer
- **Hiện tượng (Phát hiện ở ảnh chụp `round1/07_order_bk00001.png`)**: Dù file `.pdf` tồn tại thật trên đĩa và thẻ `<embed src="...pdf" type="application/pdf">` đúng cú pháp HTML, khi mở trên Chromium headless (hoặc trình duyệt in-app Zalo/Facebook trên điện thoại), trình duyệt không có plugin PDF nên hiển thị một khung màu đen chữ `"Couldn't load plugin."`.
- **Cách giải quyết chuẩn**: Kết hợp hiển thị trực tiếp bản `bao-cao.html` trong `<iframe title="Nội dung báo cáo trực tiếp">` ngay trong hộp `.pdf-viewer-box` kèm nút **📥 Tải PDF chuẩn A4 về máy** (`bao-cao.pdf`) và **📦 Tải trọn bộ Công cụ (.ZIP)**. Cách này giúp khách hàng đọc được toàn bộ báo cáo ngay trên mọi thiết bị mà không phụ thuộc PDF plugin của trình duyệt.

## 2. Bẫy Tiêm Thanh Điều Hướng Toàn Cục Vào Trang Con Có `body { max-width: 860px }`
- **Hiện tượng (Phát hiện ở ảnh chụp `round1/07_order_bk00001.png`)**: Khi `order_*.html` đặt `max-width: 860px` trực tiếp trên thẻ `<body>`, việc tiêm `<nav data-role="top-nav">` vào đầu `<body>` khiến thanh điều hướng bị bóp hẹp theo `860px` và gãy thành 3 dòng.
- **Cách giải quyết chuẩn**: Luôn giữ `body { margin: 0; padding: 0; }` toàn chiều rộng `100%`, và đặt `max-width` vào thẻ `<main id="main-content" class="order-shell" role="main">`.

## 3. Tách CSS `@media screen` Và `@media print` Khi Dùng Chung `bao-cao.html` Cho Cả Xem Trực Tiếp Lẫn Kết Xuất PDF A4
- **Hiện tượng (Phát hiện ở ảnh chụp `round2/08_order_hn00001.png`)**: Để in ra đúng 13 trang PDF A4 bằng `@page { size: A4; margin: 16mm; }`, file `bao-cao.html` đặt `body { margin: 0; }`. Nhưng khi nhúng `bao-cao.html` vào `iframe` trên màn hình web, chữ bị dính sát vào mép trái/phải của khung viền.
- **Cách giải quyết chuẩn**: Thêm `@media screen { body { padding: 18px 24px; } }`. Khi xem trên web có lề 24px thoáng đẹp; khi Playwright xuất PDF (`print` media), trình duyệt tự dùng lề `@page { margin: 16mm }` và giữ nguyên chính xác **13 trang A4**.
