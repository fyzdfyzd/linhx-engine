# BỘ 18 PROMPT AI CÁ NHÂN HOÁ DÀNH RIÊNG CHO PHAN THANH SƠN (CHUYÊN VIÊN THẨM ĐỊNH TÍN DỤNG DOANH NGHIỆP)
> **Nhãn**: `[GIẢ LẬP]` · **Vị trí**: Chuyên viên Thẩm định Tín dụng Doanh nghiệp · **Nghiệp vụ chính**: Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay · **Công cụ AI**: Claude Pro
> **3 việc tốn giờ nhất đã cá nhân hoá**: (1) Rà soát thuyết minh báo cáo tài chính và khoản phải thu · (2) Lập tờ trình thẩm định hạn mức tín dụng ngắn hạn · (3) Kiểm tra chứng từ giải ngân và mục đích sử dụng vốn

## P01 · Thiết kế bảng kiểm 5 bước & điểm chặn sai sót cho «Rà soát thuyết minh báo cáo tài chính và khoản phải thu»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Rà soát thuyết minh báo cáo tài chính và khoản phải thu
```text
Đóng vai Chuyên gia Kiểm soát Chất lượng mảng Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay, hãy giúp tôi chuẩn hoá công việc «Rà soát thuyết minh báo cáo tài chính và khoản phải thu» của vị trí Chuyên viên Thẩm định Tín dụng Doanh nghiệp trên Claude Pro:
1. Tách quy trình thực hiện thành 5 bước tuần tự kèm thời gian định mức (SLA) cho từng bước.
2. Xác định 3 lỗi sai số liệu hoặc thiếu chứng từ thường gặp nhất ở khâu «Rà soát thuyết minh báo cáo tài chính và khoản phải thu» và cách chặn từ đầu.
3. Thiết kế 1 bảng kiểm đối chiếu nhanh (Maker-Checker) trước khi chuyển hồ sơ sang bộ phận tiếp theo (chỉ dùng dữ liệu ẩn danh [GIẢ LẬP]).
```

## P02 · Soạn thảo văn bản & thông điệp chuẩn mực cho «Rà soát thuyết minh báo cáo tài chính và khoản phải thu»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Rà soát thuyết minh báo cáo tài chính và khoản phải thu
```text
Trên công cụ Claude Pro, từ dữ kiện nghiệp vụ đã che tên thật và số tài khoản dưới đây về việc «Rà soát thuyết minh báo cáo tài chính và khoản phải thu» (Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay):
1. Soạn 1 bản văn bản hành chính ngân hàng ngắn gọn (nêu rõ mục đích, danh mục hồ sơ đính kèm, thời hạn phản hồi).
2. Viết thêm 1 phiên bản tóm tắt 4 dòng để báo cáo nhanh qua nhóm điều phối nội bộ.
3. Đánh dấu [CẦN XÁC MINH] tại mọi vị trí cần điền mã biểu mẫu hoặc số hiệu quy định nội bộ.
```

## P03 · Rút ngắn 50% thời gian phân tích dữ kiện trong «Lập tờ trình thẩm định hạn mức tín dụng ngắn hạn»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Lập tờ trình thẩm định hạn mức tín dụng ngắn hạn
```text
Tôi là Chuyên viên Thẩm định Tín dụng Doanh nghiệp phụ trách Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay. Công việc «Lập tờ trình thẩm định hạn mức tín dụng ngắn hạn» đang chiếm nhiều thời gian xử lý thủ công mỗi ngày.
Hãy hướng dẫn tôi sử dụng Claude Pro để:
1. Chuyển dữ liệu thô đã ẩn danh của việc «Lập tờ trình thẩm định hạn mức tín dụng ngắn hạn» thành bảng tổng hợp có cấu trúc gồm: Hạng mục, Dữ kiện chính, Điểm bất thường và Đề xuất xử lý.
2. Chỉ ra những tiêu chí nào máy có thể lọc sơ bộ và tiêu chí nào Chuyên viên Thẩm định Tín dụng Doanh nghiệp bắt buộc phải tự kiểm tra bằng mắt.
```

## P04 · Kịch bản giải trình & tháo gỡ vướng mắc khi thực hiện «Lập tờ trình thẩm định hạn mức tín dụng ngắn hạn»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Lập tờ trình thẩm định hạn mức tín dụng ngắn hạn
```text
Khi xử lý «Lập tờ trình thẩm định hạn mức tín dụng ngắn hạn» trong nghiệp vụ Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay, nếu phát sinh vướng mắc về hồ sơ hoặc thời gian chờ phê duyệt:
1. Hãy soạn giúp Chuyên viên Thẩm định Tín dụng Doanh nghiệp 2 phương án giải trình rõ ràng, khách quan để trao đổi với khách hàng hoặc bộ phận thẩm định/kiểm soát.
2. Nêu rõ danh sách giấy tờ/thông tin cần bổ sung trong một lần duy nhất để khách hàng không phải đi lại nhiều lần.
```

## P05 · Lập danh mục rà soát chéo chống trả hồ sơ cho «Kiểm tra chứng từ giải ngân và mục đích sử dụng vốn»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Kiểm tra chứng từ giải ngân và mục đích sử dụng vốn
```text
Dành cho vị trí Chuyên viên Thẩm định Tín dụng Doanh nghiệp (Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay) trên Claude Pro: Để hồ sơ của công việc «Kiểm tra chứng từ giải ngân và mục đích sử dụng vốn» đạt tỷ lệ duyệt ngay lần đầu (First-Time-Right):
1. Liệt kê 6 điểm mâu thuẫn thông tin thường khiến hồ sơ bị cấp kiểm soát trả về.
2. Tạo mẫu phiếu tự kiểm 1 phút để Chuyên viên Thẩm định Tín dụng Doanh nghiệp rà soát sự khớp đúng giữa các chứng từ trước khi trình ký.
```

## P06 · Tổng hợp nhật ký bàn giao cuối ngày cho «Kiểm tra chứng từ giải ngân và mục đích sử dụng vốn»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Kiểm tra chứng từ giải ngân và mục đích sử dụng vốn
```text
Cuối mỗi ca làm việc của Chuyên viên Thẩm định Tín dụng Doanh nghiệp (Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay), hãy giúp tôi tổng hợp kết quả thực hiện công việc «Kiểm tra chứng từ giải ngân và mục đích sử dụng vốn» trên Claude Pro:
1. Phân loại các hồ sơ đã hoàn tất, hồ sơ đang chờ bổ sung và hồ sơ cần ưu tiên đầu giờ sáng hôm sau.
2. Viết ghi chú bàn giao ngắn gọn, rõ người nhận và mốc thời gian cam kết (không ghi thông tin cá nhân thật của khách).
```

## P07 · Thẩm định nguồn thu nhập và năng lực trả nợ (Chuyên viên Thẩm định Tín dụng Doanh nghiệp)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Chuyên viên Thẩm định Tín dụng Doanh nghiệp
- **Mục tiêu nghiệp vụ**: Thẩm định nguồn thu nhập và năng lực trả nợ
```text
[CHUYÊN MÔN CHUYÊN VIÊN THẨM ĐỊNH TÍN DỤNG DOANH NGHIỆP · NGHIỆP VỤ: Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay]
Bối cảnh: Tôi là Chuyên viên Thẩm định Tín dụng Doanh nghiệp, đang thực hiện tác vụ «Thẩm định nguồn thu nhập và năng lực trả nợ» (phân tích bảng sao kê lương, hợp đồng lao động và sổ ghi chép dòng tiền kinh doanh hộ gia đình).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng Khung tính toán hệ số trả nợ (DSR) và kiểm tra tính ổn định của nguồn thu trong 12 tháng gần nhất, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Chuyên viên Thẩm định Tín dụng Doanh nghiệp, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P08 · Phân tích báo cáo tài chính và vòng quay vốn lưu động (Chuyên viên Thẩm định Tín dụng Doanh nghiệp)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Chuyên viên Thẩm định Tín dụng Doanh nghiệp
- **Mục tiêu nghiệp vụ**: Phân tích báo cáo tài chính và vòng quay vốn lưu động
```text
[CHUYÊN MÔN CHUYÊN VIÊN THẨM ĐỊNH TÍN DỤNG DOANH NGHIỆP · NGHIỆP VỤ: Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay]
Bối cảnh: Tôi là Chuyên viên Thẩm định Tín dụng Doanh nghiệp, đang thực hiện tác vụ «Phân tích báo cáo tài chính và vòng quay vốn lưu động» (tính toán hệ số thanh khoản hiện hành, vòng quay khoản phải thu và tỷ lệ nợ trên vốn chủ sở hữu).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng Bảng nhận diện 5 biến động bất thường giữa báo cáo thuế và báo cáo tài chính nội bộ, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Chuyên viên Thẩm định Tín dụng Doanh nghiệp, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P09 · Đánh giá tài sản bảo đảm và biên độ an toàn (Chuyên viên Thẩm định Tín dụng Doanh nghiệp)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Chuyên viên Thẩm định Tín dụng Doanh nghiệp
- **Mục tiêu nghiệp vụ**: Đánh giá tài sản bảo đảm và biên độ an toàn
```text
[CHUYÊN MÔN CHUYÊN VIÊN THẨM ĐỊNH TÍN DỤNG DOANH NGHIỆP · NGHIỆP VỤ: Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay]
Bối cảnh: Tôi là Chuyên viên Thẩm định Tín dụng Doanh nghiệp, đang thực hiện tác vụ «Đánh giá tài sản bảo đảm và biên độ an toàn» (tổng hợp thông tin pháp lý quy hoạch, khả năng thanh khoản và tỷ lệ cấp tín dụng tối đa trên tài sản).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng Danh mục 7 tiêu chí thẩm định thực địa bất động sản và phương tiện vận tải, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Chuyên viên Thẩm định Tín dụng Doanh nghiệp, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P10 · Nhận diện dấu hiệu cảnh báo sớm rủi ro tín dụng (Chuyên viên Thẩm định Tín dụng Doanh nghiệp)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Chuyên viên Thẩm định Tín dụng Doanh nghiệp
- **Mục tiêu nghiệp vụ**: Nhận diện dấu hiệu cảnh báo sớm rủi ro tín dụng
```text
[CHUYÊN MÔN CHUYÊN VIÊN THẨM ĐỊNH TÍN DỤNG DOANH NGHIỆP · NGHIỆP VỤ: Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay]
Bối cảnh: Tôi là Chuyên viên Thẩm định Tín dụng Doanh nghiệp, đang thực hiện tác vụ «Nhận diện dấu hiệu cảnh báo sớm rủi ro tín dụng» (rà soát mâu thuẫn giữa mục đích sử dụng vốn, dòng tiền thực tế và lịch sử quan hệ tín dụng).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng Bộ 8 chỉ báo cảnh báo sớm (Early Warning Signals) trước và sau khi giải ngân, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Chuyên viên Thẩm định Tín dụng Doanh nghiệp, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P11 · Lập tờ trình thẩm định tín dụng trình cấp phê duyệt (Chuyên viên Thẩm định Tín dụng Doanh nghiệp)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Chuyên viên Thẩm định Tín dụng Doanh nghiệp
- **Mục tiêu nghiệp vụ**: Lập tờ trình thẩm định tín dụng trình cấp phê duyệt
```text
[CHUYÊN MÔN CHUYÊN VIÊN THẨM ĐỊNH TÍN DỤNG DOANH NGHIỆP · NGHIỆP VỤ: Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay]
Bối cảnh: Tôi là Chuyên viên Thẩm định Tín dụng Doanh nghiệp, đang thực hiện tác vụ «Lập tờ trình thẩm định tín dụng trình cấp phê duyệt» (cấu trúc tờ trình 5 phần gồm tóm tắt đề xuất, năng lực pháp lý, tài chính, rủi ro và điều kiện tín dụng).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng Mẫu tóm tắt điều hành 1 trang giúp cấp phê duyệt nắm bắt nhanh điểm mạnh và chốt kiểm soát, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Chuyên viên Thẩm định Tín dụng Doanh nghiệp, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P12 · Kiểm tra sau vay và đánh giá mục đích sử dụng vốn (Chuyên viên Thẩm định Tín dụng Doanh nghiệp)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Chuyên viên Thẩm định Tín dụng Doanh nghiệp
- **Mục tiêu nghiệp vụ**: Kiểm tra sau vay và đánh giá mục đích sử dụng vốn
```text
[CHUYÊN MÔN CHUYÊN VIÊN THẨM ĐỊNH TÍN DỤNG DOANH NGHIỆP · NGHIỆP VỤ: Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay]
Bối cảnh: Tôi là Chuyên viên Thẩm định Tín dụng Doanh nghiệp, đang thực hiện tác vụ «Kiểm tra sau vay và đánh giá mục đích sử dụng vốn» (soạn biên bản kiểm tra thực địa, đối chiếu hoá đơn GTGT và chứng từ giải ngân chuyển khoản).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng Bảng kiểm hậu kiểm chứng từ giải ngân và đánh giá tình hình hoạt động thực tế của khách hàng, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Chuyên viên Thẩm định Tín dụng Doanh nghiệp, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P13 · Soạn thư điện tử phối hợp xử lý nghiệp vụ chuẩn ngân hàng
- **Nhóm**: Nhóm C — Soạn thảo biểu mẫu & Tuân thủ quy trình
- **Mục tiêu nghiệp vụ**: Soạn thư điện tử phối hợp giải quyết công việc «rà soát thuyết minh báo cáo tài chính và khoản phải thu» trong mảng Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay
```text
Hãy soạn một thư điện tử trang trọng cho vị trí Chuyên viên Thẩm định Tín dụng Doanh nghiệp để phối hợp xử lý việc «rà soát thuyết minh báo cáo tài chính và khoản phải thu» (Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay) trên Claude Pro. Cấu trúc gồm: Tiêu đề chuẩn có mức độ ưu tiên, Bảng tóm tắt trạng thái hồ sơ ẩn danh, Đề xuất hướng xử lý và Thời hạn phản hồi SLA.
```

## P14 · Lập tờ trình nghiệp vụ có bảng đánh giá rủi ro
- **Nhóm**: Nhóm C — Soạn thảo biểu mẫu & Tuân thủ quy trình
- **Mục tiêu nghiệp vụ**: Soạn tờ trình đề xuất phương án xử lý cho Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay của vị trí Chuyên viên Thẩm định Tín dụng Doanh nghiệp
```text
Hãy lập khung Tờ trình nghiệp vụ dành cho Chuyên viên Thẩm định Tín dụng Doanh nghiệp phụ trách Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay (trọng tâm: «lập tờ trình thẩm định hạn mức tín dụng ngắn hạn»). Bắt buộc có đủ 4 mục: Căn cứ thực hiện (gắn nhãn [CẦN XÁC MINH] số hiệu văn bản), Nội dung đề xuất, Bảng nhận diện rủi ro & Biện pháp kiểm soát Maker-Checker, và Kiến nghị phê duyệt.
```

## P15 · Đối chiếu quy trình tác nghiệp với văn bản quy định nội bộ
- **Nhóm**: Nhóm C — Soạn thảo biểu mẫu & Tuân thủ quy trình
- **Mục tiêu nghiệp vụ**: Rà soát quy trình «lập tờ trình thẩm định hạn mức tín dụng ngắn hạn» của Chuyên viên Thẩm định Tín dụng Doanh nghiệp và đánh dấu [CẦN XÁC MINH] các căn cứ pháp lý
```text
Dựa trên bản mô tả các bước thực hiện «lập tờ trình thẩm định hạn mức tín dụng ngắn hạn» của Chuyên viên Thẩm định Tín dụng Doanh nghiệp (Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay), hãy lập bảng đối chiếu gồm 4 cột: Bước thực hiện hiện tại — Rủi ro sai lệch — Điểm cần đối chiếu với quy định nội bộ [CẦN XÁC MINH] — Đề xuất chuẩn hoá.
```

## P16 · Rà soát chéo Maker-Checker phát hiện sai lệch số liệu
- **Nhóm**: Nhóm D — Kiểm soát Maker-Checker & Báo cáo tuần
- **Mục tiêu nghiệp vụ**: Kiểm tra chéo kết quả «kiểm tra chứng từ giải ngân và mục đích sử dụng vốn» trong nghiệp vụ Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay
```text
Đóng vai Kiểm soát viên kiểm tra lại hồ sơ «kiểm tra chứng từ giải ngân và mục đích sử dụng vốn» do Chuyên viên Thẩm định Tín dụng Doanh nghiệp (Phan Thanh Sơn) lập trong mảng Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay. Hãy chỉ ra các điểm cần đối chiếu số học, tính nhất quán giữa chữ và số, và các điều kiện phê duyệt còn thiếu.
```

## P17 · Tổng hợp báo cáo hiệu suất tuần từ nhật ký công việc
- **Nhóm**: Nhóm D — Kiểm soát Maker-Checker & Báo cáo tuần
- **Mục tiêu nghiệp vụ**: Tổng hợp kết quả công việc tuần cho vị trí Chuyên viên Thẩm định Tín dụng Doanh nghiệp phụ trách Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay
```text
Từ danh sách số lượng hồ sơ đã xử lý trong tuần của Phan Thanh Sơn (Chuyên viên Thẩm định Tín dụng Doanh nghiệp — Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay), hãy xuất bảng Báo cáo tuần gồm: Nhóm việc trọng tâm (Rà soát thuyết minh báo cáo tài chính và khoản phải thu; Lập tờ trình thẩm định hạn mức tín dụng ngắn hạn; Kiểm tra chứng từ giải ngân và mục đích sử dụng vốn), Khối lượng hoàn thành, Tỷ lệ đúng hạn SLA, Điểm nghẽn phát sinh và Đề xuất tuần tới.
```

## P18 · Tối ưu lại thư viện câu lệnh cá nhân sau mỗi tuần làm việc
- **Nhóm**: Nhóm D — Kiểm soát Maker-Checker & Báo cáo tuần
- **Mục tiêu nghiệp vụ**: Tinh chỉnh bộ câu lệnh Claude Pro cho 3 việc trọng tâm của Chuyên viên Thẩm định Tín dụng Doanh nghiệp
```text
Dựa trên kết quả sử dụng Claude Pro trong tuần qua cho 3 việc («Rà soát thuyết minh báo cáo tài chính và khoản phải thu», «Lập tờ trình thẩm định hạn mức tín dụng ngắn hạn», «Kiểm tra chứng từ giải ngân và mục đích sử dụng vốn») ở vị trí Chuyên viên Thẩm định Tín dụng Doanh nghiệp, hãy đề xuất cách rút gọn câu lệnh và bổ sung các ràng buộc đầu ra để kết quả tuần tới sát với biểu mẫu thực tế hơn.
```
