# MẪU 01: EMAIL GIAO DỊCH & PHỐI HỢP NGHIỆP VỤ (CHUYÊN VIÊN THẨM ĐỊNH TÍN DỤNG DOANH NGHIỆP)
> **Nhãn dữ liệu**: `[GIẢ LẬP]` · **Người sử dụng**: Phan Thanh Sơn (Chuyên viên Thẩm định Tín dụng Doanh nghiệp) · **Nghiệp vụ**: Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay

## 1. Cấu trúc tiêu đề chuẩn
`[Mã đơn vị] - [Mức độ ưu tiên] - V/v: Phối hợp xử lý rà soát thuyết minh báo cáo tài chính và khoản phải thu (Mã hồ sơ ẩn danh: HS-XXXX)`

## 2. Nội dung biểu mẫu
Kính gửi: Anh/Chị `[Tên người nhận / Bộ phận phối hợp]`,

Căn cứ quy trình thực hiện nghiệp vụ **Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay** (`[CẦN XÁC MINH mã quy trình nội bộ]`), tôi xin gửi thông tin tổng hợp liên quan đến công việc **Rà soát thuyết minh báo cáo tài chính và khoản phải thu** như sau:

| Hạng mục kiểm tra | Nội dung tóm tắt (Đã ẩn danh PII) | Trạng thái chứng từ | Cam kết SLA |
|---|---|---|---|
| Hồ sơ pháp lý / Giao dịch | Đã đối chiếu bản gốc tại đơn vị | Đạt yêu cầu | Trong 30 phút |
| Nội dung cần phối hợp | Xác nhận bước kiểm soát đối với rà soát thuyết minh báo cáo tài chính và khoản phải thu | Đang chờ duyệt | Trước 15:00 hôm nay |
| Điểm kiểm soát rủi ro | Đã qua bước kiểm tra sơ bộ của Chuyên viên Thẩm định Tín dụng Doanh nghiệp | Đã ký kiểm soát | Đúng hạn |

Kính đề nghị Anh/Chị xem xét và phản hồi trước `[Giờ/Ngày]` để đảm bảo tiến độ cam kết với khách hàng.

Trân trọng,
**Phan Thanh Sơn** — Chuyên viên Thẩm định Tín dụng Doanh nghiệp
