# MẪU 02: TỜ TRÌNH NGHIỆP VỤ & ĐÁNH GIÁ RỦI RO (CHUYÊN VIÊN THẨM ĐỊNH TÍN DỤNG DOANH NGHIỆP)
> **Nhãn dữ liệu**: `[GIẢ LẬP]` · **Người lập**: Phan Thanh Sơn (Chuyên viên Thẩm định Tín dụng Doanh nghiệp) · **Nghiệp vụ**: Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay

## 1. Căn cứ thực hiện
- Quy định nội bộ về **Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay** của Ngân hàng (`[CẦN XÁC MINH số hiệu văn bản hiện hành]`).
- Văn bản hướng dẫn nghiệp vụ của Ngân hàng Nhà nước có liên quan (`[CẦN XÁC MINH thông tư áp dụng]`).

## 2. Tóm tắt nội dung trình duyệt
Phục vụ xử lý nghiệp vụ **Lập tờ trình thẩm định hạn mức tín dụng ngắn hạn** và **Rà soát thuyết minh báo cáo tài chính và khoản phải thu** tại đơn vị:

| STT | Bước nghiệp vụ | Người thực hiện (R) | Người phê duyệt (A) | Điểm kiểm soát (Maker-Checker) | SLA chuẩn |
|---|---|---|---|---|---|
| 1 | Tiếp nhận & kiểm tra hồ sơ | Chuyên viên Thẩm định Tín dụng Doanh nghiệp | Trưởng bộ phận | Đối chiếu danh mục chứng từ bắt buộc | 20 phút |
| 2 | Xử lý chuyên môn: Lập tờ trình thẩm định hạn mức tín dụng ngắn hạn | Chuyên viên Thẩm định Tín dụng Doanh nghiệp | Kiểm soát viên / Cấp phê duyệt | Kiểm tra chéo số liệu & hạn mức | 45 phút |
| 3 | Hạch toán / Hoàn tất lưu trữ | Bộ phận Vận hành | Giám đốc đơn vị | Nhật ký hệ thống & lưu hồ sơ | 15 phút |

## 3. Nhận diện rủi ro & Biện pháp kiểm soát
- **Rủi ro tác nghiệp**: Sai sót thông tin khi nhập liệu thủ công ở khâu `Lập tờ trình thẩm định hạn mức tín dụng ngắn hạn`.
- **Biện pháp kiểm soát**: Áp dụng nguyên tắc bốn mắt (Maker-Checker) trước khi phê duyệt trên hệ thống.

## 4. Kiến nghị phê duyệt
Kính trình Lãnh đạo đơn vị xem xét phê duyệt phương án thực hiện như mục 2.
