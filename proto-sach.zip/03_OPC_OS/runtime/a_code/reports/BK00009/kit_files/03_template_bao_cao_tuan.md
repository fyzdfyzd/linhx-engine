# MẪU 03: BÁO CÁO TUẦN & ĐỐI SOÁT HIỆU SUẤT (CHUYÊN VIÊN THẨM ĐỊNH TÍN DỤNG DOANH NGHIỆP)
> **Nhãn dữ liệu**: `[GIẢ LẬP]` · **Người báo cáo**: Phan Thanh Sơn (Chuyên viên Thẩm định Tín dụng Doanh nghiệp) · **Nghiệp vụ**: Thẩm định báo cáo tài chính doanh nghiệp, đánh giá dòng tiền và phương án vay

## 1. Bảng kết quả thực hiện trong tuần
| Nhóm công việc trọng tâm | Khối lượng hoàn thành | Tỷ lệ đúng hạn SLA | Thời gian tiết kiệm nhờ AI | Ghi chú kiểm soát |
|---|---|---|---|---|
| 1. Rà soát thuyết minh báo cáo tài chính và khoản phải thu | 18 hồ sơ / lượt | 100% | 3,5 giờ/tuần | Không phát sinh lỗi trả về |
| 2. Lập tờ trình thẩm định hạn mức tín dụng ngắn hạn | 14 hồ sơ / lượt | 96% | 2,5 giờ/tuần | Đã rà soát chéo 100% |
| 3. Kiểm tra chứng từ giải ngân và mục đích sử dụng vốn | 10 hồ sơ / lượt | 100% | 2,0 giờ/tuần | Đạt chuẩn tuân thủ |

## 2. Vấn đề tồn đọng & Đề xuất tuần tới
1. **Điểm nghẽn**: Thời gian chờ bổ sung chứng từ ở khâu `Lập tờ trình thẩm định hạn mức tín dụng ngắn hạn` còn kéo dài vào cuối buổi chiều.
2. **Giải pháp tuần tới**: Áp dụng mẫu nhắc hồ sơ tự động từ đầu giờ sáng và rà soát danh mục `[CẦN XÁC MINH]` trước khi trình ký.
