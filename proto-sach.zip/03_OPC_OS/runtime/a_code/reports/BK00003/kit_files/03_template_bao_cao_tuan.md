# MẪU 03: BÁO CÁO TUẦN & ĐỐI SOÁT HIỆU SUẤT (CHUYÊN VIÊN THẨM ĐỊNH TÍN DỤNG CÁ NHÂN)
> **Nhãn dữ liệu**: `[GIẢ LẬP]` · **Người báo cáo**: Hoàng Minh Đức (Chuyên viên Thẩm định Tín dụng Cá nhân) · **Nghiệp vụ**: Thẩm định hồ sơ vay mua bất động sản, phân tích nguồn trả nợ và lập tờ trình tái thẩm định

## 1. Bảng kết quả thực hiện trong tuần
| Nhóm công việc trọng tâm | Khối lượng hoàn thành | Tỷ lệ đúng hạn SLA | Thời gian tiết kiệm nhờ AI | Ghi chú kiểm soát |
|---|---|---|---|---|
| 1. Phân tích sao kê dòng tiền thu nhập và lịch sử trả nợ của khách vay | 18 hồ sơ / lượt | 100% | 3,5 giờ/tuần | Không phát sinh lỗi trả về |
| 2. Viết tờ trình thẩm định tín dụng nêu rõ điểm mạnh và rủi ro khoản vay | 14 hồ sơ / lượt | 96% | 2,5 giờ/tuần | Đã rà soát chéo 100% |
| 3. Soạn thông báo điều kiện phê duyệt tín dụng gửi đơn vị kinh doanh | 10 hồ sơ / lượt | 100% | 2,0 giờ/tuần | Đạt chuẩn tuân thủ |

## 2. Vấn đề tồn đọng & Đề xuất tuần tới
1. **Điểm nghẽn**: Thời gian chờ bổ sung chứng từ ở khâu `Viết tờ trình thẩm định tín dụng nêu rõ điểm mạnh và rủi ro khoản vay` còn kéo dài vào cuối buổi chiều.
2. **Giải pháp tuần tới**: Áp dụng mẫu nhắc hồ sơ tự động từ đầu giờ sáng và rà soát danh mục `[CẦN XÁC MINH]` trước khi trình ký.
