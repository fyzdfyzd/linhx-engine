# MẪU 01: EMAIL GIAO DỊCH & PHỐI HỢP NGHIỆP VỤ (CHUYÊN VIÊN THẨM ĐỊNH TÍN DỤNG CÁ NHÂN)
> **Nhãn dữ liệu**: `[GIẢ LẬP]` · **Người sử dụng**: Hoàng Minh Đức (Chuyên viên Thẩm định Tín dụng Cá nhân) · **Nghiệp vụ**: Thẩm định hồ sơ vay mua bất động sản, phân tích nguồn trả nợ và lập tờ trình tái thẩm định

## 1. Cấu trúc tiêu đề chuẩn
`[Mã đơn vị] - [Mức độ ưu tiên] - V/v: Phối hợp xử lý phân tích sao kê dòng tiền thu nhập và lịch sử trả nợ của khách vay (Mã hồ sơ ẩn danh: HS-XXXX)`

## 2. Nội dung biểu mẫu
Kính gửi: Anh/Chị `[Tên người nhận / Bộ phận phối hợp]`,

Căn cứ quy trình thực hiện nghiệp vụ **Thẩm định hồ sơ vay mua bất động sản, phân tích nguồn trả nợ và lập tờ trình tái thẩm định** (`[CẦN XÁC MINH mã quy trình nội bộ]`), tôi xin gửi thông tin tổng hợp liên quan đến công việc **Phân tích sao kê dòng tiền thu nhập và lịch sử trả nợ của khách vay** như sau:

| Hạng mục kiểm tra | Nội dung tóm tắt (Đã ẩn danh PII) | Trạng thái chứng từ | Cam kết SLA |
|---|---|---|---|
| Hồ sơ pháp lý / Giao dịch | Đã đối chiếu bản gốc tại đơn vị | Đạt yêu cầu | Trong 30 phút |
| Nội dung cần phối hợp | Xác nhận bước kiểm soát đối với phân tích sao kê dòng tiền thu nhập và lịch sử trả nợ của khách vay | Đang chờ duyệt | Trước 15:00 hôm nay |
| Điểm kiểm soát rủi ro | Đã qua bước kiểm tra sơ bộ của Chuyên viên Thẩm định Tín dụng Cá nhân | Đã ký kiểm soát | Đúng hạn |

Kính đề nghị Anh/Chị xem xét và phản hồi trước `[Giờ/Ngày]` để đảm bảo tiến độ cam kết với khách hàng.

Trân trọng,
**Hoàng Minh Đức** — Chuyên viên Thẩm định Tín dụng Cá nhân
