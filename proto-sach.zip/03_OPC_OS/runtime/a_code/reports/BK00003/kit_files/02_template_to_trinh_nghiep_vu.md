# MẪU 02: TỜ TRÌNH NGHIỆP VỤ & ĐÁNH GIÁ RỦI RO (CHUYÊN VIÊN THẨM ĐỊNH TÍN DỤNG CÁ NHÂN)
> **Nhãn dữ liệu**: `[GIẢ LẬP]` · **Người lập**: Hoàng Minh Đức (Chuyên viên Thẩm định Tín dụng Cá nhân) · **Nghiệp vụ**: Thẩm định hồ sơ vay mua bất động sản, phân tích nguồn trả nợ và lập tờ trình tái thẩm định

## 1. Căn cứ thực hiện
- Quy định nội bộ về **Thẩm định hồ sơ vay mua bất động sản, phân tích nguồn trả nợ và lập tờ trình tái thẩm định** của Ngân hàng (`[CẦN XÁC MINH số hiệu văn bản hiện hành]`).
- Văn bản hướng dẫn nghiệp vụ của Ngân hàng Nhà nước có liên quan (`[CẦN XÁC MINH thông tư áp dụng]`).

## 2. Tóm tắt nội dung trình duyệt
Phục vụ xử lý nghiệp vụ **Viết tờ trình thẩm định tín dụng nêu rõ điểm mạnh và rủi ro khoản vay** và **Phân tích sao kê dòng tiền thu nhập và lịch sử trả nợ của khách vay** tại đơn vị:

| STT | Bước nghiệp vụ | Người thực hiện (R) | Người phê duyệt (A) | Điểm kiểm soát (Maker-Checker) | SLA chuẩn |
|---|---|---|---|---|---|
| 1 | Tiếp nhận & kiểm tra hồ sơ | Chuyên viên Thẩm định Tín dụng Cá nhân | Trưởng bộ phận | Đối chiếu danh mục chứng từ bắt buộc | 20 phút |
| 2 | Xử lý chuyên môn: Viết tờ trình thẩm định tín dụng nêu rõ điểm mạnh và rủi ro khoản vay | Chuyên viên Thẩm định Tín dụng Cá nhân | Kiểm soát viên / Cấp phê duyệt | Kiểm tra chéo số liệu & hạn mức | 45 phút |
| 3 | Hạch toán / Hoàn tất lưu trữ | Bộ phận Vận hành | Giám đốc đơn vị | Nhật ký hệ thống & lưu hồ sơ | 15 phút |

## 3. Nhận diện rủi ro & Biện pháp kiểm soát
- **Rủi ro tác nghiệp**: Sai sót thông tin khi nhập liệu thủ công ở khâu `Viết tờ trình thẩm định tín dụng nêu rõ điểm mạnh và rủi ro khoản vay`.
- **Biện pháp kiểm soát**: Áp dụng nguyên tắc bốn mắt (Maker-Checker) trước khi phê duyệt trên hệ thống.

## 4. Kiến nghị phê duyệt
Kính trình Lãnh đạo đơn vị xem xét phê duyệt phương án thực hiện như mục 2.
