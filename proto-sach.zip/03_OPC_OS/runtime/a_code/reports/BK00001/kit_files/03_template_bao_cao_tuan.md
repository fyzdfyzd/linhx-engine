# MẪU 03: BÁO CÁO TUẦN & ĐỐI SOÁT HIỆU SUẤT (RM KHÁCH HÀNG DOANH NGHIỆP SME)
> **Nhãn dữ liệu**: `[GIẢ LẬP]` · **Người báo cáo**: Phạm Quốc Khánh (RM Khách hàng Doanh nghiệp SME) · **Nghiệp vụ**: Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA

## 1. Bảng kết quả thực hiện trong tuần
| Nhóm công việc trọng tâm | Khối lượng hoàn thành | Tỷ lệ đúng hạn SLA | Thời gian tiết kiệm nhờ AI | Ghi chú kiểm soát |
|---|---|---|---|---|
| 1. Viết báo cáo tiếp xúc khách hàng doanh nghiệp sau buổi gặp | 18 hồ sơ / lượt | 100% | 3,5 giờ/tuần | Không phát sinh lỗi trả về |
| 2. Soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng | 14 hồ sơ / lượt | 96% | 2,5 giờ/tuần | Đã rà soát chéo 100% |
| 3. Soạn email giải trình lãi suất và phí tài trợ thương mại | 10 hồ sơ / lượt | 100% | 2,0 giờ/tuần | Đạt chuẩn tuân thủ |

## 2. Vấn đề tồn đọng & Đề xuất tuần tới
1. **Điểm nghẽn**: Thời gian chờ bổ sung chứng từ ở khâu `Soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng` còn kéo dài vào cuối buổi chiều.
2. **Giải pháp tuần tới**: Áp dụng mẫu nhắc hồ sơ tự động từ đầu giờ sáng và rà soát danh mục `[CẦN XÁC MINH]` trước khi trình ký.
