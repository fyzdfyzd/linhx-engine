# BỘ 18 PROMPT AI CÁ NHÂN HOÁ DÀNH RIÊNG CHO PHẠM QUỐC KHÁNH (RM KHÁCH HÀNG DOANH NGHIỆP SME)
> **Nhãn**: `[GIẢ LẬP]` · **Vị trí**: RM Khách hàng Doanh nghiệp SME · **Nghiệp vụ chính**: Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA · **Công cụ AI**: Claude Pro
> **3 việc tốn giờ nhất đã cá nhân hoá**: (1) Viết báo cáo tiếp xúc khách hàng doanh nghiệp sau buổi gặp · (2) Soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng · (3) Soạn email giải trình lãi suất và phí tài trợ thương mại

## P01 · Thiết kế bảng kiểm 5 bước & điểm chặn sai sót cho «Viết báo cáo tiếp xúc khách hàng doanh nghiệp sau buổi gặp»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Viết báo cáo tiếp xúc khách hàng doanh nghiệp sau buổi gặp
```text
Đóng vai Chuyên gia Kiểm soát Chất lượng mảng Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA, hãy giúp tôi chuẩn hoá công việc «Viết báo cáo tiếp xúc khách hàng doanh nghiệp sau buổi gặp» của vị trí RM Khách hàng Doanh nghiệp SME trên Claude Pro:
1. Tách quy trình thực hiện thành 5 bước tuần tự kèm thời gian định mức (SLA) cho từng bước.
2. Xác định 3 lỗi sai số liệu hoặc thiếu chứng từ thường gặp nhất ở khâu «Viết báo cáo tiếp xúc khách hàng doanh nghiệp sau buổi gặp» và cách chặn từ đầu.
3. Thiết kế 1 bảng kiểm đối chiếu nhanh (Maker-Checker) trước khi chuyển hồ sơ sang bộ phận tiếp theo (chỉ dùng dữ liệu ẩn danh [GIẢ LẬP]).
```

## P02 · Soạn thảo văn bản & thông điệp chuẩn mực cho «Viết báo cáo tiếp xúc khách hàng doanh nghiệp sau buổi gặp»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Viết báo cáo tiếp xúc khách hàng doanh nghiệp sau buổi gặp
```text
Trên công cụ Claude Pro, từ dữ kiện nghiệp vụ đã che tên thật và số tài khoản dưới đây về việc «Viết báo cáo tiếp xúc khách hàng doanh nghiệp sau buổi gặp» (Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA):
1. Soạn 1 bản văn bản hành chính ngân hàng ngắn gọn (nêu rõ mục đích, danh mục hồ sơ đính kèm, thời hạn phản hồi).
2. Viết thêm 1 phiên bản tóm tắt 4 dòng để báo cáo nhanh qua nhóm điều phối nội bộ.
3. Đánh dấu [CẦN XÁC MINH] tại mọi vị trí cần điền mã biểu mẫu hoặc số hiệu quy định nội bộ.
```

## P03 · Rút ngắn 50% thời gian phân tích dữ kiện trong «Soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng
```text
Tôi là RM Khách hàng Doanh nghiệp SME phụ trách Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA. Công việc «Soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng» đang chiếm nhiều thời gian xử lý thủ công mỗi ngày.
Hãy hướng dẫn tôi sử dụng Claude Pro để:
1. Chuyển dữ liệu thô đã ẩn danh của việc «Soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng» thành bảng tổng hợp có cấu trúc gồm: Hạng mục, Dữ kiện chính, Điểm bất thường và Đề xuất xử lý.
2. Chỉ ra những tiêu chí nào máy có thể lọc sơ bộ và tiêu chí nào RM Khách hàng Doanh nghiệp SME bắt buộc phải tự kiểm tra bằng mắt.
```

## P04 · Kịch bản giải trình & tháo gỡ vướng mắc khi thực hiện «Soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng
```text
Khi xử lý «Soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng» trong nghiệp vụ Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA, nếu phát sinh vướng mắc về hồ sơ hoặc thời gian chờ phê duyệt:
1. Hãy soạn giúp RM Khách hàng Doanh nghiệp SME 2 phương án giải trình rõ ràng, khách quan để trao đổi với khách hàng hoặc bộ phận thẩm định/kiểm soát.
2. Nêu rõ danh sách giấy tờ/thông tin cần bổ sung trong một lần duy nhất để khách hàng không phải đi lại nhiều lần.
```

## P05 · Lập danh mục rà soát chéo chống trả hồ sơ cho «Soạn email giải trình lãi suất và phí tài trợ thương mại»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Soạn email giải trình lãi suất và phí tài trợ thương mại
```text
Dành cho vị trí RM Khách hàng Doanh nghiệp SME (Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA) trên Claude Pro: Để hồ sơ của công việc «Soạn email giải trình lãi suất và phí tài trợ thương mại» đạt tỷ lệ duyệt ngay lần đầu (First-Time-Right):
1. Liệt kê 6 điểm mâu thuẫn thông tin thường khiến hồ sơ bị cấp kiểm soát trả về.
2. Tạo mẫu phiếu tự kiểm 1 phút để RM Khách hàng Doanh nghiệp SME rà soát sự khớp đúng giữa các chứng từ trước khi trình ký.
```

## P06 · Tổng hợp nhật ký bàn giao cuối ngày cho «Soạn email giải trình lãi suất và phí tài trợ thương mại»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Soạn email giải trình lãi suất và phí tài trợ thương mại
```text
Cuối mỗi ca làm việc của RM Khách hàng Doanh nghiệp SME (Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA), hãy giúp tôi tổng hợp kết quả thực hiện công việc «Soạn email giải trình lãi suất và phí tài trợ thương mại» trên Claude Pro:
1. Phân loại các hồ sơ đã hoàn tất, hồ sơ đang chờ bổ sung và hồ sơ cần ưu tiên đầu giờ sáng hôm sau.
2. Viết ghi chú bàn giao ngắn gọn, rõ người nhận và mốc thời gian cam kết (không ghi thông tin cá nhân thật của khách).
```

## P07 · Khai thác nhu cầu vốn lưu động & bảo lãnh (RM Khách hàng Doanh nghiệp SME)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho RM Khách hàng Doanh nghiệp SME
- **Mục tiêu nghiệp vụ**: Khai thác nhu cầu vốn lưu động & bảo lãnh
```text
[CHUYÊN MÔN RM KHÁCH HÀNG DOANH NGHIỆP SME · NGHIỆP VỤ: Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA]
Bối cảnh: Tôi là RM Khách hàng Doanh nghiệp SME, đang thực hiện tác vụ «Khai thác nhu cầu vốn lưu động & bảo lãnh» (chuẩn bị bộ câu hỏi khảo sát vòng quay hàng tồn kho, công nợ phải thu và nhu cầu bảo lãnh dự thầu trước buổi gặp doanh nghiệp).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng Bảng 10 câu hỏi phỏng vấn Giám đốc Tài chính (CFO) doanh nghiệp SME kèm chỉ số tài chính cần thu thập, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của RM Khách hàng Doanh nghiệp SME, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P08 · Thuyết minh cấu trúc hạn mức tín dụng (RM Khách hàng Doanh nghiệp SME)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho RM Khách hàng Doanh nghiệp SME
- **Mục tiêu nghiệp vụ**: Thuyết minh cấu trúc hạn mức tín dụng
```text
[CHUYÊN MÔN RM KHÁCH HÀNG DOANH NGHIỆP SME · NGHIỆP VỤ: Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA]
Bối cảnh: Tôi là RM Khách hàng Doanh nghiệp SME, đang thực hiện tác vụ «Thuyết minh cấu trúc hạn mức tín dụng» (tóm tắt phương án tài trợ thương mại, chiết khấu bộ chứng từ và cơ cấu tài sản bảo đảm).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng Khung thuyết minh 4 phần trình Hội đồng Tín dụng làm rõ nguồn trả nợ thứ nhất và thứ hai, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của RM Khách hàng Doanh nghiệp SME, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P09 · Chăm sóc sau giải ngân & bán chéo CASA (RM Khách hàng Doanh nghiệp SME)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho RM Khách hàng Doanh nghiệp SME
- **Mục tiêu nghiệp vụ**: Chăm sóc sau giải ngân & bán chéo CASA
```text
[CHUYÊN MÔN RM KHÁCH HÀNG DOANH NGHIỆP SME · NGHIỆP VỤ: Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA]
Bối cảnh: Tôi là RM Khách hàng Doanh nghiệp SME, đang thực hiện tác vụ «Chăm sóc sau giải ngân & bán chéo CASA» (thiết kế kịch bản mời doanh nghiệp sử dụng gói chi lương tự động, thu hộ QR và tiền gửi kỳ hạn ngắn).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng Kịch bản tư vấn 3 phương án tối ưu dòng tiền nhàn rỗi giúp tăng tỷ lệ CASA tại đơn vị, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của RM Khách hàng Doanh nghiệp SME, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P10 · Xử lý từ chối về lãi suất vay (RM Khách hàng Doanh nghiệp SME)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho RM Khách hàng Doanh nghiệp SME
- **Mục tiêu nghiệp vụ**: Xử lý từ chối về lãi suất vay
```text
[CHUYÊN MÔN RM KHÁCH HÀNG DOANH NGHIỆP SME · NGHIỆP VỤ: Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA]
Bối cảnh: Tôi là RM Khách hàng Doanh nghiệp SME, đang thực hiện tác vụ «Xử lý từ chối về lãi suất vay» (soạn bảng đối chiếu tổng chi phí vốn thực tế, tốc độ giải ngân và tiện ích ngân hàng số).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng Ma trận 5 tình huống khách hàng so sánh lãi suất và cách phản hồi dựa trên giá trị tổng thể, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của RM Khách hàng Doanh nghiệp SME, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P11 · Rà soát hồ sơ pháp lý doanh nghiệp (RM Khách hàng Doanh nghiệp SME)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho RM Khách hàng Doanh nghiệp SME
- **Mục tiêu nghiệp vụ**: Rà soát hồ sơ pháp lý doanh nghiệp
```text
[CHUYÊN MÔN RM KHÁCH HÀNG DOANH NGHIỆP SME · NGHIỆP VỤ: Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA]
Bối cảnh: Tôi là RM Khách hàng Doanh nghiệp SME, đang thực hiện tác vụ «Rà soát hồ sơ pháp lý doanh nghiệp» (kiểm tra danh mục giấy phép đăng ký kinh doanh, điều lệ công ty, biên bản họp HĐTV và tờ khai thuế).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng Bảng kiểm đối chiếu tính hợp lệ của đại diện pháp luật và thẩm quyền ký kết hợp đồng tín dụng, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của RM Khách hàng Doanh nghiệp SME, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P12 · Chuẩn bị kịch bản tiếp cận khách hàng mới (RM Khách hàng Doanh nghiệp SME)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho RM Khách hàng Doanh nghiệp SME
- **Mục tiêu nghiệp vụ**: Chuẩn bị kịch bản tiếp cận khách hàng mới
```text
[CHUYÊN MÔN RM KHÁCH HÀNG DOANH NGHIỆP SME · NGHIỆP VỤ: Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA]
Bối cảnh: Tôi là RM Khách hàng Doanh nghiệp SME, đang thực hiện tác vụ «Chuẩn bị kịch bản tiếp cận khách hàng mới» (viết lời giới thiệu giải pháp tài chính chuyên biệt theo ngành sản xuất, thương mại hoặc xuất nhập khẩu).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng 3 mẫu mở đầu cuộc gọi và tin nhắn hẹn gặp theo đặc thù dòng tiền từng ngành, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của RM Khách hàng Doanh nghiệp SME, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P13 · Soạn thư điện tử phối hợp xử lý nghiệp vụ chuẩn ngân hàng
- **Nhóm**: Nhóm C — Soạn thảo biểu mẫu & Tuân thủ quy trình
- **Mục tiêu nghiệp vụ**: Soạn thư điện tử phối hợp giải quyết công việc «viết báo cáo tiếp xúc khách hàng doanh nghiệp sau buổi gặp» trong mảng Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA
```text
Hãy soạn một thư điện tử trang trọng cho vị trí RM Khách hàng Doanh nghiệp SME để phối hợp xử lý việc «viết báo cáo tiếp xúc khách hàng doanh nghiệp sau buổi gặp» (Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA) trên Claude Pro. Cấu trúc gồm: Tiêu đề chuẩn có mức độ ưu tiên, Bảng tóm tắt trạng thái hồ sơ ẩn danh, Đề xuất hướng xử lý và Thời hạn phản hồi SLA.
```

## P14 · Lập tờ trình nghiệp vụ có bảng đánh giá rủi ro
- **Nhóm**: Nhóm C — Soạn thảo biểu mẫu & Tuân thủ quy trình
- **Mục tiêu nghiệp vụ**: Soạn tờ trình đề xuất phương án xử lý cho Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA của vị trí RM Khách hàng Doanh nghiệp SME
```text
Hãy lập khung Tờ trình nghiệp vụ dành cho RM Khách hàng Doanh nghiệp SME phụ trách Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA (trọng tâm: «soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng»). Bắt buộc có đủ 4 mục: Căn cứ thực hiện (gắn nhãn [CẦN XÁC MINH] số hiệu văn bản), Nội dung đề xuất, Bảng nhận diện rủi ro & Biện pháp kiểm soát Maker-Checker, và Kiến nghị phê duyệt.
```

## P15 · Đối chiếu quy trình tác nghiệp với văn bản quy định nội bộ
- **Nhóm**: Nhóm C — Soạn thảo biểu mẫu & Tuân thủ quy trình
- **Mục tiêu nghiệp vụ**: Rà soát quy trình «soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng» của RM Khách hàng Doanh nghiệp SME và đánh dấu [CẦN XÁC MINH] các căn cứ pháp lý
```text
Dựa trên bản mô tả các bước thực hiện «soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng» của RM Khách hàng Doanh nghiệp SME (Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA), hãy lập bảng đối chiếu gồm 4 cột: Bước thực hiện hiện tại — Rủi ro sai lệch — Điểm cần đối chiếu với quy định nội bộ [CẦN XÁC MINH] — Đề xuất chuẩn hoá.
```

## P16 · Rà soát chéo Maker-Checker phát hiện sai lệch số liệu
- **Nhóm**: Nhóm D — Kiểm soát Maker-Checker & Báo cáo tuần
- **Mục tiêu nghiệp vụ**: Kiểm tra chéo kết quả «soạn email giải trình lãi suất và phí tài trợ thương mại» trong nghiệp vụ Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA
```text
Đóng vai Kiểm soát viên kiểm tra lại hồ sơ «soạn email giải trình lãi suất và phí tài trợ thương mại» do RM Khách hàng Doanh nghiệp SME (Phạm Quốc Khánh) lập trong mảng Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA. Hãy chỉ ra các điểm cần đối chiếu số học, tính nhất quán giữa chữ và số, và các điều kiện phê duyệt còn thiếu.
```

## P17 · Tổng hợp báo cáo hiệu suất tuần từ nhật ký công việc
- **Nhóm**: Nhóm D — Kiểm soát Maker-Checker & Báo cáo tuần
- **Mục tiêu nghiệp vụ**: Tổng hợp kết quả công việc tuần cho vị trí RM Khách hàng Doanh nghiệp SME phụ trách Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA
```text
Từ danh sách số lượng hồ sơ đã xử lý trong tuần của Phạm Quốc Khánh (RM Khách hàng Doanh nghiệp SME — Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA), hãy xuất bảng Báo cáo tuần gồm: Nhóm việc trọng tâm (Viết báo cáo tiếp xúc khách hàng doanh nghiệp sau buổi gặp; Soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng; Soạn email giải trình lãi suất và phí tài trợ thương mại), Khối lượng hoàn thành, Tỷ lệ đúng hạn SLA, Điểm nghẽn phát sinh và Đề xuất tuần tới.
```

## P18 · Tối ưu lại thư viện câu lệnh cá nhân sau mỗi tuần làm việc
- **Nhóm**: Nhóm D — Kiểm soát Maker-Checker & Báo cáo tuần
- **Mục tiêu nghiệp vụ**: Tinh chỉnh bộ câu lệnh Claude Pro cho 3 việc trọng tâm của RM Khách hàng Doanh nghiệp SME
```text
Dựa trên kết quả sử dụng Claude Pro trong tuần qua cho 3 việc («Viết báo cáo tiếp xúc khách hàng doanh nghiệp sau buổi gặp», «Soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng», «Soạn email giải trình lãi suất và phí tài trợ thương mại») ở vị trí RM Khách hàng Doanh nghiệp SME, hãy đề xuất cách rút gọn câu lệnh và bổ sung các ràng buộc đầu ra để kết quả tuần tới sát với biểu mẫu thực tế hơn.
```
