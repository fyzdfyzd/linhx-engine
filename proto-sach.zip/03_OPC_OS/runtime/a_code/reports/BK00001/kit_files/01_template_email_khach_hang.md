# MẪU 01: EMAIL GIAO DỊCH & PHỐI HỢP NGHIỆP VỤ (RM KHÁCH HÀNG DOANH NGHIỆP SME)
> **Nhãn dữ liệu**: `[GIẢ LẬP]` · **Người sử dụng**: Phạm Quốc Khánh (RM Khách hàng Doanh nghiệp SME) · **Nghiệp vụ**: Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA

## 1. Cấu trúc tiêu đề chuẩn
`[Mã đơn vị] - [Mức độ ưu tiên] - V/v: Phối hợp xử lý viết báo cáo tiếp xúc khách hàng doanh nghiệp sau buổi gặp (Mã hồ sơ ẩn danh: HS-XXXX)`

## 2. Nội dung biểu mẫu
Kính gửi: Anh/Chị `[Tên người nhận / Bộ phận phối hợp]`,

Căn cứ quy trình thực hiện nghiệp vụ **Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA** (`[CẦN XÁC MINH mã quy trình nội bộ]`), tôi xin gửi thông tin tổng hợp liên quan đến công việc **Viết báo cáo tiếp xúc khách hàng doanh nghiệp sau buổi gặp** như sau:

| Hạng mục kiểm tra | Nội dung tóm tắt (Đã ẩn danh PII) | Trạng thái chứng từ | Cam kết SLA |
|---|---|---|---|
| Hồ sơ pháp lý / Giao dịch | Đã đối chiếu bản gốc tại đơn vị | Đạt yêu cầu | Trong 30 phút |
| Nội dung cần phối hợp | Xác nhận bước kiểm soát đối với viết báo cáo tiếp xúc khách hàng doanh nghiệp sau buổi gặp | Đang chờ duyệt | Trước 15:00 hôm nay |
| Điểm kiểm soát rủi ro | Đã qua bước kiểm tra sơ bộ của RM Khách hàng Doanh nghiệp SME | Đã ký kiểm soát | Đúng hạn |

Kính đề nghị Anh/Chị xem xét và phản hồi trước `[Giờ/Ngày]` để đảm bảo tiến độ cam kết với khách hàng.

Trân trọng,
**Phạm Quốc Khánh** — RM Khách hàng Doanh nghiệp SME
