# MẪU 02: TỜ TRÌNH NGHIỆP VỤ & ĐÁNH GIÁ RỦI RO (RM KHÁCH HÀNG DOANH NGHIỆP SME)
> **Nhãn dữ liệu**: `[GIẢ LẬP]` · **Người lập**: Phạm Quốc Khánh (RM Khách hàng Doanh nghiệp SME) · **Nghiệp vụ**: Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA

## 1. Căn cứ thực hiện
- Quy định nội bộ về **Tư vấn hạn mức tín dụng vốn lưu động, bảo lãnh dự thầu và bán chéo gói chi lương CASA** của Ngân hàng (`[CẦN XÁC MINH số hiệu văn bản hiện hành]`).
- Văn bản hướng dẫn nghiệp vụ của Ngân hàng Nhà nước có liên quan (`[CẦN XÁC MINH thông tư áp dụng]`).

## 2. Tóm tắt nội dung trình duyệt
Phục vụ xử lý nghiệp vụ **Soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng** và **Viết báo cáo tiếp xúc khách hàng doanh nghiệp sau buổi gặp** tại đơn vị:

| STT | Bước nghiệp vụ | Người thực hiện (R) | Người phê duyệt (A) | Điểm kiểm soát (Maker-Checker) | SLA chuẩn |
|---|---|---|---|---|---|
| 1 | Tiếp nhận & kiểm tra hồ sơ | RM Khách hàng Doanh nghiệp SME | Trưởng bộ phận | Đối chiếu danh mục chứng từ bắt buộc | 20 phút |
| 2 | Xử lý chuyên môn: Soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng | RM Khách hàng Doanh nghiệp SME | Kiểm soát viên / Cấp phê duyệt | Kiểm tra chéo số liệu & hạn mức | 45 phút |
| 3 | Hạch toán / Hoàn tất lưu trữ | Bộ phận Vận hành | Giám đốc đơn vị | Nhật ký hệ thống & lưu hồ sơ | 15 phút |

## 3. Nhận diện rủi ro & Biện pháp kiểm soát
- **Rủi ro tác nghiệp**: Sai sót thông tin khi nhập liệu thủ công ở khâu `Soạn đề xuất cấu trúc hạn mức vay và bảo lãnh trình hội đồng`.
- **Biện pháp kiểm soát**: Áp dụng nguyên tắc bốn mắt (Maker-Checker) trước khi phê duyệt trên hệ thống.

## 4. Kiến nghị phê duyệt
Kính trình Lãnh đạo đơn vị xem xét phê duyệt phương án thực hiện như mục 2.
