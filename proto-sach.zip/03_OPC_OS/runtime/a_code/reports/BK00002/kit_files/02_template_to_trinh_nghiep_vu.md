# MẪU 02: TỜ TRÌNH NGHIỆP VỤ & ĐÁNH GIÁ RỦI RO (GIAO DỊCH VIÊN QUẦY (TELLER))
> **Nhãn dữ liệu**: `[GIẢ LẬP]` · **Người lập**: Lê Thu Trang (Giao dịch viên Quầy (Teller)) · **Nghiệp vụ**: Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC

## 1. Căn cứ thực hiện
- Quy định nội bộ về **Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC** của Ngân hàng (`[CẦN XÁC MINH số hiệu văn bản hiện hành]`).
- Văn bản hướng dẫn nghiệp vụ của Ngân hàng Nhà nước có liên quan (`[CẦN XÁC MINH thông tư áp dụng]`).

## 2. Tóm tắt nội dung trình duyệt
Phục vụ xử lý nghiệp vụ **Hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn** và **Soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng** tại đơn vị:

| STT | Bước nghiệp vụ | Người thực hiện (R) | Người phê duyệt (A) | Điểm kiểm soát (Maker-Checker) | SLA chuẩn |
|---|---|---|---|---|---|
| 1 | Tiếp nhận & kiểm tra hồ sơ | Giao dịch viên Quầy (Teller) | Trưởng bộ phận | Đối chiếu danh mục chứng từ bắt buộc | 20 phút |
| 2 | Xử lý chuyên môn: Hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn | Giao dịch viên Quầy (Teller) | Kiểm soát viên / Cấp phê duyệt | Kiểm tra chéo số liệu & hạn mức | 45 phút |
| 3 | Hạch toán / Hoàn tất lưu trữ | Bộ phận Vận hành | Giám đốc đơn vị | Nhật ký hệ thống & lưu hồ sơ | 15 phút |

## 3. Nhận diện rủi ro & Biện pháp kiểm soát
- **Rủi ro tác nghiệp**: Sai sót thông tin khi nhập liệu thủ công ở khâu `Hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn`.
- **Biện pháp kiểm soát**: Áp dụng nguyên tắc bốn mắt (Maker-Checker) trước khi phê duyệt trên hệ thống.

## 4. Kiến nghị phê duyệt
Kính trình Lãnh đạo đơn vị xem xét phê duyệt phương án thực hiện như mục 2.
