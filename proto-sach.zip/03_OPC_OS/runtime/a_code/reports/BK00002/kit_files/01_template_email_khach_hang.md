# MẪU 01: EMAIL GIAO DỊCH & PHỐI HỢP NGHIỆP VỤ (GIAO DỊCH VIÊN QUẦY (TELLER))
> **Nhãn dữ liệu**: `[GIẢ LẬP]` · **Người sử dụng**: Lê Thu Trang (Giao dịch viên Quầy (Teller)) · **Nghiệp vụ**: Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC

## 1. Cấu trúc tiêu đề chuẩn
`[Mã đơn vị] - [Mức độ ưu tiên] - V/v: Phối hợp xử lý soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng (Mã hồ sơ ẩn danh: HS-XXXX)`

## 2. Nội dung biểu mẫu
Kính gửi: Anh/Chị `[Tên người nhận / Bộ phận phối hợp]`,

Căn cứ quy trình thực hiện nghiệp vụ **Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC** (`[CẦN XÁC MINH mã quy trình nội bộ]`), tôi xin gửi thông tin tổng hợp liên quan đến công việc **Soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng** như sau:

| Hạng mục kiểm tra | Nội dung tóm tắt (Đã ẩn danh PII) | Trạng thái chứng từ | Cam kết SLA |
|---|---|---|---|
| Hồ sơ pháp lý / Giao dịch | Đã đối chiếu bản gốc tại đơn vị | Đạt yêu cầu | Trong 30 phút |
| Nội dung cần phối hợp | Xác nhận bước kiểm soát đối với soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng | Đang chờ duyệt | Trước 15:00 hôm nay |
| Điểm kiểm soát rủi ro | Đã qua bước kiểm tra sơ bộ của Giao dịch viên Quầy (Teller) | Đã ký kiểm soát | Đúng hạn |

Kính đề nghị Anh/Chị xem xét và phản hồi trước `[Giờ/Ngày]` để đảm bảo tiến độ cam kết với khách hàng.

Trân trọng,
**Lê Thu Trang** — Giao dịch viên Quầy (Teller)
