# BỘ 18 PROMPT AI CÁ NHÂN HOÁ DÀNH RIÊNG CHO LÊ THU TRANG (GIAO DỊCH VIÊN QUẦY (TELLER))
> **Nhãn**: `[GIẢ LẬP]` · **Vị trí**: Giao dịch viên Quầy (Teller) · **Nghiệp vụ chính**: Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC · **Công cụ AI**: ChatGPT Plus
> **3 việc tốn giờ nhất đã cá nhân hoá**: (1) Soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng · (2) Hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn · (3) Tổng hợp biên bản kiểm quỹ và đối chiếu chứng từ cuối ngày

## P01 · Thiết kế bảng kiểm 5 bước & điểm chặn sai sót cho «Soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng
```text
Đóng vai Chuyên gia Kiểm soát Chất lượng mảng Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC, hãy giúp tôi chuẩn hoá công việc «Soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng» của vị trí Giao dịch viên Quầy (Teller) trên ChatGPT Plus:
1. Tách quy trình thực hiện thành 5 bước tuần tự kèm thời gian định mức (SLA) cho từng bước.
2. Xác định 3 lỗi sai số liệu hoặc thiếu chứng từ thường gặp nhất ở khâu «Soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng» và cách chặn từ đầu.
3. Thiết kế 1 bảng kiểm đối chiếu nhanh (Maker-Checker) trước khi chuyển hồ sơ sang bộ phận tiếp theo (chỉ dùng dữ liệu ẩn danh [GIẢ LẬP]).
```

## P02 · Soạn thảo văn bản & thông điệp chuẩn mực cho «Soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng
```text
Trên công cụ ChatGPT Plus, từ dữ kiện nghiệp vụ đã che tên thật và số tài khoản dưới đây về việc «Soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng» (Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC):
1. Soạn 1 bản văn bản hành chính ngân hàng ngắn gọn (nêu rõ mục đích, danh mục hồ sơ đính kèm, thời hạn phản hồi).
2. Viết thêm 1 phiên bản tóm tắt 4 dòng để báo cáo nhanh qua nhóm điều phối nội bộ.
3. Đánh dấu [CẦN XÁC MINH] tại mọi vị trí cần điền mã biểu mẫu hoặc số hiệu quy định nội bộ.
```

## P03 · Rút ngắn 50% thời gian phân tích dữ kiện trong «Hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn
```text
Tôi là Giao dịch viên Quầy (Teller) phụ trách Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC. Công việc «Hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn» đang chiếm nhiều thời gian xử lý thủ công mỗi ngày.
Hãy hướng dẫn tôi sử dụng ChatGPT Plus để:
1. Chuyển dữ liệu thô đã ẩn danh của việc «Hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn» thành bảng tổng hợp có cấu trúc gồm: Hạng mục, Dữ kiện chính, Điểm bất thường và Đề xuất xử lý.
2. Chỉ ra những tiêu chí nào máy có thể lọc sơ bộ và tiêu chí nào Giao dịch viên Quầy (Teller) bắt buộc phải tự kiểm tra bằng mắt.
```

## P04 · Kịch bản giải trình & tháo gỡ vướng mắc khi thực hiện «Hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn
```text
Khi xử lý «Hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn» trong nghiệp vụ Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC, nếu phát sinh vướng mắc về hồ sơ hoặc thời gian chờ phê duyệt:
1. Hãy soạn giúp Giao dịch viên Quầy (Teller) 2 phương án giải trình rõ ràng, khách quan để trao đổi với khách hàng hoặc bộ phận thẩm định/kiểm soát.
2. Nêu rõ danh sách giấy tờ/thông tin cần bổ sung trong một lần duy nhất để khách hàng không phải đi lại nhiều lần.
```

## P05 · Lập danh mục rà soát chéo chống trả hồ sơ cho «Tổng hợp biên bản kiểm quỹ và đối chiếu chứng từ cuối ngày»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Tổng hợp biên bản kiểm quỹ và đối chiếu chứng từ cuối ngày
```text
Dành cho vị trí Giao dịch viên Quầy (Teller) (Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC) trên ChatGPT Plus: Để hồ sơ của công việc «Tổng hợp biên bản kiểm quỹ và đối chiếu chứng từ cuối ngày» đạt tỷ lệ duyệt ngay lần đầu (First-Time-Right):
1. Liệt kê 6 điểm mâu thuẫn thông tin thường khiến hồ sơ bị cấp kiểm soát trả về.
2. Tạo mẫu phiếu tự kiểm 1 phút để Giao dịch viên Quầy (Teller) rà soát sự khớp đúng giữa các chứng từ trước khi trình ký.
```

## P06 · Tổng hợp nhật ký bàn giao cuối ngày cho «Tổng hợp biên bản kiểm quỹ và đối chiếu chứng từ cuối ngày»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Tổng hợp biên bản kiểm quỹ và đối chiếu chứng từ cuối ngày
```text
Cuối mỗi ca làm việc của Giao dịch viên Quầy (Teller) (Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC), hãy giúp tôi tổng hợp kết quả thực hiện công việc «Tổng hợp biên bản kiểm quỹ và đối chiếu chứng từ cuối ngày» trên ChatGPT Plus:
1. Phân loại các hồ sơ đã hoàn tất, hồ sơ đang chờ bổ sung và hồ sơ cần ưu tiên đầu giờ sáng hôm sau.
2. Viết ghi chú bàn giao ngắn gọn, rõ người nhận và mốc thời gian cam kết (không ghi thông tin cá nhân thật của khách).
```

## P07 · Xử lý giao dịch nộp rút và chuyển tiền tại quầy (Giao dịch viên Quầy (Teller))
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Giao dịch viên Quầy (Teller)
- **Mục tiêu nghiệp vụ**: Xử lý giao dịch nộp rút và chuyển tiền tại quầy
```text
[CHUYÊN MÔN GIAO DỊCH VIÊN QUẦY (TELLER) · NGHIỆP VỤ: Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC]
Bối cảnh: Tôi là Giao dịch viên Quầy (Teller), đang thực hiện tác vụ «Xử lý giao dịch nộp rút và chuyển tiền tại quầy» (kiểm tra nhanh danh mục chứng từ uỷ nhiệm chi, giấy lĩnh tiền mặt và hạn mức phê duyệt trong ngày).
Công cụ sử dụng: ChatGPT Plus.
Đầu ra yêu cầu: Hãy xây dựng Bảng kiểm 6 điểm nhận diện sai sót trên chứng từ kế toán trước khi hạch toán vào Core Banking, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Giao dịch viên Quầy (Teller), điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P08 · Tra soát giao dịch chuyển tiền nhanh liên ngân hàng (Giao dịch viên Quầy (Teller))
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Giao dịch viên Quầy (Teller)
- **Mục tiêu nghiệp vụ**: Tra soát giao dịch chuyển tiền nhanh liên ngân hàng
```text
[CHUYÊN MÔN GIAO DỊCH VIÊN QUẦY (TELLER) · NGHIỆP VỤ: Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC]
Bối cảnh: Tôi là Giao dịch viên Quầy (Teller), đang thực hiện tác vụ «Tra soát giao dịch chuyển tiền nhanh liên ngân hàng» (soạn phiếu tiếp nhận tra soát và hướng dẫn khách hàng theo dõi tiến độ đối soát).
Công cụ sử dụng: ChatGPT Plus.
Đầu ra yêu cầu: Hãy xây dựng Mẫu thông báo lộ trình xử lý tra soát rõ ràng từng mốc thời gian cam kết (SLA), trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Giao dịch viên Quầy (Teller), điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P09 · Hướng dẫn cập nhật sinh trắc học và định danh điện tử (Giao dịch viên Quầy (Teller))
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Giao dịch viên Quầy (Teller)
- **Mục tiêu nghiệp vụ**: Hướng dẫn cập nhật sinh trắc học và định danh điện tử
```text
[CHUYÊN MÔN GIAO DỊCH VIÊN QUẦY (TELLER) · NGHIỆP VỤ: Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC]
Bối cảnh: Tôi là Giao dịch viên Quầy (Teller), đang thực hiện tác vụ «Hướng dẫn cập nhật sinh trắc học và định danh điện tử» (giải thích quy trình đối chiếu căn cước gắn chip theo quy định hiện hành [CẦN XÁC MINH]).
Công cụ sử dụng: ChatGPT Plus.
Đầu ra yêu cầu: Hãy xây dựng Hướng dẫn từng bước bằng ngôn ngữ bình dân cho khách hàng lớn tuổi tại quầy giao dịch, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Giao dịch viên Quầy (Teller), điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P10 · Kiểm đếm và cân đối sổ quỹ cuối ngày (Giao dịch viên Quầy (Teller))
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Giao dịch viên Quầy (Teller)
- **Mục tiêu nghiệp vụ**: Kiểm đếm và cân đối sổ quỹ cuối ngày
```text
[CHUYÊN MÔN GIAO DỊCH VIÊN QUẦY (TELLER) · NGHIỆP VỤ: Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC]
Bối cảnh: Tôi là Giao dịch viên Quầy (Teller), đang thực hiện tác vụ «Kiểm đếm và cân đối sổ quỹ cuối ngày» (rà soát chênh lệch bảng kê mệnh giá tiền mặt, ngoại tệ và chứng từ thu chi trong ca).
Công cụ sử dụng: ChatGPT Plus.
Đầu ra yêu cầu: Hãy xây dựng Quy trình 4 bước khoanh vùng nhanh nguyên nhân lệch quỹ cuối ngày giữa Giao dịch viên và Kiểm soát viên, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Giao dịch viên Quầy (Teller), điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P11 · Tư vấn biểu phí dịch vụ và kỳ hạn tiết kiệm (Giao dịch viên Quầy (Teller))
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Giao dịch viên Quầy (Teller)
- **Mục tiêu nghiệp vụ**: Tư vấn biểu phí dịch vụ và kỳ hạn tiết kiệm
```text
[CHUYÊN MÔN GIAO DỊCH VIÊN QUẦY (TELLER) · NGHIỆP VỤ: Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC]
Bối cảnh: Tôi là Giao dịch viên Quầy (Teller), đang thực hiện tác vụ «Tư vấn biểu phí dịch vụ và kỳ hạn tiết kiệm» (so sánh lợi tức thực nhận giữa tiết kiệm trả lãi cuối kỳ, định kỳ và gửi góp linh hoạt).
Công cụ sử dụng: ChatGPT Plus.
Đầu ra yêu cầu: Hãy xây dựng Bảng so sánh trực quan 3 phương án gửi tiết kiệm theo kế hoạch chi tiêu của khách hàng cá nhân, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Giao dịch viên Quầy (Teller), điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P12 · Hoà giải tình huống khách hàng chờ lâu giờ cao điểm (Giao dịch viên Quầy (Teller))
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Giao dịch viên Quầy (Teller)
- **Mục tiêu nghiệp vụ**: Hoà giải tình huống khách hàng chờ lâu giờ cao điểm
```text
[CHUYÊN MÔN GIAO DỊCH VIÊN QUẦY (TELLER) · NGHIỆP VỤ: Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC]
Bối cảnh: Tôi là Giao dịch viên Quầy (Teller), đang thực hiện tác vụ «Hoà giải tình huống khách hàng chờ lâu giờ cao điểm» (soạn lời xin lỗi chuẩn mực dịch vụ khách hàng và điều phối phân luồng giao dịch ưu tiên).
Công cụ sử dụng: ChatGPT Plus.
Đầu ra yêu cầu: Hãy xây dựng 3 mẫu câu giao tiếp hạ nhiệt căng thẳng tại quầy và hướng dẫn chuyển giao dịch nhỏ sang máy tự động, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Giao dịch viên Quầy (Teller), điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P13 · Soạn thư điện tử phối hợp xử lý nghiệp vụ chuẩn ngân hàng
- **Nhóm**: Nhóm C — Soạn thảo biểu mẫu & Tuân thủ quy trình
- **Mục tiêu nghiệp vụ**: Soạn thư điện tử phối hợp giải quyết công việc «soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng» trong mảng Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC
```text
Hãy soạn một thư điện tử trang trọng cho vị trí Giao dịch viên Quầy (Teller) để phối hợp xử lý việc «soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng» (Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC) trên ChatGPT Plus. Cấu trúc gồm: Tiêu đề chuẩn có mức độ ưu tiên, Bảng tóm tắt trạng thái hồ sơ ẩn danh, Đề xuất hướng xử lý và Thời hạn phản hồi SLA.
```

## P14 · Lập tờ trình nghiệp vụ có bảng đánh giá rủi ro
- **Nhóm**: Nhóm C — Soạn thảo biểu mẫu & Tuân thủ quy trình
- **Mục tiêu nghiệp vụ**: Soạn tờ trình đề xuất phương án xử lý cho Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC của vị trí Giao dịch viên Quầy (Teller)
```text
Hãy lập khung Tờ trình nghiệp vụ dành cho Giao dịch viên Quầy (Teller) phụ trách Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC (trọng tâm: «hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn»). Bắt buộc có đủ 4 mục: Căn cứ thực hiện (gắn nhãn [CẦN XÁC MINH] số hiệu văn bản), Nội dung đề xuất, Bảng nhận diện rủi ro & Biện pháp kiểm soát Maker-Checker, và Kiến nghị phê duyệt.
```

## P15 · Đối chiếu quy trình tác nghiệp với văn bản quy định nội bộ
- **Nhóm**: Nhóm C — Soạn thảo biểu mẫu & Tuân thủ quy trình
- **Mục tiêu nghiệp vụ**: Rà soát quy trình «hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn» của Giao dịch viên Quầy (Teller) và đánh dấu [CẦN XÁC MINH] các căn cứ pháp lý
```text
Dựa trên bản mô tả các bước thực hiện «hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn» của Giao dịch viên Quầy (Teller) (Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC), hãy lập bảng đối chiếu gồm 4 cột: Bước thực hiện hiện tại — Rủi ro sai lệch — Điểm cần đối chiếu với quy định nội bộ [CẦN XÁC MINH] — Đề xuất chuẩn hoá.
```

## P16 · Rà soát chéo Maker-Checker phát hiện sai lệch số liệu
- **Nhóm**: Nhóm D — Kiểm soát Maker-Checker & Báo cáo tuần
- **Mục tiêu nghiệp vụ**: Kiểm tra chéo kết quả «tổng hợp biên bản kiểm quỹ và đối chiếu chứng từ cuối ngày» trong nghiệp vụ Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC
```text
Đóng vai Kiểm soát viên kiểm tra lại hồ sơ «tổng hợp biên bản kiểm quỹ và đối chiếu chứng từ cuối ngày» do Giao dịch viên Quầy (Teller) (Lê Thu Trang) lập trong mảng Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC. Hãy chỉ ra các điểm cần đối chiếu số học, tính nhất quán giữa chữ và số, và các điều kiện phê duyệt còn thiếu.
```

## P17 · Tổng hợp báo cáo hiệu suất tuần từ nhật ký công việc
- **Nhóm**: Nhóm D — Kiểm soát Maker-Checker & Báo cáo tuần
- **Mục tiêu nghiệp vụ**: Tổng hợp kết quả công việc tuần cho vị trí Giao dịch viên Quầy (Teller) phụ trách Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC
```text
Từ danh sách số lượng hồ sơ đã xử lý trong tuần của Lê Thu Trang (Giao dịch viên Quầy (Teller) — Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC), hãy xuất bảng Báo cáo tuần gồm: Nhóm việc trọng tâm (Soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng; Hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn; Tổng hợp biên bản kiểm quỹ và đối chiếu chứng từ cuối ngày), Khối lượng hoàn thành, Tỷ lệ đúng hạn SLA, Điểm nghẽn phát sinh và Đề xuất tuần tới.
```

## P18 · Tối ưu lại thư viện câu lệnh cá nhân sau mỗi tuần làm việc
- **Nhóm**: Nhóm D — Kiểm soát Maker-Checker & Báo cáo tuần
- **Mục tiêu nghiệp vụ**: Tinh chỉnh bộ câu lệnh ChatGPT Plus cho 3 việc trọng tâm của Giao dịch viên Quầy (Teller)
```text
Dựa trên kết quả sử dụng ChatGPT Plus trong tuần qua cho 3 việc («Soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng», «Hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn», «Tổng hợp biên bản kiểm quỹ và đối chiếu chứng từ cuối ngày») ở vị trí Giao dịch viên Quầy (Teller), hãy đề xuất cách rút gọn câu lệnh và bổ sung các ràng buộc đầu ra để kết quả tuần tới sát với biểu mẫu thực tế hơn.
```
