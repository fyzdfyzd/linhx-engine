# MẪU 03: BÁO CÁO TUẦN & ĐỐI SOÁT HIỆU SUẤT (GIAO DỊCH VIÊN QUẦY (TELLER))
> **Nhãn dữ liệu**: `[GIẢ LẬP]` · **Người báo cáo**: Lê Thu Trang (Giao dịch viên Quầy (Teller)) · **Nghiệp vụ**: Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC

## 1. Bảng kết quả thực hiện trong tuần
| Nhóm công việc trọng tâm | Khối lượng hoàn thành | Tỷ lệ đúng hạn SLA | Thời gian tiết kiệm nhờ AI | Ghi chú kiểm soát |
|---|---|---|---|---|
| 1. Soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng | 18 hồ sơ / lượt | 100% | 3,5 giờ/tuần | Không phát sinh lỗi trả về |
| 2. Hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn | 14 hồ sơ / lượt | 96% | 2,5 giờ/tuần | Đã rà soát chéo 100% |
| 3. Tổng hợp biên bản kiểm quỹ và đối chiếu chứng từ cuối ngày | 10 hồ sơ / lượt | 100% | 2,0 giờ/tuần | Đạt chuẩn tuân thủ |

## 2. Vấn đề tồn đọng & Đề xuất tuần tới
1. **Điểm nghẽn**: Thời gian chờ bổ sung chứng từ ở khâu `Hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn` còn kéo dài vào cuối buổi chiều.
2. **Giải pháp tuần tới**: Áp dụng mẫu nhắc hồ sơ tự động từ đầu giờ sáng và rà soát danh mục `[CẦN XÁC MINH]` trước khi trình ký.
