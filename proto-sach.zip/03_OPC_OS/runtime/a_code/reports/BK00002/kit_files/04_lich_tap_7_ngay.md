# LỊCH TẬP 7 NGÀY LÀM CHỦ BỘ CÔNG CỤ AI NGÂN HÀNG
> **Học viên**: Lê Thu Trang · **Vị trí**: Giao dịch viên Quầy (Teller) · **Nghiệp vụ**: Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC · **Công cụ**: ChatGPT Plus

| Ngày | Mục tiêu rèn luyện (15 phút/ngày) | Prompt & Template áp dụng | Bài tập thực hành trên dữ liệu giả lập | Tiêu chí hoàn thành |
|---|---|---|---|---|
| **Ngày 1** | Thiết lập quy tắc ẩn danh dữ liệu & khung làm việc trên ChatGPT Plus | `P01`, `P02` | Thay toàn bộ tên thật, số CIF, CCCD bằng mã `KH_01` trước khi thử việc `Soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng` | 0% dữ liệu thật đưa lên AI |
| **Ngày 2** | Tự động hoá việc tốn giờ #1: `Soạn phiếu tiếp nhận tra soát chuyển tiền nhầm tài khoản liên ngân hàng` | `P01`, `P02`, `Mẫu 01 Email` | Tạo bảng kiểm 5 bước và bản nháp email phối hợp trong 3 phút | Giảm 50% thời gian soạn thảo |
| **Ngày 3** | Tự động hoá việc tốn giờ #2: `Hướng dẫn khách hàng cập nhật sinh trắc học và giấy tờ tuỳ thân hết hạn` | `P03`, `P04`, `Mẫu 02 Tờ trình` | Lập khung tờ trình có cột Maker-Checker và nhãn `[CẦN XÁC MINH]` | Đủ 4 mục chuẩn tờ trình |
| **Ngày 4** | Tự động hoá việc tốn giờ #3: `Tổng hợp biên bản kiểm quỹ và đối chiếu chứng từ cuối ngày` | `P05`, `P06` | Rà soát lỗi số liệu và lập danh sách điểm kiểm soát rủi ro | Bắt được 3 điểm rủi ro |
| **Ngày 5** | Ứng dụng bộ câu lệnh chuyên sâu cho `Giao dịch viên Quầy (Teller)` | `P07` đến `P12` | Thực hành kịch bản chuyên môn `Xử lý giao dịch nộp rút tiền mặt, tra soát chuyển tiền nhanh Napas 247 và mở tài khoản eKYC` trên 2 tình huống giả định | Hoàn thành 2 hồ sơ mẫu |
| **Ngày 6** | Rà soát tuân thủ & chuẩn hoá SOP nội bộ | `P13`, `P14`, `P15` | Kiểm tra chéo quy trình với văn bản nội bộ, gắn cờ `[CẦN XÁC MINH]` | Không tự bịa số hiệu thông tư |
| **Ngày 7** | Tổng kết hiệu suất tuần & tinh chỉnh thư viện cá nhân | `P16`, `P17`, `P18`, `Mẫu 03 Báo cáo tuần` | Xuất báo cáo tuần từ nhật ký công việc và lưu 5 câu lệnh dùng nhiều nhất | Tiết kiệm ≥ 5 giờ làm việc/tuần |
