# Phiếu chất lượng: Bản đồ sao cá nhân · Bùi Ngọc Ánh

**ĐẠT**: 97.3/100 (ngưỡng 85), 0 lỗi, 3 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 7215 |
| so_doan_loi_giai | 100 |
| so_muc | 17 |
| muc_du_noi_dung | 16 |
| so_nguon | 7 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 24.4 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|
| Q14 | canh | 1 | 2.0 |
| Q15 | canh | 1 | 0.2 |
| Q12 | canh | 1 | 0.5 |

## Chi tiết (tối đa 60 dòng)

- [canh] Q14 @ muoi-hai-nha: 3 đoạn cùng mở đầu “ngọc ánh có”
- [canh] Q15 @ mat-trang#8: Khoảng trắng thừa quanh dấu câu — “Ngọc Ánh khá nhạy cảm, thậm chí sẽ có khả năng tâm linh. Ngoài …”
- [canh] Q12 @ sao-tho#1: Câu 62 chữ — “Với bạn, sự an toàn về vật chất rất quan trọng và vị thế …”
