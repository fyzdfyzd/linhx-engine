# MẪU 01: EMAIL GIAO DỊCH & PHỐI HỢP NGHIỆP VỤ (CHUYÊN VIÊN VẬN HÀNH & ĐỐI SOÁT THANH TOÁN)
> **Nhãn dữ liệu**: `[GIẢ LẬP]` · **Người sử dụng**: Nguyễn Đình Khoa (Chuyên viên Vận hành & Đối soát Thanh toán) · **Nghiệp vụ**: Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP

## 1. Cấu trúc tiêu đề chuẩn
`[Mã đơn vị] - [Mức độ ưu tiên] - V/v: Phối hợp xử lý đối soát chênh lệch sao kê ngân hàng và sổ phụ cuối ngày (Mã hồ sơ ẩn danh: HS-XXXX)`

## 2. Nội dung biểu mẫu
Kính gửi: Anh/Chị `[Tên người nhận / Bộ phận phối hợp]`,

Căn cứ quy trình thực hiện nghiệp vụ **Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP** (`[CẦN XÁC MINH mã quy trình nội bộ]`), tôi xin gửi thông tin tổng hợp liên quan đến công việc **Đối soát chênh lệch sao kê ngân hàng và sổ phụ cuối ngày** như sau:

| Hạng mục kiểm tra | Nội dung tóm tắt (Đã ẩn danh PII) | Trạng thái chứng từ | Cam kết SLA |
|---|---|---|---|
| Hồ sơ pháp lý / Giao dịch | Đã đối chiếu bản gốc tại đơn vị | Đạt yêu cầu | Trong 30 phút |
| Nội dung cần phối hợp | Xác nhận bước kiểm soát đối với đối soát chênh lệch sao kê ngân hàng và sổ phụ cuối ngày | Đang chờ duyệt | Trước 15:00 hôm nay |
| Điểm kiểm soát rủi ro | Đã qua bước kiểm tra sơ bộ của Chuyên viên Vận hành & Đối soát Thanh toán | Đã ký kiểm soát | Đúng hạn |

Kính đề nghị Anh/Chị xem xét và phản hồi trước `[Giờ/Ngày]` để đảm bảo tiến độ cam kết với khách hàng.

Trân trọng,
**Nguyễn Đình Khoa** — Chuyên viên Vận hành & Đối soát Thanh toán
