# BỘ 18 PROMPT AI CÁ NHÂN HOÁ DÀNH RIÊNG CHO NGUYỄN ĐÌNH KHOA (CHUYÊN VIÊN VẬN HÀNH & ĐỐI SOÁT THANH TOÁN)
> **Nhãn**: `[GIẢ LẬP]` · **Vị trí**: Chuyên viên Vận hành & Đối soát Thanh toán · **Nghiệp vụ chính**: Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP · **Công cụ AI**: Claude Pro
> **3 việc tốn giờ nhất đã cá nhân hoá**: (1) Đối soát chênh lệch sao kê ngân hàng và sổ phụ cuối ngày · (2) Soạn thảo quy trình SOP 10 mục kèm lưu đồ và bảng RACI · (3) Lập báo cáo tổng hợp SLA vận hành hàng tuần

## P01 · Thiết kế bảng kiểm 5 bước & điểm chặn sai sót cho «Đối soát chênh lệch sao kê ngân hàng và sổ phụ cuối ngày»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Đối soát chênh lệch sao kê ngân hàng và sổ phụ cuối ngày
```text
Đóng vai Chuyên gia Kiểm soát Chất lượng mảng Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP, hãy giúp tôi chuẩn hoá công việc «Đối soát chênh lệch sao kê ngân hàng và sổ phụ cuối ngày» của vị trí Chuyên viên Vận hành & Đối soát Thanh toán trên Claude Pro:
1. Tách quy trình thực hiện thành 5 bước tuần tự kèm thời gian định mức (SLA) cho từng bước.
2. Xác định 3 lỗi sai số liệu hoặc thiếu chứng từ thường gặp nhất ở khâu «Đối soát chênh lệch sao kê ngân hàng và sổ phụ cuối ngày» và cách chặn từ đầu.
3. Thiết kế 1 bảng kiểm đối chiếu nhanh (Maker-Checker) trước khi chuyển hồ sơ sang bộ phận tiếp theo (chỉ dùng dữ liệu ẩn danh [GIẢ LẬP]).
```

## P02 · Soạn thảo văn bản & thông điệp chuẩn mực cho «Đối soát chênh lệch sao kê ngân hàng và sổ phụ cuối ngày»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Đối soát chênh lệch sao kê ngân hàng và sổ phụ cuối ngày
```text
Trên công cụ Claude Pro, từ dữ kiện nghiệp vụ đã che tên thật và số tài khoản dưới đây về việc «Đối soát chênh lệch sao kê ngân hàng và sổ phụ cuối ngày» (Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP):
1. Soạn 1 bản văn bản hành chính ngân hàng ngắn gọn (nêu rõ mục đích, danh mục hồ sơ đính kèm, thời hạn phản hồi).
2. Viết thêm 1 phiên bản tóm tắt 4 dòng để báo cáo nhanh qua nhóm điều phối nội bộ.
3. Đánh dấu [CẦN XÁC MINH] tại mọi vị trí cần điền mã biểu mẫu hoặc số hiệu quy định nội bộ.
```

## P03 · Rút ngắn 50% thời gian phân tích dữ kiện trong «Soạn thảo quy trình SOP 10 mục kèm lưu đồ và bảng RACI»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Soạn thảo quy trình SOP 10 mục kèm lưu đồ và bảng RACI
```text
Tôi là Chuyên viên Vận hành & Đối soát Thanh toán phụ trách Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP. Công việc «Soạn thảo quy trình SOP 10 mục kèm lưu đồ và bảng RACI» đang chiếm nhiều thời gian xử lý thủ công mỗi ngày.
Hãy hướng dẫn tôi sử dụng Claude Pro để:
1. Chuyển dữ liệu thô đã ẩn danh của việc «Soạn thảo quy trình SOP 10 mục kèm lưu đồ và bảng RACI» thành bảng tổng hợp có cấu trúc gồm: Hạng mục, Dữ kiện chính, Điểm bất thường và Đề xuất xử lý.
2. Chỉ ra những tiêu chí nào máy có thể lọc sơ bộ và tiêu chí nào Chuyên viên Vận hành & Đối soát Thanh toán bắt buộc phải tự kiểm tra bằng mắt.
```

## P04 · Kịch bản giải trình & tháo gỡ vướng mắc khi thực hiện «Soạn thảo quy trình SOP 10 mục kèm lưu đồ và bảng RACI»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Soạn thảo quy trình SOP 10 mục kèm lưu đồ và bảng RACI
```text
Khi xử lý «Soạn thảo quy trình SOP 10 mục kèm lưu đồ và bảng RACI» trong nghiệp vụ Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP, nếu phát sinh vướng mắc về hồ sơ hoặc thời gian chờ phê duyệt:
1. Hãy soạn giúp Chuyên viên Vận hành & Đối soát Thanh toán 2 phương án giải trình rõ ràng, khách quan để trao đổi với khách hàng hoặc bộ phận thẩm định/kiểm soát.
2. Nêu rõ danh sách giấy tờ/thông tin cần bổ sung trong một lần duy nhất để khách hàng không phải đi lại nhiều lần.
```

## P05 · Lập danh mục rà soát chéo chống trả hồ sơ cho «Lập báo cáo tổng hợp SLA vận hành hàng tuần»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Lập báo cáo tổng hợp SLA vận hành hàng tuần
```text
Dành cho vị trí Chuyên viên Vận hành & Đối soát Thanh toán (Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP) trên Claude Pro: Để hồ sơ của công việc «Lập báo cáo tổng hợp SLA vận hành hàng tuần» đạt tỷ lệ duyệt ngay lần đầu (First-Time-Right):
1. Liệt kê 6 điểm mâu thuẫn thông tin thường khiến hồ sơ bị cấp kiểm soát trả về.
2. Tạo mẫu phiếu tự kiểm 1 phút để Chuyên viên Vận hành & Đối soát Thanh toán rà soát sự khớp đúng giữa các chứng từ trước khi trình ký.
```

## P06 · Tổng hợp nhật ký bàn giao cuối ngày cho «Lập báo cáo tổng hợp SLA vận hành hàng tuần»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Lập báo cáo tổng hợp SLA vận hành hàng tuần
```text
Cuối mỗi ca làm việc của Chuyên viên Vận hành & Đối soát Thanh toán (Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP), hãy giúp tôi tổng hợp kết quả thực hiện công việc «Lập báo cáo tổng hợp SLA vận hành hàng tuần» trên Claude Pro:
1. Phân loại các hồ sơ đã hoàn tất, hồ sơ đang chờ bổ sung và hồ sơ cần ưu tiên đầu giờ sáng hôm sau.
2. Viết ghi chú bàn giao ngắn gọn, rõ người nhận và mốc thời gian cam kết (không ghi thông tin cá nhân thật của khách).
```

## P07 · Đối soát giao dịch sao kê và hệ thống Core Banking (Chuyên viên Vận hành & Đối soát Thanh toán)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Chuyên viên Vận hành & Đối soát Thanh toán
- **Mục tiêu nghiệp vụ**: Đối soát giao dịch sao kê và hệ thống Core Banking
```text
[CHUYÊN MÔN CHUYÊN VIÊN VẬN HÀNH & ĐỐI SOÁT THANH TOÁN · NGHIỆP VỤ: Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP]
Bối cảnh: Tôi là Chuyên viên Vận hành & Đối soát Thanh toán, đang thực hiện tác vụ «Đối soát giao dịch sao kê và hệ thống Core Banking» (phát hiện các dòng lệch số tiền, lệch ngày giá trị hạch toán và phân loại nhóm nguyên nhân).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng Quy trình phân nhóm chênh lệch đối soát tự động và mẫu biên bản xử lý giao dịch treo, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Chuyên viên Vận hành & Đối soát Thanh toán, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P08 · Chuẩn hoá quy trình vận hành chuẩn SOP 10 mục (Chuyên viên Vận hành & Đối soát Thanh toán)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Chuyên viên Vận hành & Đối soát Thanh toán
- **Mục tiêu nghiệp vụ**: Chuẩn hoá quy trình vận hành chuẩn SOP 10 mục
```text
[CHUYÊN MÔN CHUYÊN VIÊN VẬN HÀNH & ĐỐI SOÁT THANH TOÁN · NGHIỆP VỤ: Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP]
Bối cảnh: Tôi là Chuyên viên Vận hành & Đối soát Thanh toán, đang thực hiện tác vụ «Chuẩn hoá quy trình vận hành chuẩn SOP 10 mục» (thiết kế bảng phân công trách nhiệm RACI, lưu đồ bước thực hiện và điểm kiểm soát bốn mắt).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng Khung chuẩn hoá tài liệu SOP nội bộ giúp nhân sự mới nắm bắt quy trình trong 3 ngày, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Chuyên viên Vận hành & Đối soát Thanh toán, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P09 · Kiểm soát hồ sơ giải ngân và phong toả tài sản bảo đảm (Chuyên viên Vận hành & Đối soát Thanh toán)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Chuyên viên Vận hành & Đối soát Thanh toán
- **Mục tiêu nghiệp vụ**: Kiểm soát hồ sơ giải ngân và phong toả tài sản bảo đảm
```text
[CHUYÊN MÔN CHUYÊN VIÊN VẬN HÀNH & ĐỐI SOÁT THANH TOÁN · NGHIỆP VỤ: Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP]
Bối cảnh: Tôi là Chuyên viên Vận hành & Đối soát Thanh toán, đang thực hiện tác vụ «Kiểm soát hồ sơ giải ngân và phong toả tài sản bảo đảm» (rà soát điều kiện tiên quyết, đăng ký giao dịch bảo đảm và hợp đồng bảo hiểm trước khi hạch toán).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng Bảng kiểm 10 điều kiện bắt buộc hoàn thành trước khi bấm nút giải ngân trên hệ thống, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Chuyên viên Vận hành & Đối soát Thanh toán, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P10 · Báo cáo sự cố vận hành và phân tích SLA (Chuyên viên Vận hành & Đối soát Thanh toán)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Chuyên viên Vận hành & Đối soát Thanh toán
- **Mục tiêu nghiệp vụ**: Báo cáo sự cố vận hành và phân tích SLA
```text
[CHUYÊN MÔN CHUYÊN VIÊN VẬN HÀNH & ĐỐI SOÁT THANH TOÁN · NGHIỆP VỤ: Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP]
Bối cảnh: Tôi là Chuyên viên Vận hành & Đối soát Thanh toán, đang thực hiện tác vụ «Báo cáo sự cố vận hành và phân tích SLA» (tổng hợp thời gian xử lý trung bình từng khâu và khoanh vùng điểm nghẽn vượt cam kết SLA).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng Mẫu báo cáo phân tích nguyên nhân gốc rễ (5 Whys) và kế hoạch khắc phục phòng ngừa, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Chuyên viên Vận hành & Đối soát Thanh toán, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P11 · Tự đánh giá ma trận rủi ro hoạt động RCSA (Chuyên viên Vận hành & Đối soát Thanh toán)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Chuyên viên Vận hành & Đối soát Thanh toán
- **Mục tiêu nghiệp vụ**: Tự đánh giá ma trận rủi ro hoạt động RCSA
```text
[CHUYÊN MÔN CHUYÊN VIÊN VẬN HÀNH & ĐỐI SOÁT THANH TOÁN · NGHIỆP VỤ: Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP]
Bối cảnh: Tôi là Chuyên viên Vận hành & Đối soát Thanh toán, đang thực hiện tác vụ «Tự đánh giá ma trận rủi ro hoạt động RCSA» (xác định điểm rủi ro tiềm ẩn, chốt kiểm soát phòng ngừa và tần suất kiểm tra định kỳ).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng Bảng ma trận Rủi ro × Mức độ ảnh hưởng kèm chỉ số rủi ro chính (KRI) cho bộ phận vận hành, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Chuyên viên Vận hành & Đối soát Thanh toán, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P12 · Đối chiếu quy định nội bộ với văn bản pháp quy mới (Chuyên viên Vận hành & Đối soát Thanh toán)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho Chuyên viên Vận hành & Đối soát Thanh toán
- **Mục tiêu nghiệp vụ**: Đối chiếu quy định nội bộ với văn bản pháp quy mới
```text
[CHUYÊN MÔN CHUYÊN VIÊN VẬN HÀNH & ĐỐI SOÁT THANH TOÁN · NGHIỆP VỤ: Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP]
Bối cảnh: Tôi là Chuyên viên Vận hành & Đối soát Thanh toán, đang thực hiện tác vụ «Đối chiếu quy định nội bộ với văn bản pháp quy mới» (lập bảng so sánh điều khoản thay đổi và gắn nhãn [CẦN XÁC MINH] cho các mục cần Pháp chế rà soát).
Công cụ sử dụng: Claude Pro.
Đầu ra yêu cầu: Hãy xây dựng Mẫu bảng đối chiếu Điểm cũ — Điểm mới — Tác động quy trình — Hành động cập nhật biểu mẫu, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của Chuyên viên Vận hành & Đối soát Thanh toán, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P13 · Soạn thư điện tử phối hợp xử lý nghiệp vụ chuẩn ngân hàng
- **Nhóm**: Nhóm C — Soạn thảo biểu mẫu & Tuân thủ quy trình
- **Mục tiêu nghiệp vụ**: Soạn thư điện tử phối hợp giải quyết công việc «đối soát chênh lệch sao kê ngân hàng và sổ phụ cuối ngày» trong mảng Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP
```text
Hãy soạn một thư điện tử trang trọng cho vị trí Chuyên viên Vận hành & Đối soát Thanh toán để phối hợp xử lý việc «đối soát chênh lệch sao kê ngân hàng và sổ phụ cuối ngày» (Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP) trên Claude Pro. Cấu trúc gồm: Tiêu đề chuẩn có mức độ ưu tiên, Bảng tóm tắt trạng thái hồ sơ ẩn danh, Đề xuất hướng xử lý và Thời hạn phản hồi SLA.
```

## P14 · Lập tờ trình nghiệp vụ có bảng đánh giá rủi ro
- **Nhóm**: Nhóm C — Soạn thảo biểu mẫu & Tuân thủ quy trình
- **Mục tiêu nghiệp vụ**: Soạn tờ trình đề xuất phương án xử lý cho Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP của vị trí Chuyên viên Vận hành & Đối soát Thanh toán
```text
Hãy lập khung Tờ trình nghiệp vụ dành cho Chuyên viên Vận hành & Đối soát Thanh toán phụ trách Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP (trọng tâm: «soạn thảo quy trình SOP 10 mục kèm lưu đồ và bảng RACI»). Bắt buộc có đủ 4 mục: Căn cứ thực hiện (gắn nhãn [CẦN XÁC MINH] số hiệu văn bản), Nội dung đề xuất, Bảng nhận diện rủi ro & Biện pháp kiểm soát Maker-Checker, và Kiến nghị phê duyệt.
```

## P15 · Đối chiếu quy trình tác nghiệp với văn bản quy định nội bộ
- **Nhóm**: Nhóm C — Soạn thảo biểu mẫu & Tuân thủ quy trình
- **Mục tiêu nghiệp vụ**: Rà soát quy trình «soạn thảo quy trình SOP 10 mục kèm lưu đồ và bảng RACI» của Chuyên viên Vận hành & Đối soát Thanh toán và đánh dấu [CẦN XÁC MINH] các căn cứ pháp lý
```text
Dựa trên bản mô tả các bước thực hiện «soạn thảo quy trình SOP 10 mục kèm lưu đồ và bảng RACI» của Chuyên viên Vận hành & Đối soát Thanh toán (Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP), hãy lập bảng đối chiếu gồm 4 cột: Bước thực hiện hiện tại — Rủi ro sai lệch — Điểm cần đối chiếu với quy định nội bộ [CẦN XÁC MINH] — Đề xuất chuẩn hoá.
```

## P16 · Rà soát chéo Maker-Checker phát hiện sai lệch số liệu
- **Nhóm**: Nhóm D — Kiểm soát Maker-Checker & Báo cáo tuần
- **Mục tiêu nghiệp vụ**: Kiểm tra chéo kết quả «lập báo cáo tổng hợp SLA vận hành hàng tuần» trong nghiệp vụ Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP
```text
Đóng vai Kiểm soát viên kiểm tra lại hồ sơ «lập báo cáo tổng hợp SLA vận hành hàng tuần» do Chuyên viên Vận hành & Đối soát Thanh toán (Nguyễn Đình Khoa) lập trong mảng Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP. Hãy chỉ ra các điểm cần đối chiếu số học, tính nhất quán giữa chữ và số, và các điều kiện phê duyệt còn thiếu.
```

## P17 · Tổng hợp báo cáo hiệu suất tuần từ nhật ký công việc
- **Nhóm**: Nhóm D — Kiểm soát Maker-Checker & Báo cáo tuần
- **Mục tiêu nghiệp vụ**: Tổng hợp kết quả công việc tuần cho vị trí Chuyên viên Vận hành & Đối soát Thanh toán phụ trách Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP
```text
Từ danh sách số lượng hồ sơ đã xử lý trong tuần của Nguyễn Đình Khoa (Chuyên viên Vận hành & Đối soát Thanh toán — Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP), hãy xuất bảng Báo cáo tuần gồm: Nhóm việc trọng tâm (Đối soát chênh lệch sao kê ngân hàng và sổ phụ cuối ngày; Soạn thảo quy trình SOP 10 mục kèm lưu đồ và bảng RACI; Lập báo cáo tổng hợp SLA vận hành hàng tuần), Khối lượng hoàn thành, Tỷ lệ đúng hạn SLA, Điểm nghẽn phát sinh và Đề xuất tuần tới.
```

## P18 · Tối ưu lại thư viện câu lệnh cá nhân sau mỗi tuần làm việc
- **Nhóm**: Nhóm D — Kiểm soát Maker-Checker & Báo cáo tuần
- **Mục tiêu nghiệp vụ**: Tinh chỉnh bộ câu lệnh Claude Pro cho 3 việc trọng tâm của Chuyên viên Vận hành & Đối soát Thanh toán
```text
Dựa trên kết quả sử dụng Claude Pro trong tuần qua cho 3 việc («Đối soát chênh lệch sao kê ngân hàng và sổ phụ cuối ngày», «Soạn thảo quy trình SOP 10 mục kèm lưu đồ và bảng RACI», «Lập báo cáo tổng hợp SLA vận hành hàng tuần») ở vị trí Chuyên viên Vận hành & Đối soát Thanh toán, hãy đề xuất cách rút gọn câu lệnh và bổ sung các ràng buộc đầu ra để kết quả tuần tới sát với biểu mẫu thực tế hơn.
```
