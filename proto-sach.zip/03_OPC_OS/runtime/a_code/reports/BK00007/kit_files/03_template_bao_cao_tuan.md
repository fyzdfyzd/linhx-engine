# MẪU 03: BÁO CÁO TUẦN & ĐỐI SOÁT HIỆU SUẤT (CHUYÊN VIÊN VẬN HÀNH & ĐỐI SOÁT THANH TOÁN)
> **Nhãn dữ liệu**: `[GIẢ LẬP]` · **Người báo cáo**: Nguyễn Đình Khoa (Chuyên viên Vận hành & Đối soát Thanh toán) · **Nghiệp vụ**: Hạch toán giải ngân, đối soát Core Banking và chuẩn hoá quy trình SOP

## 1. Bảng kết quả thực hiện trong tuần
| Nhóm công việc trọng tâm | Khối lượng hoàn thành | Tỷ lệ đúng hạn SLA | Thời gian tiết kiệm nhờ AI | Ghi chú kiểm soát |
|---|---|---|---|---|
| 1. Đối soát chênh lệch sao kê ngân hàng và sổ phụ cuối ngày | 18 hồ sơ / lượt | 100% | 3,5 giờ/tuần | Không phát sinh lỗi trả về |
| 2. Soạn thảo quy trình SOP 10 mục kèm lưu đồ và bảng RACI | 14 hồ sơ / lượt | 96% | 2,5 giờ/tuần | Đã rà soát chéo 100% |
| 3. Lập báo cáo tổng hợp SLA vận hành hàng tuần | 10 hồ sơ / lượt | 100% | 2,0 giờ/tuần | Đạt chuẩn tuân thủ |

## 2. Vấn đề tồn đọng & Đề xuất tuần tới
1. **Điểm nghẽn**: Thời gian chờ bổ sung chứng từ ở khâu `Soạn thảo quy trình SOP 10 mục kèm lưu đồ và bảng RACI` còn kéo dài vào cuối buổi chiều.
2. **Giải pháp tuần tới**: Áp dụng mẫu nhắc hồ sơ tự động từ đầu giờ sáng và rà soát danh mục `[CẦN XÁC MINH]` trước khi trình ký.
