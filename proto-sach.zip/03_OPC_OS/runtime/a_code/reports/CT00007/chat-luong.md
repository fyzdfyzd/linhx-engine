# Phiếu chất lượng: Bản đồ sao cá nhân · Phạm Thanh Hằng

**CHƯA ĐẠT**: 94.5/100 (ngưỡng 85), 1 lỗi, 1 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 7432 |
| so_doan_loi_giai | 105 |
| so_muc | 17 |
| muc_du_noi_dung | 16 |
| so_nguon | 7 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 25.7 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|
| Q12 | canh | 1 | 0.5 |
| Q02 | loi | 1 | 5.0 |

## Chi tiết (tối đa 60 dòng)

- [canh] Q12 @ goc-chieu#8: Câu 77 chữ — “Họ kết hợp chủ nghĩa lý tưởng với sự đổi mới, do vậy họ …”
- [loi] Q02 @ the-he#3: Đoạn bị cắt giữa câu — “… có lẽ sẽ là những người rất tân tiến và yêu chuộng tự do.”
