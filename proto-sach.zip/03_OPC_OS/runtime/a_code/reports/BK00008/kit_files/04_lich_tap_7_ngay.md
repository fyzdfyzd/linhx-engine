# LỊCH TẬP 7 NGÀY LÀM CHỦ BỘ CÔNG CỤ AI NGÂN HÀNG
> **Học viên**: Lý Mỹ Linh · **Vị trí**: RM Khách hàng Cá nhân · **Nghiệp vụ**: Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu · **Công cụ**: ChatGPT Plus

| Ngày | Mục tiêu rèn luyện (15 phút/ngày) | Prompt & Template áp dụng | Bài tập thực hành trên dữ liệu giả lập | Tiêu chí hoàn thành |
|---|---|---|---|---|
| **Ngày 1** | Thiết lập quy tắc ẩn danh dữ liệu & khung làm việc trên ChatGPT Plus | `P01`, `P02` | Thay toàn bộ tên thật, số CIF, CCCD bằng mã `KH_01` trước khi thử việc `Soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần` | 0% dữ liệu thật đưa lên AI |
| **Ngày 2** | Tự động hoá việc tốn giờ #1: `Soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần` | `P01`, `P02`, `Mẫu 01 Email` | Tạo bảng kiểm 5 bước và bản nháp email phối hợp trong 3 phút | Giảm 50% thời gian soạn thảo |
| **Ngày 3** | Tự động hoá việc tốn giờ #2: `Chuẩn bị danh mục hồ sơ chứng minh thu nhập cho khách vay` | `P03`, `P04`, `Mẫu 02 Tờ trình` | Lập khung tờ trình có cột Maker-Checker và nhãn `[CẦN XÁC MINH]` | Đủ 4 mục chuẩn tờ trình |
| **Ngày 4** | Tự động hoá việc tốn giờ #3: `Tổng hợp phễu khách hàng tiềm năng trong tuần` | `P05`, `P06` | Rà soát lỗi số liệu và lập danh sách điểm kiểm soát rủi ro | Bắt được 3 điểm rủi ro |
| **Ngày 5** | Ứng dụng bộ câu lệnh chuyên sâu cho `RM Khách hàng Cá nhân` | `P07` đến `P12` | Thực hành kịch bản chuyên môn `Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu` trên 2 tình huống giả định | Hoàn thành 2 hồ sơ mẫu |
| **Ngày 6** | Rà soát tuân thủ & chuẩn hoá SOP nội bộ | `P13`, `P14`, `P15` | Kiểm tra chéo quy trình với văn bản nội bộ, gắn cờ `[CẦN XÁC MINH]` | Không tự bịa số hiệu thông tư |
| **Ngày 7** | Tổng kết hiệu suất tuần & tinh chỉnh thư viện cá nhân | `P16`, `P17`, `P18`, `Mẫu 03 Báo cáo tuần` | Xuất báo cáo tuần từ nhật ký công việc và lưu 5 câu lệnh dùng nhiều nhất | Tiết kiệm ≥ 5 giờ làm việc/tuần |
