# BỘ 18 PROMPT AI CÁ NHÂN HOÁ DÀNH RIÊNG CHO LÝ MỸ LINH (RM KHÁCH HÀNG CÁ NHÂN)
> **Nhãn**: `[GIẢ LẬP]` · **Vị trí**: RM Khách hàng Cá nhân · **Nghiệp vụ chính**: Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu · **Công cụ AI**: ChatGPT Plus
> **3 việc tốn giờ nhất đã cá nhân hoá**: (1) Soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần · (2) Chuẩn bị danh mục hồ sơ chứng minh thu nhập cho khách vay · (3) Tổng hợp phễu khách hàng tiềm năng trong tuần

## P01 · Thiết kế bảng kiểm 5 bước & điểm chặn sai sót cho «Soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần
```text
Đóng vai Chuyên gia Kiểm soát Chất lượng mảng Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu, hãy giúp tôi chuẩn hoá công việc «Soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần» của vị trí RM Khách hàng Cá nhân trên ChatGPT Plus:
1. Tách quy trình thực hiện thành 5 bước tuần tự kèm thời gian định mức (SLA) cho từng bước.
2. Xác định 3 lỗi sai số liệu hoặc thiếu chứng từ thường gặp nhất ở khâu «Soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần» và cách chặn từ đầu.
3. Thiết kế 1 bảng kiểm đối chiếu nhanh (Maker-Checker) trước khi chuyển hồ sơ sang bộ phận tiếp theo (chỉ dùng dữ liệu ẩn danh [GIẢ LẬP]).
```

## P02 · Soạn thảo văn bản & thông điệp chuẩn mực cho «Soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần
```text
Trên công cụ ChatGPT Plus, từ dữ kiện nghiệp vụ đã che tên thật và số tài khoản dưới đây về việc «Soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần» (Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu):
1. Soạn 1 bản văn bản hành chính ngân hàng ngắn gọn (nêu rõ mục đích, danh mục hồ sơ đính kèm, thời hạn phản hồi).
2. Viết thêm 1 phiên bản tóm tắt 4 dòng để báo cáo nhanh qua nhóm điều phối nội bộ.
3. Đánh dấu [CẦN XÁC MINH] tại mọi vị trí cần điền mã biểu mẫu hoặc số hiệu quy định nội bộ.
```

## P03 · Rút ngắn 50% thời gian phân tích dữ kiện trong «Chuẩn bị danh mục hồ sơ chứng minh thu nhập cho khách vay»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Chuẩn bị danh mục hồ sơ chứng minh thu nhập cho khách vay
```text
Tôi là RM Khách hàng Cá nhân phụ trách Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu. Công việc «Chuẩn bị danh mục hồ sơ chứng minh thu nhập cho khách vay» đang chiếm nhiều thời gian xử lý thủ công mỗi ngày.
Hãy hướng dẫn tôi sử dụng ChatGPT Plus để:
1. Chuyển dữ liệu thô đã ẩn danh của việc «Chuẩn bị danh mục hồ sơ chứng minh thu nhập cho khách vay» thành bảng tổng hợp có cấu trúc gồm: Hạng mục, Dữ kiện chính, Điểm bất thường và Đề xuất xử lý.
2. Chỉ ra những tiêu chí nào máy có thể lọc sơ bộ và tiêu chí nào RM Khách hàng Cá nhân bắt buộc phải tự kiểm tra bằng mắt.
```

## P04 · Kịch bản giải trình & tháo gỡ vướng mắc khi thực hiện «Chuẩn bị danh mục hồ sơ chứng minh thu nhập cho khách vay»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Chuẩn bị danh mục hồ sơ chứng minh thu nhập cho khách vay
```text
Khi xử lý «Chuẩn bị danh mục hồ sơ chứng minh thu nhập cho khách vay» trong nghiệp vụ Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu, nếu phát sinh vướng mắc về hồ sơ hoặc thời gian chờ phê duyệt:
1. Hãy soạn giúp RM Khách hàng Cá nhân 2 phương án giải trình rõ ràng, khách quan để trao đổi với khách hàng hoặc bộ phận thẩm định/kiểm soát.
2. Nêu rõ danh sách giấy tờ/thông tin cần bổ sung trong một lần duy nhất để khách hàng không phải đi lại nhiều lần.
```

## P05 · Lập danh mục rà soát chéo chống trả hồ sơ cho «Tổng hợp phễu khách hàng tiềm năng trong tuần»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Tổng hợp phễu khách hàng tiềm năng trong tuần
```text
Dành cho vị trí RM Khách hàng Cá nhân (Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu) trên ChatGPT Plus: Để hồ sơ của công việc «Tổng hợp phễu khách hàng tiềm năng trong tuần» đạt tỷ lệ duyệt ngay lần đầu (First-Time-Right):
1. Liệt kê 6 điểm mâu thuẫn thông tin thường khiến hồ sơ bị cấp kiểm soát trả về.
2. Tạo mẫu phiếu tự kiểm 1 phút để RM Khách hàng Cá nhân rà soát sự khớp đúng giữa các chứng từ trước khi trình ký.
```

## P06 · Tổng hợp nhật ký bàn giao cuối ngày cho «Tổng hợp phễu khách hàng tiềm năng trong tuần»
- **Nhóm**: Nhóm A — Giải quyết 3 việc tốn giờ nhất hằng ngày
- **Mục tiêu nghiệp vụ**: Tổng hợp phễu khách hàng tiềm năng trong tuần
```text
Cuối mỗi ca làm việc của RM Khách hàng Cá nhân (Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu), hãy giúp tôi tổng hợp kết quả thực hiện công việc «Tổng hợp phễu khách hàng tiềm năng trong tuần» trên ChatGPT Plus:
1. Phân loại các hồ sơ đã hoàn tất, hồ sơ đang chờ bổ sung và hồ sơ cần ưu tiên đầu giờ sáng hôm sau.
2. Viết ghi chú bàn giao ngắn gọn, rõ người nhận và mốc thời gian cam kết (không ghi thông tin cá nhân thật của khách).
```

## P07 · Khai thác nhu cầu vốn lưu động & bảo lãnh (RM Khách hàng Cá nhân)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho RM Khách hàng Cá nhân
- **Mục tiêu nghiệp vụ**: Khai thác nhu cầu vốn lưu động & bảo lãnh
```text
[CHUYÊN MÔN RM KHÁCH HÀNG CÁ NHÂN · NGHIỆP VỤ: Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu]
Bối cảnh: Tôi là RM Khách hàng Cá nhân, đang thực hiện tác vụ «Khai thác nhu cầu vốn lưu động & bảo lãnh» (chuẩn bị bộ câu hỏi khảo sát vòng quay hàng tồn kho, công nợ phải thu và nhu cầu bảo lãnh dự thầu trước buổi gặp doanh nghiệp).
Công cụ sử dụng: ChatGPT Plus.
Đầu ra yêu cầu: Hãy xây dựng Bảng 10 câu hỏi phỏng vấn Giám đốc Tài chính (CFO) doanh nghiệp SME kèm chỉ số tài chính cần thu thập, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của RM Khách hàng Cá nhân, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P08 · Thuyết minh cấu trúc hạn mức tín dụng (RM Khách hàng Cá nhân)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho RM Khách hàng Cá nhân
- **Mục tiêu nghiệp vụ**: Thuyết minh cấu trúc hạn mức tín dụng
```text
[CHUYÊN MÔN RM KHÁCH HÀNG CÁ NHÂN · NGHIỆP VỤ: Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu]
Bối cảnh: Tôi là RM Khách hàng Cá nhân, đang thực hiện tác vụ «Thuyết minh cấu trúc hạn mức tín dụng» (tóm tắt phương án tài trợ thương mại, chiết khấu bộ chứng từ và cơ cấu tài sản bảo đảm).
Công cụ sử dụng: ChatGPT Plus.
Đầu ra yêu cầu: Hãy xây dựng Khung thuyết minh 4 phần trình Hội đồng Tín dụng làm rõ nguồn trả nợ thứ nhất và thứ hai, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của RM Khách hàng Cá nhân, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P09 · Chăm sóc sau giải ngân & bán chéo CASA (RM Khách hàng Cá nhân)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho RM Khách hàng Cá nhân
- **Mục tiêu nghiệp vụ**: Chăm sóc sau giải ngân & bán chéo CASA
```text
[CHUYÊN MÔN RM KHÁCH HÀNG CÁ NHÂN · NGHIỆP VỤ: Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu]
Bối cảnh: Tôi là RM Khách hàng Cá nhân, đang thực hiện tác vụ «Chăm sóc sau giải ngân & bán chéo CASA» (thiết kế kịch bản mời doanh nghiệp sử dụng gói chi lương tự động, thu hộ QR và tiền gửi kỳ hạn ngắn).
Công cụ sử dụng: ChatGPT Plus.
Đầu ra yêu cầu: Hãy xây dựng Kịch bản tư vấn 3 phương án tối ưu dòng tiền nhàn rỗi giúp tăng tỷ lệ CASA tại đơn vị, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của RM Khách hàng Cá nhân, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P10 · Xử lý từ chối về lãi suất vay (RM Khách hàng Cá nhân)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho RM Khách hàng Cá nhân
- **Mục tiêu nghiệp vụ**: Xử lý từ chối về lãi suất vay
```text
[CHUYÊN MÔN RM KHÁCH HÀNG CÁ NHÂN · NGHIỆP VỤ: Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu]
Bối cảnh: Tôi là RM Khách hàng Cá nhân, đang thực hiện tác vụ «Xử lý từ chối về lãi suất vay» (soạn bảng đối chiếu tổng chi phí vốn thực tế, tốc độ giải ngân và tiện ích ngân hàng số).
Công cụ sử dụng: ChatGPT Plus.
Đầu ra yêu cầu: Hãy xây dựng Ma trận 5 tình huống khách hàng so sánh lãi suất và cách phản hồi dựa trên giá trị tổng thể, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của RM Khách hàng Cá nhân, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P11 · Rà soát hồ sơ pháp lý doanh nghiệp (RM Khách hàng Cá nhân)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho RM Khách hàng Cá nhân
- **Mục tiêu nghiệp vụ**: Rà soát hồ sơ pháp lý doanh nghiệp
```text
[CHUYÊN MÔN RM KHÁCH HÀNG CÁ NHÂN · NGHIỆP VỤ: Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu]
Bối cảnh: Tôi là RM Khách hàng Cá nhân, đang thực hiện tác vụ «Rà soát hồ sơ pháp lý doanh nghiệp» (kiểm tra danh mục giấy phép đăng ký kinh doanh, điều lệ công ty, biên bản họp HĐTV và tờ khai thuế).
Công cụ sử dụng: ChatGPT Plus.
Đầu ra yêu cầu: Hãy xây dựng Bảng kiểm đối chiếu tính hợp lệ của đại diện pháp luật và thẩm quyền ký kết hợp đồng tín dụng, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của RM Khách hàng Cá nhân, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P12 · Chuẩn bị kịch bản tiếp cận khách hàng mới (RM Khách hàng Cá nhân)
- **Nhóm**: Nhóm B — Nghiệp vụ chuyên sâu cho RM Khách hàng Cá nhân
- **Mục tiêu nghiệp vụ**: Chuẩn bị kịch bản tiếp cận khách hàng mới
```text
[CHUYÊN MÔN RM KHÁCH HÀNG CÁ NHÂN · NGHIỆP VỤ: Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu]
Bối cảnh: Tôi là RM Khách hàng Cá nhân, đang thực hiện tác vụ «Chuẩn bị kịch bản tiếp cận khách hàng mới» (viết lời giới thiệu giải pháp tài chính chuyên biệt theo ngành sản xuất, thương mại hoặc xuất nhập khẩu).
Công cụ sử dụng: ChatGPT Plus.
Đầu ra yêu cầu: Hãy xây dựng 3 mẫu mở đầu cuộc gọi và tin nhắn hẹn gặp theo đặc thù dòng tiền từng ngành, trong đó:
- Mọi thông tin định danh khách hàng (tên, CIF, CCCD, số tài khoản) đều thay bằng mã ẩn danh [GIẢ LẬP].
- Ghi rõ bước thực hiện của RM Khách hàng Cá nhân, điểm kiểm soát của cấp phê duyệt và thời gian xử lý tiêu chuẩn.
```

## P13 · Soạn thư điện tử phối hợp xử lý nghiệp vụ chuẩn ngân hàng
- **Nhóm**: Nhóm C — Soạn thảo biểu mẫu & Tuân thủ quy trình
- **Mục tiêu nghiệp vụ**: Soạn thư điện tử phối hợp giải quyết công việc «soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần» trong mảng Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu
```text
Hãy soạn một thư điện tử trang trọng cho vị trí RM Khách hàng Cá nhân để phối hợp xử lý việc «soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần» (Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu) trên ChatGPT Plus. Cấu trúc gồm: Tiêu đề chuẩn có mức độ ưu tiên, Bảng tóm tắt trạng thái hồ sơ ẩn danh, Đề xuất hướng xử lý và Thời hạn phản hồi SLA.
```

## P14 · Lập tờ trình nghiệp vụ có bảng đánh giá rủi ro
- **Nhóm**: Nhóm C — Soạn thảo biểu mẫu & Tuân thủ quy trình
- **Mục tiêu nghiệp vụ**: Soạn tờ trình đề xuất phương án xử lý cho Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu của vị trí RM Khách hàng Cá nhân
```text
Hãy lập khung Tờ trình nghiệp vụ dành cho RM Khách hàng Cá nhân phụ trách Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu (trọng tâm: «chuẩn bị danh mục hồ sơ chứng minh thu nhập cho khách vay»). Bắt buộc có đủ 4 mục: Căn cứ thực hiện (gắn nhãn [CẦN XÁC MINH] số hiệu văn bản), Nội dung đề xuất, Bảng nhận diện rủi ro & Biện pháp kiểm soát Maker-Checker, và Kiến nghị phê duyệt.
```

## P15 · Đối chiếu quy trình tác nghiệp với văn bản quy định nội bộ
- **Nhóm**: Nhóm C — Soạn thảo biểu mẫu & Tuân thủ quy trình
- **Mục tiêu nghiệp vụ**: Rà soát quy trình «chuẩn bị danh mục hồ sơ chứng minh thu nhập cho khách vay» của RM Khách hàng Cá nhân và đánh dấu [CẦN XÁC MINH] các căn cứ pháp lý
```text
Dựa trên bản mô tả các bước thực hiện «chuẩn bị danh mục hồ sơ chứng minh thu nhập cho khách vay» của RM Khách hàng Cá nhân (Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu), hãy lập bảng đối chiếu gồm 4 cột: Bước thực hiện hiện tại — Rủi ro sai lệch — Điểm cần đối chiếu với quy định nội bộ [CẦN XÁC MINH] — Đề xuất chuẩn hoá.
```

## P16 · Rà soát chéo Maker-Checker phát hiện sai lệch số liệu
- **Nhóm**: Nhóm D — Kiểm soát Maker-Checker & Báo cáo tuần
- **Mục tiêu nghiệp vụ**: Kiểm tra chéo kết quả «tổng hợp phễu khách hàng tiềm năng trong tuần» trong nghiệp vụ Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu
```text
Đóng vai Kiểm soát viên kiểm tra lại hồ sơ «tổng hợp phễu khách hàng tiềm năng trong tuần» do RM Khách hàng Cá nhân (Lý Mỹ Linh) lập trong mảng Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu. Hãy chỉ ra các điểm cần đối chiếu số học, tính nhất quán giữa chữ và số, và các điều kiện phê duyệt còn thiếu.
```

## P17 · Tổng hợp báo cáo hiệu suất tuần từ nhật ký công việc
- **Nhóm**: Nhóm D — Kiểm soát Maker-Checker & Báo cáo tuần
- **Mục tiêu nghiệp vụ**: Tổng hợp kết quả công việc tuần cho vị trí RM Khách hàng Cá nhân phụ trách Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu
```text
Từ danh sách số lượng hồ sơ đã xử lý trong tuần của Lý Mỹ Linh (RM Khách hàng Cá nhân — Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu), hãy xuất bảng Báo cáo tuần gồm: Nhóm việc trọng tâm (Soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần; Chuẩn bị danh mục hồ sơ chứng minh thu nhập cho khách vay; Tổng hợp phễu khách hàng tiềm năng trong tuần), Khối lượng hoàn thành, Tỷ lệ đúng hạn SLA, Điểm nghẽn phát sinh và Đề xuất tuần tới.
```

## P18 · Tối ưu lại thư viện câu lệnh cá nhân sau mỗi tuần làm việc
- **Nhóm**: Nhóm D — Kiểm soát Maker-Checker & Báo cáo tuần
- **Mục tiêu nghiệp vụ**: Tinh chỉnh bộ câu lệnh ChatGPT Plus cho 3 việc trọng tâm của RM Khách hàng Cá nhân
```text
Dựa trên kết quả sử dụng ChatGPT Plus trong tuần qua cho 3 việc («Soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần», «Chuẩn bị danh mục hồ sơ chứng minh thu nhập cho khách vay», «Tổng hợp phễu khách hàng tiềm năng trong tuần») ở vị trí RM Khách hàng Cá nhân, hãy đề xuất cách rút gọn câu lệnh và bổ sung các ràng buộc đầu ra để kết quả tuần tới sát với biểu mẫu thực tế hơn.
```
