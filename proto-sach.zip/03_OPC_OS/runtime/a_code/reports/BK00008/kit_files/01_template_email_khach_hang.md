# MẪU 01: EMAIL GIAO DỊCH & PHỐI HỢP NGHIỆP VỤ (RM KHÁCH HÀNG CÁ NHÂN)
> **Nhãn dữ liệu**: `[GIẢ LẬP]` · **Người sử dụng**: Lý Mỹ Linh (RM Khách hàng Cá nhân) · **Nghiệp vụ**: Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu

## 1. Cấu trúc tiêu đề chuẩn
`[Mã đơn vị] - [Mức độ ưu tiên] - V/v: Phối hợp xử lý soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần (Mã hồ sơ ẩn danh: HS-XXXX)`

## 2. Nội dung biểu mẫu
Kính gửi: Anh/Chị `[Tên người nhận / Bộ phận phối hợp]`,

Căn cứ quy trình thực hiện nghiệp vụ **Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu** (`[CẦN XÁC MINH mã quy trình nội bộ]`), tôi xin gửi thông tin tổng hợp liên quan đến công việc **Soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần** như sau:

| Hạng mục kiểm tra | Nội dung tóm tắt (Đã ẩn danh PII) | Trạng thái chứng từ | Cam kết SLA |
|---|---|---|---|
| Hồ sơ pháp lý / Giao dịch | Đã đối chiếu bản gốc tại đơn vị | Đạt yêu cầu | Trong 30 phút |
| Nội dung cần phối hợp | Xác nhận bước kiểm soát đối với soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần | Đang chờ duyệt | Trước 15:00 hôm nay |
| Điểm kiểm soát rủi ro | Đã qua bước kiểm tra sơ bộ của RM Khách hàng Cá nhân | Đã ký kiểm soát | Đúng hạn |

Kính đề nghị Anh/Chị xem xét và phản hồi trước `[Giờ/Ngày]` để đảm bảo tiến độ cam kết với khách hàng.

Trân trọng,
**Lý Mỹ Linh** — RM Khách hàng Cá nhân
