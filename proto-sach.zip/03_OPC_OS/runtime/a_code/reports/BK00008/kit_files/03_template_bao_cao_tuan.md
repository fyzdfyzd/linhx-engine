# MẪU 03: BÁO CÁO TUẦN & ĐỐI SOÁT HIỆU SUẤT (RM KHÁCH HÀNG CÁ NHÂN)
> **Nhãn dữ liệu**: `[GIẢ LẬP]` · **Người báo cáo**: Lý Mỹ Linh (RM Khách hàng Cá nhân) · **Nghiệp vụ**: Tư vấn vay mua nhà, mở thẻ tín dụng và chăm sóc khách hàng hiện hữu

## 1. Bảng kết quả thực hiện trong tuần
| Nhóm công việc trọng tâm | Khối lượng hoàn thành | Tỷ lệ đúng hạn SLA | Thời gian tiết kiệm nhờ AI | Ghi chú kiểm soát |
|---|---|---|---|---|
| 1. Soạn tin nhắn tư vấn phương án trả góp gốc lãi giảm dần | 18 hồ sơ / lượt | 100% | 3,5 giờ/tuần | Không phát sinh lỗi trả về |
| 2. Chuẩn bị danh mục hồ sơ chứng minh thu nhập cho khách vay | 14 hồ sơ / lượt | 96% | 2,5 giờ/tuần | Đã rà soát chéo 100% |
| 3. Tổng hợp phễu khách hàng tiềm năng trong tuần | 10 hồ sơ / lượt | 100% | 2,0 giờ/tuần | Đạt chuẩn tuân thủ |

## 2. Vấn đề tồn đọng & Đề xuất tuần tới
1. **Điểm nghẽn**: Thời gian chờ bổ sung chứng từ ở khâu `Chuẩn bị danh mục hồ sơ chứng minh thu nhập cho khách vay` còn kéo dài vào cuối buổi chiều.
2. **Giải pháp tuần tới**: Áp dụng mẫu nhắc hồ sơ tự động từ đầu giờ sáng và rà soát danh mục `[CẦN XÁC MINH]` trước khi trình ký.
