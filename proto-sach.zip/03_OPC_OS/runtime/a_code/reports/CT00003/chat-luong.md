# Phiếu chất lượng: Bản đồ sao cá nhân · Lê Hoàng Nam

**ĐẠT**: 99.3/100 (ngưỡng 85), 0 lỗi, 2 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 7512 |
| so_doan_loi_giai | 99 |
| so_muc | 17 |
| muc_du_noi_dung | 16 |
| so_nguon | 8 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 25.6 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|
| Q15 | canh | 1 | 0.2 |
| Q12 | canh | 1 | 0.5 |

## Chi tiết (tối đa 60 dòng)

- [canh] Q15 @ mat-trang#7: Khoảng trắng thừa quanh dấu câu — “Hoàng Nam khá nhạy cảm, thậm chí sẽ có khả năng tâm linh. Ngoài …”
- [canh] Q12 @ goc-chieu#12: Câu 77 chữ — “Họ kết hợp chủ nghĩa lý tưởng với sự đổi mới, do vậy họ …”
