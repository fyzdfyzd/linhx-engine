# Phiếu chất lượng: Bản đồ sao cá nhân · Nguyễn Thảo Vy

**CHƯA ĐẠT**: 83.6/100 (ngưỡng 85), 2 lỗi, 4 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 7397 |
| so_doan_loi_giai | 91 |
| so_muc | 17 |
| muc_du_noi_dung | 16 |
| so_nguon | 8 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 23.9 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|
| Q15 | canh | 2 | 0.4 |
| Q01 | loi | 1 | 10.0 |
| Q09 | canh | 1 | 0.5 |
| Q12 | canh | 1 | 0.5 |
| Q02 | loi | 1 | 5.0 |

## Chi tiết (tối đa 60 dòng)

- [canh] Q15 @ tom-tat#4: Khoảng trắng thừa quanh dấu câu — “Cung ẩn (cung trội): Bảo Bình: Người có tính Bảo Bình trội có nhu …”
- [loi] Q01 @ sao-kim#5: Còn biến chưa thay: ~ — “Người có Sao Kim ở cung Song Tử là các cá nhân hòa đồng, …”
- [canh] Q15 @ cung-an#2: Khoảng trắng thừa quanh dấu câu — “Người có tính Bảo Bình trội có nhu cầu thể hiện cá tính và …”
- [canh] Q09 @ the-he#5: Từ nặng nề: “chết”, nên viết lại nhẹ hơn
- [canh] Q12 @ cung-an#6: Câu 63 chữ — “Ngôi sao này đặc trưng cho thuyết vị lai, chủ nghĩa nhân đạo, tài …”
- [loi] Q02 @ the-he#3: Đoạn bị cắt giữa câu — “… Có lẽ bạn sẽ cần được dạy cách trao và nhận sự tự do.”
