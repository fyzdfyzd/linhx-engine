# Phiếu chất lượng: Bản đồ sao cá nhân · Ngô Minh Tuấn

**ĐẠT**: 95.0/100 (ngưỡng 85), 0 lỗi, 4 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 4975 |
| so_doan_loi_giai | 62 |
| so_muc | 12 |
| muc_du_noi_dung | 11 |
| so_nguon | 6 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 24.4 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|
| Q05 | canh | 2 | 4.0 |
| Q09 | canh | 1 | 0.5 |
| Q12 | canh | 1 | 0.5 |

## Chi tiết (tối đa 60 dòng)

- [canh] Q05 @ mat-trang: Mục 242 chữ, dưới 250
- [canh] Q05 @ sao-moc: Mục 65 chữ, dưới 120
- [canh] Q09 @ mat-troi#2: Từ nặng nề: “bất hạnh”, nên viết lại nhẹ hơn
- [canh] Q12 @ mat-troi#8: Câu 69 chữ — “Với tính cách dễ xúc động và trí tưởng tưởng phong phú, bạn có …”
