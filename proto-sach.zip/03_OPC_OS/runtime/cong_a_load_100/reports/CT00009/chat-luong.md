# Phiếu chất lượng: Bản đồ sao cá nhân · Khách Hàng Kiểm Tải 009

**CHƯA ĐẠT**: 94.5/100 (ngưỡng 85), 1 lỗi, 1 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 7081 |
| so_doan_loi_giai | 94 |
| so_muc | 17 |
| muc_du_noi_dung | 16 |
| so_nguon | 7 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 23.7 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|
| Q09 | canh | 1 | 0.5 |
| Q02 | loi | 1 | 5.0 |

## Chi tiết (tối đa 60 dòng)

- [canh] Q09 @ the-he#5: Từ nặng nề: “chết”, nên viết lại nhẹ hơn
- [loi] Q02 @ the-he#3: Đoạn bị cắt giữa câu — “… Có lẽ bạn sẽ cần được dạy cách trao và nhận sự tự do.”
