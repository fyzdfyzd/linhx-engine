# Phiếu chất lượng: Bản đồ sao cá nhân · Khách Hàng Kiểm Tải 008

**ĐẠT**: 99.5/100 (ngưỡng 85), 0 lỗi, 1 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 7041 |
| so_doan_loi_giai | 100 |
| so_muc | 17 |
| muc_du_noi_dung | 16 |
| so_nguon | 8 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 24.6 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|
| Q12 | canh | 1 | 0.5 |

## Chi tiết (tối đa 60 dòng)

- [canh] Q12 @ sao-tho#1: Câu 62 chữ — “Với bạn, sự an toàn về vật chất rất quan trọng và vị thế …”
