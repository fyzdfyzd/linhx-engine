# Phiếu chất lượng: Bản đồ sao cá nhân · Khách Hàng Kiểm Tải 002

**ĐẠT**: 95.6/100 (ngưỡng 85), 0 lỗi, 7 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 8407 |
| so_doan_loi_giai | 106 |
| so_muc | 17 |
| muc_du_noi_dung | 16 |
| so_nguon | 8 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 24.6 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|
| Q05 | canh | 1 | 2.0 |
| Q15 | canh | 2 | 0.4 |
| Q09 | canh | 1 | 0.5 |
| Q12 | canh | 3 | 1.5 |

## Chi tiết (tối đa 60 dòng)

- [canh] Q05 @ sao-moc: Mục 110 chữ, dưới 120
- [canh] Q15 @ tom-tat#4: Khoảng trắng thừa quanh dấu câu — “Cung ẩn (cung trội): Bảo Bình: Người có tính Bảo Bình trội có nhu …”
- [canh] Q09 @ mat-troi#2: Từ nặng nề: “bất hạnh”, nên viết lại nhẹ hơn
- [canh] Q15 @ cung-an#2: Khoảng trắng thừa quanh dấu câu — “Người có tính Bảo Bình trội có nhu cầu thể hiện cá tính và …”
- [canh] Q12 @ mat-troi#8: Câu 69 chữ — “Với tính cách dễ xúc động và trí tưởng tưởng phong phú, bạn có …”
- [canh] Q12 @ goc-chieu#2: Câu 67 chữ — “Tuy nhiên với những khó khăn tự nhận thức có thể được thuyên giảm, …”
- [canh] Q12 @ goc-chieu#10: Câu 77 chữ — “Họ kết hợp chủ nghĩa lý tưởng với sự đổi mới, do vậy họ …”
