# Phiếu chất lượng: Bản đồ sao cá nhân · Khách Hàng Kiểm Tải 010

**ĐẠT**: 100.0/100 (ngưỡng 85), 0 lỗi, 0 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 7322 |
| so_doan_loi_giai | 96 |
| so_muc | 17 |
| muc_du_noi_dung | 16 |
| so_nguon | 7 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 24.7 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|

## Chi tiết (tối đa 60 dòng)

