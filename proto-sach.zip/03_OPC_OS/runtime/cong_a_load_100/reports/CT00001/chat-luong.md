# Phiếu chất lượng: Bản đồ sao cá nhân · Khách Hàng Kiểm Tải 001

**ĐẠT**: 97.5/100 (ngưỡng 85), 0 lỗi, 2 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 7364 |
| so_doan_loi_giai | 100 |
| so_muc | 17 |
| muc_du_noi_dung | 16 |
| so_nguon | 8 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 24.1 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|
| Q05 | canh | 1 | 2.0 |
| Q12 | canh | 1 | 0.5 |

## Chi tiết (tối đa 60 dòng)

- [canh] Q05 @ sao-moc: Mục 110 chữ, dưới 120
- [canh] Q12 @ mat-troi#10: Câu 66 chữ — “Nếu cảm thấy đôi giầy không thoải mái, bạn có thể sẽ đi chân …”
