# Phiếu chất lượng: Bản đồ sao cá nhân · Khách Hàng Kiểm Tải 004

**CHƯA ĐẠT**: 89.6/100 (ngưỡng 85), 1 lỗi, 2 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 6749 |
| so_doan_loi_giai | 90 |
| so_muc | 17 |
| muc_du_noi_dung | 16 |
| so_nguon | 7 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 24.3 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|
| Q15 | canh | 2 | 0.4 |
| Q01 | loi | 1 | 10.0 |

## Chi tiết (tối đa 60 dòng)

- [canh] Q15 @ tom-tat#4: Khoảng trắng thừa quanh dấu câu — “Cung ẩn (cung trội): Song Ngư: Người có tính Song Ngư trội thường rất …”
- [loi] Q01 @ sao-kim#5: Còn biến chưa thay: ~ — “Người có Sao Kim ở cung Song Tử là các cá nhân hòa đồng, …”
- [canh] Q15 @ cung-an#3: Khoảng trắng thừa quanh dấu câu — “Nhưng một mặt khác, người trội tính Song Ngư cũng có tính Linh hoạt …”
