# Phiếu chất lượng: Bản đồ sao cá nhân · Khách Hàng Kiểm Tải 003

**ĐẠT**: 99.8/100 (ngưỡng 85), 0 lỗi, 1 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 7206 |
| so_doan_loi_giai | 96 |
| so_muc | 17 |
| muc_du_noi_dung | 16 |
| so_nguon | 8 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 23.6 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|
| Q15 | canh | 1 | 0.2 |

## Chi tiết (tối đa 60 dòng)

- [canh] Q15 @ mat-trang#8: Khoảng trắng thừa quanh dấu câu — “003 khá nhạy cảm, thậm chí sẽ có khả năng tâm linh. Ngoài ra, …”
