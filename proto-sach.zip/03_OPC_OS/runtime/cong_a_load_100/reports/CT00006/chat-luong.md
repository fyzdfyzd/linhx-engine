# Phiếu chất lượng: Bản đồ sao cá nhân · Khách Hàng Kiểm Tải 006

**CHƯA ĐẠT**: 82.5/100 (ngưỡng 85), 2 lỗi, 2 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 7300 |
| so_doan_loi_giai | 91 |
| so_muc | 17 |
| muc_du_noi_dung | 16 |
| so_nguon | 8 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 24.2 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|
| Q05 | canh | 1 | 2.0 |
| Q01 | loi | 1 | 10.0 |
| Q02 | loi | 1 | 5.0 |
| Q12 | canh | 1 | 0.5 |

## Chi tiết (tối đa 60 dòng)

- [canh] Q05 @ sao-moc: Mục 107 chữ, dưới 120
- [loi] Q01 @ sao-kim#5: Còn biến chưa thay: ~ — “Người có Sao Kim ở cung Song Tử là các cá nhân hòa đồng, …”
- [loi] Q02 @ mat-troi#3: Đoạn bị cắt giữa câu — “… đã nói về việc 006 "hay có tâm trạng, nhút nhát và hay khóc":”
- [canh] Q12 @ sao-thuy#5: Câu 67 chữ — “Ví dụ, nếu bạn có tình yêu âm nhạc và có năng khiếu, thì …”
