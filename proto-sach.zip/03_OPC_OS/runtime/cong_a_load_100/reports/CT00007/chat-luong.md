# Phiếu chất lượng: Bản đồ sao cá nhân · Khách Hàng Kiểm Tải 007

**ĐẠT**: 99.5/100 (ngưỡng 85), 0 lỗi, 1 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 7221 |
| so_doan_loi_giai | 98 |
| so_muc | 17 |
| muc_du_noi_dung | 16 |
| so_nguon | 7 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 25.1 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|
| Q12 | canh | 1 | 0.5 |

## Chi tiết (tối đa 60 dòng)

- [canh] Q12 @ goc-chieu#12: Câu 67 chữ — “Tuy nhiên với những khó khăn tự nhận thức có thể được thuyên giảm, …”
