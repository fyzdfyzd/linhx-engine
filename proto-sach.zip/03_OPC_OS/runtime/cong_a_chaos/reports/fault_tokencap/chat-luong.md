# Phiếu chất lượng: Bản đồ sao cá nhân · Lê Thu Hà

**CHƯA ĐẠT**: 85.3/100 (ngưỡng 85), 2 lỗi, 4 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 4786 |
| so_doan_loi_giai | 60 |
| so_muc | 12 |
| muc_du_noi_dung | 11 |
| so_nguon | 5 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 24.4 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|
| Q05 | canh | 2 | 4.0 |
| Q15 | canh | 1 | 0.2 |
| Q02 | loi | 2 | 10.0 |
| Q12 | canh | 1 | 0.5 |

## Chi tiết (tối đa 60 dòng)

- [canh] Q05 @ mat-trang: Mục 244 chữ, dưới 250
- [canh] Q05 @ sao-moc: Mục 107 chữ, dưới 120
- [canh] Q15 @ nguyen-to#10: Khoảng trắng thừa quanh dấu câu — “(+) Hà là người ít giao du với người ngoài cũng như xã hội. …”
- [loi] Q02 @ mat-troi#3: Đoạn bị cắt giữa câu — “… đã nói về việc Hà "hay có tâm trạng, nhút nhát và hay khóc":”
- [canh] Q12 @ sao-thuy#5: Câu 67 chữ — “Ví dụ, nếu bạn có tình yêu âm nhạc và có năng khiếu, thì …”
- [loi] Q02 @ sao-kim#1: Đoạn bị cắt giữa câu — “… nên sẽ không nghi ngờ gì việc bạn sẽ tích cóp từng chút một.”
