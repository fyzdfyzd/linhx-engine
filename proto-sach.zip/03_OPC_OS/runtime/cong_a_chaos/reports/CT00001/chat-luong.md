# Phiếu chất lượng: Bản đồ sao cá nhân · Đặng Quốc Bảo

**ĐẠT**: 97.0/100 (ngưỡng 85), 0 lỗi, 3 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 6819 |
| so_doan_loi_giai | 90 |
| so_muc | 17 |
| muc_du_noi_dung | 16 |
| so_nguon | 7 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 24.3 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|
| Q05 | canh | 1 | 2.0 |
| Q12 | canh | 2 | 1.0 |

## Chi tiết (tối đa 60 dòng)

- [canh] Q05 @ sao-moc: Mục 100 chữ, dưới 120
- [canh] Q12 @ sao-thuy#5: Câu 67 chữ — “Ví dụ, nếu bạn có tình yêu âm nhạc và có năng khiếu, thì …”
- [canh] Q12 @ goc-chieu#16: Câu 77 chữ — “Họ kết hợp chủ nghĩa lý tưởng với sự đổi mới, do vậy họ …”
