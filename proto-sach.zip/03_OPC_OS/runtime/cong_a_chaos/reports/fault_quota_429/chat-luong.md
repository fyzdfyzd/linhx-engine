# Phiếu chất lượng: Bản đồ sao cá nhân · Nguyễn Minh Quân

**CHƯA ĐẠT**: 92.5/100 (ngưỡng 85), 1 lỗi, 2 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 7341 |
| so_doan_loi_giai | 95 |
| so_muc | 17 |
| muc_du_noi_dung | 16 |
| so_nguon | 7 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 23.1 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|
| Q05 | canh | 1 | 2.0 |
| Q09 | canh | 1 | 0.5 |
| Q02 | loi | 1 | 5.0 |

## Chi tiết (tối đa 60 dòng)

- [canh] Q05 @ sao-moc: Mục 96 chữ, dưới 120
- [canh] Q09 @ the-he#5: Từ nặng nề: “chết”, nên viết lại nhẹ hơn
- [loi] Q02 @ the-he#3: Đoạn bị cắt giữa câu — “… Có lẽ bạn sẽ cần được dạy cách trao và nhận sự tự do.”
