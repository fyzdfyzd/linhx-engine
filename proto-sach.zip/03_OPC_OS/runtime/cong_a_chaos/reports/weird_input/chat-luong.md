# Phiếu chất lượng: Bản đồ sao cá nhân · Nguyễn AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

**ĐẠT**: 97.5/100 (ngưỡng 85), 0 lỗi, 2 cảnh báo.

| Chỉ số | Giá trị |
|---|---|
| so_chu | 4241 |
| so_doan_loi_giai | 53 |
| so_muc | 12 |
| muc_du_noi_dung | 11 |
| so_nguon | 6 |
| thuc_the_thieu_loi_giai | 0 |
| chu_trung_binh_moi_cau | 26.2 |

## Theo luật

| Luật | Mức | Số lần | Trừ điểm |
|---|---|---|---|
| Q05 | canh | 1 | 2.0 |
| Q12 | canh | 1 | 0.5 |

## Chi tiết (tối đa 60 dòng)

- [canh] Q05 @ sao-moc: Mục 78 chữ, dưới 120
- [canh] Q12 @ goc-chieu#14: Câu 77 chữ — “Họ kết hợp chủ nghĩa lý tưởng với sự đổi mới, do vậy họ …”
