# Biên Bản Kiểm Thử E2E & Kiểm Toán Thị Giác — Vòng 1 (`E2E-ROUND-1.md`)

> **Thời gian**: 2026-10-25 14:23:59 · **Điểm Reviewer Khó Tính Vòng 1**: **`5.00 / 10.0`** (`CHƯA ĐẠT >= 9.2 — Cần sửa lỗi sang Vòng 2`)  
> **File dữ liệu kiểm toán**: [`reports/round1-audit.json`](file:///D:/LINHX/PROTO/03_OPC_OS/reports/round1-audit.json)  
> **Thư mục ảnh chụp màn hình Vòng 1**: [`reports/screens/round1/`](file:///D:/LINHX/PROTO/03_OPC_OS/reports/screens/round1/)

---

## 1. Kết Quả Soi Trực Tiếp Ảnh Chụp Màn Hình Vòng 1 (`read_file` Visual Audit)

Qua việc mở xem trực tiếp các ảnh chụp màn hình thực tế bằng Playwright Chromium (`1440×900`, `full_page=True`):
- [`01_dashboard_3_opcs.png`](file:///D:/LINHX/PROTO/03_OPC_OS/reports/screens/round1/01_dashboard_3_opcs.png): Bố cục 3 OPC và thanh cảnh báo đỏ `401,332,000 VNĐ` hiển thị rõ, tuy nhiên thanh điều hướng trên cùng dùng `position: sticky` và trang thiếu thẻ ngữ nghĩa `<main>`.
- [`04_store_opc2_bank.png`](file:///D:/LINHX/PROTO/03_OPC_OS/reports/screens/round1/04_store_opc2_bank.png): Các ô nhập liệu của Form đặt mua đang hiển thị chuỗi placeholder giả lập thô (`[Dữ liệu mẫu ten]`, `[Dữ liệu mẫu vi_tri]`) thay vì nhãn tiếng Việt có dấu và dữ liệu nghiệp vụ thật; form mới chỉ chuyển hướng tĩnh sang đơn mẫu chứ chưa gọi API tạo đơn trực tiếp.
- [`07_order_bk00001.png`](file:///D:/LINHX/PROTO/03_OPC_OS/reports/screens/round1/07_order_bk00001.png): **Phát hiện 2 lỗi thị giác lớn chỉ thấy khi mở ảnh `.png`**:
  1. Thanh điều hướng trên cùng bị bóp nghẹt vào khung `body { max-width: 860px }` của trang đơn hàng khiến các nút menu bị gãy thành 3 dòng rất xấu.
  2. Khung `<embed type="application/pdf">` trên Chromium headless (và các trình duyệt di động không có PDF plugin) hiện hộp đen `"Couldn't load plugin."` thay vì hiển thị nội dung báo cáo trực tiếp trên trang.

---

## 2. Danh Sách Lỗi Phát Hiện Ở Vòng 1 (`REV-R1-*`)

| Mã lỗi | Mức độ | Trang bị ảnh hưởng | Mô tả lỗi cụ thể | Hướng xử lý cho Vòng 2 |
|---|---|---|---|---|
| `REV-R1-PDF-EMBED-PLUGIN` | **HIGH** | `order_*.html` (Cả 3 OPC) | Thẻ `<embed type="application/pdf">` hiện `"Couldn't load plugin."` trên trình duyệt không bật PDF plugin, và đường dẫn kiểm tra tài nguyên đang trỏ nhầm `/runtime/multi_opc/reports/` thay vì `/runtime/a_code/reports/`. | Nhúng trực tiếp bản báo cáo (`bao-cao.html`) trong khung xem trực tiếp trên trang đơn kèm nút chuyển đổi / tải `bao-cao.pdf` và `bo_cong_cu_*.zip`, đồng thời đồng bộ thư mục `reports` vào `runtime/multi_opc/reports/`. |
| `REV-R1-NAV-SQUEEZED` | **MEDIUM** | `order_*.html` & Toàn bộ 8 trang | Thanh điều hướng dùng `position: sticky` và trên trang đơn bị bó trong `body { max-width: 860px }` làm gãy dòng menu. | Đổi sang `position: relative`, tách `body { margin: 0 }` trên trang đơn để thanh điều hướng rộng toàn màn hình `100%`, nội dung đơn đặt trong `<main class="order-main">`. |
| `REV-R1-STORE-STATIC-FORM` | **MEDIUM** | `/store/opc001..003` | Ô input của Form đặt mua hiển thị `[Dữ liệu mẫu vi_tri]` kém tự nhiên và chưa có endpoint `/api/create-demo-order` xử lý tạo đơn trực tiếp. | Thay bằng nhãn tiếng Việt chuẩn + dữ liệu điền sẵn chân thực cho từng OPC và thêm endpoint `/api/create-demo-order` trên `server_ui.py`. |
| `REV-R1-A11Y-LANDMARKS` | **LOW** | Toàn bộ 8 trang | Thiếu thẻ ngữ nghĩa `<main role="main">` và `.skip-link`. | Bổ sung `<main role="main">` cho Dashboard, trang A/B, Storefront và Trang đơn. |
