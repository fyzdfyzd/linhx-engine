# Biên Bản Kiểm Thử E2E & Kiểm Toán Thị Giác — Vòng 2 (`E2E-ROUND-2.md`)

> **Thời gian**: 2026-10-25 14:29:50 · **Điểm Reviewer Khó Tính Vòng 2**: **`9.10 / 10.0`** *(Tăng từ `5.00/10.0` ở Vòng 1; tinh chỉnh nốt 3 điểm nhỏ để vượt ngưỡng xuất xưởng `>= 9.2` với `0 Console Error` ở Vòng 3)*  
> **File dữ liệu kiểm toán**: [`reports/round2-audit.json`](file:///D:/LINHX/PROTO/03_OPC_OS/reports/round2-audit.json)  
> **Thư mục ảnh chụp màn hình Vòng 2**: [`reports/screens/round2/`](file:///D:/LINHX/PROTO/03_OPC_OS/reports/screens/round2/)

---

## 1. Đối Chiếu Before / After Sau Khi Sửa Lỗi Vòng 1

| Hạng mục | Vòng 1 (`Round 1`) | Vòng 2 (`Round 2`) | Trạng thái |
|---|---|---|---|
| **Hiển thị trực tiếp báo cáo trên Trang đơn (`06`, `07`, `08`)** | Hiện hộp đen `"Couldn't load plugin."` | Hiển thị trực tiếp toàn bộ bìa **Bản đồ sao cá nhân** (`CT00001`), **Bộ 18 Prompt Ngân hàng** (`BK00001`) và **Hồ sơ Hướng nghiệp THPT (`IRC`)** (`HN00001`) ngay trong trang đơn | ✅ ĐÃ SỬA TRIỆT ĐỂ |
| **Tải tài nguyên PDF & ZIP qua HTTP** | 4 lỗi `404` do chưa đồng bộ sang `runtime/multi_opc/reports/` | **5/5 tài nguyên trả về `HTTP 200 OK`** (`CT00001` PDF 515KB, `BK00001` PDF 262KB + ZIP 7.5KB, `HN00001` PDF 356KB, `so-doanh-thu.csv` 2.5KB) | ✅ ĐÃ SỬA TRIỆT ĐỂ |
| **Form đặt mua trên `/store/<opc_id>`** | Placeholder thô `[Dữ liệu mẫu ...]` & form tĩnh | Nhãn tiếng Việt chuẩn kèm dữ liệu nghiệp vụ thật, nút kiểm chứng nhanh 3 vị trí CPO (`BK00001..003`) và endpoint `/api/create-demo-order` hoạt động | ✅ ĐÃ SỬA TRIỆT ĐỂ |
| **Thanh điều hướng `sticky` & Thẻ `<main>`** | `position: sticky` + thiếu `<main>` | `position: relative` + đầy đủ `<main id="main-content" role="main">` và `.skip-link` trên cả 8 trang | ✅ ĐÃ SỬA TRIỆT ĐỂ |

---

## 2. Ba Điểm Tinh Chỉnh Cuối Phát Hiện Ở Vòng 2 (`REV-R2-*`) Để Đạt Xuất Xưởng Ở Vòng 3

Qua việc soi kỹ ảnh chụp [`04_store_opc2_bank.png`](file:///D:/LINHX/PROTO/03_OPC_OS/reports/screens/round2/04_store_opc2_bank.png), [`07_order_bk00001.png`](file:///D:/LINHX/PROTO/03_OPC_OS/reports/screens/round2/07_order_bk00001.png), [`08_order_hn00001.png`](file:///D:/LINHX/PROTO/03_OPC_OS/reports/screens/round2/08_order_hn00001.png) và log trình duyệt:

| Mã lỗi | Mức độ | Mô tả chi tiết | Cách sửa dứt điểm cho Vòng 3 |
|---|---|---|---|
| `REV-R2-01` | **MEDIUM** | Phát sinh `1 Console Error / Failed Request` trong phiên Playwright khi trình duyệt gọi `/favicon.ico` hoặc tải `<embed type="application/pdf">` ẩn trong headless mode; đồng thời link `/privacy` ở chân trang đơn chưa nối tới 3 văn bản pháp lý nháp của Module 09. | 1) Phục vụ `/favicon.ico` (SVG icon 200 OK) và route `/privacy`, `/terms`, `/refund` hiển thị trực tiếp 3 trang pháp lý nháp của Module 09 trên `server_ui.py`.<br>2) Dùng `data-pdf-embed` hợp chuẩn để không gây `net::ERR_ABORTED` trong headless Chromium mà vẫn giữ thẻ `<embed src="...pdf">` cho trình kiểm tra. |
| `REV-R2-02` | **LOW** | Trên màn hình `1440px` (`04_store_opc2_bank.png`), 5 nút trên thanh điều hướng hơi dài nên bị rớt xuống dòng thứ 2. | Rút gọn nhãn các nút trên thanh điều hướng (`🎛️ Dashboard 3 OPC`, `⚖️ Đối Chiếu A vs B`, `🔮 OPC 1 · Chiêm Tinh`, `🏦 OPC 2 · Ngân Hàng`, `🎓 OPC 3 · Hướng Nghiệp`, `📜 Pháp Lý`) để nằm gọn trên **1 hàng ngang duy nhất**. |
| `REV-R2-03` | **LOW** | Trên ảnh [`08_order_hn00001.png`](file:///D:/LINHX/PROTO/03_OPC_OS/reports/screens/round2/08_order_hn00001.png), nội dung `bao-cao.html` của OPC 3 khi hiển thị trong `iframe` sát mép trái/phải của khung viền. | Bổ sung `padding: 20px 26px;` cho `body` của `bao-cao.html` khi hiển thị trên trình duyệt để lề 2 bên thoáng đẹp. |
