# Báo Cáo Kiểm Thử E2E & Đánh Giá Reviewer Khó Tính — Vòng 2 (Round 2)

- **Thời gian**: `2026-10-25T07:36:08.768107+00:00`
- **Điểm số Reviewer Khó Tính**: **9.3 / 10.0**
- **Số ảnh chụp màn hình**: `7`
- **Số lỗi Console trình duyệt**: `0`
- **Số vấn đề phát hiện**: `1`

## 1. Danh sách ảnh chụp màn hình thực tế (`reports/screens/round2/`)
- `01-hub-desktop-all.png`: `D:\LINHX\PROTO\01_MAY_TAO_NOI_DUNG\reports\screens\round2\01-hub-desktop-all.png`
- `02-hub-filter-report.png`: `D:\LINHX\PROTO\01_MAY_TAO_NOI_DUNG\reports\screens\round2\02-hub-filter-report.png`
- `03-hub-mobile-390x844.png`: `D:\LINHX\PROTO\01_MAY_TAO_NOI_DUNG\reports\screens\round2\03-hub-mobile-390x844.png`
- `04-bai-viet-publication.png`: `D:\LINHX\PROTO\01_MAY_TAO_NOI_DUNG\reports\screens\round2\04-bai-viet-publication.png`
- `05-report-a4-publication.png`: `D:\LINHX\PROTO\01_MAY_TAO_NOI_DUNG\reports\screens\round2\05-report-a4-publication.png`
- `06-course-slide-deck.png`: `D:\LINHX\PROTO\01_MAY_TAO_NOI_DUNG\reports\screens\round2\06-course-slide-deck.png`
- `07-onbrand-pixel-report.png`: `D:\LINHX\PROTO\01_MAY_TAO_NOI_DUNG\reports\screens\round2\07-onbrand-pixel-report.png`

## 2. Kết quả kiểm toán DOM & Thị giác trên từng kịch bản
- **01_hub_desktop**: `13` thẻ bài chạy, `maxCardChars = 130` (trần `<= 200`), `brokenImgs = 0`, `smallTapTargets = 0`.
- **02_hub_filter_report**: Lọc đúng `4` bài `report_mau`, mở chi tiết `Báo cáo mẫu: Kiểm toán Rủi ro Shadow AI và Khung Quản trị Dữ liệu Hai Lớp cho Doanh nghiệp vừa và nhỏ Việt Nam 2026`.
- **03_hub_mobile (390x844)**: `fixedFooter = False`, `hasSkipLink = True`, `hasLegendBar = True`.
- **04_bai_viet_publication (`BAI_04`)**: `brokenImgs = 0`, `validSvgs = 2`, `rawMarkdownBoldCount = 0`, `h2Count = 3`.
- **05_report_a4_publication (`BAI_08`)**: `brokenImgs = 0`, `validSvgs = 2`, `rawMarkdownBoldCount = 0`.
- **06_course_slide_deck (`BAI_11`)**: `brokenImgs = 0`, `validSvgs = 2`.
- **07_onbrand_pixel_report (`BAI_01`)**: `brokenImgs = 0`.

## 3. Danh sách phát hiện & hướng khắc phục cho vòng tiếp theo
- **[REV-R2-03] (HIGH) `05-report-a4-publication.png, 06-course-slide-deck.png`**: Hộp `.callout-leaf` của Report `BAI_08` (Shadow AI) và tiêu đề Slide 02/04 của `BAI_11` (Buổi 02) vẫn dùng câu chữ cố định của `BAI_02`/`BAI_03` thay vì trích xuất động từ đề tài và biểu đồ `H01`/`H02` của từng bài.
  - *Cách sửa*: Cập nhật `media_hoa.py` để lấy động tiêu đề `exhibits_map[0]['tieu_de']`, `exhibits_map[1]['tieu_de']` và câu mở đầu của từng bài đưa vào `.callout-leaf`, `.photo-caption` và tiêu đề Slide 02/04.
