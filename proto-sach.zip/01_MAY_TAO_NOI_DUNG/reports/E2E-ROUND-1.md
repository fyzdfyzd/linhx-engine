# Báo Cáo Kiểm Thử E2E & Đánh Giá Reviewer Khó Tính — Vòng 1 (Round 1)

- **Thời gian**: `2026-10-25T07:30:21.728107+00:00`
- **Điểm số Reviewer Khó Tính**: **7.1 / 10.0**
- **Số ảnh chụp màn hình**: `7`
- **Số lỗi Console trình duyệt**: `14`
- **Số vấn đề phát hiện**: `4`

## 1. Danh sách ảnh chụp màn hình thực tế (`reports/screens/round1/`)
- `01-hub-desktop-all.png`: `D:\LINHX\PROTO\01_MAY_TAO_NOI_DUNG\reports\screens\round1\01-hub-desktop-all.png`
- `02-hub-filter-report.png`: `D:\LINHX\PROTO\01_MAY_TAO_NOI_DUNG\reports\screens\round1\02-hub-filter-report.png`
- `03-hub-mobile-390x844.png`: `D:\LINHX\PROTO\01_MAY_TAO_NOI_DUNG\reports\screens\round1\03-hub-mobile-390x844.png`
- `04-bai-viet-publication.png`: `D:\LINHX\PROTO\01_MAY_TAO_NOI_DUNG\reports\screens\round1\04-bai-viet-publication.png`
- `05-report-a4-publication.png`: `D:\LINHX\PROTO\01_MAY_TAO_NOI_DUNG\reports\screens\round1\05-report-a4-publication.png`
- `06-course-slide-deck.png`: `D:\LINHX\PROTO\01_MAY_TAO_NOI_DUNG\reports\screens\round1\06-course-slide-deck.png`
- `07-onbrand-pixel-report.png`: `D:\LINHX\PROTO\01_MAY_TAO_NOI_DUNG\reports\screens\round1\07-onbrand-pixel-report.png`

## 2. Kết quả kiểm toán DOM & Thị giác trên từng kịch bản
- **01_hub_desktop**: `13` thẻ bài chạy, `maxCardChars = 130` (trần `<= 200`), `brokenImgs = 2`, `smallTapTargets = 7`.
- **02_hub_filter_report**: Lọc đúng `4` bài `report_mau`, mở chi tiết `Báo cáo mẫu: Kiểm toán Rủi ro Shadow AI và Khung Quản trị Dữ liệu Hai Lớp cho Doanh nghiệp vừa và nhỏ Việt Nam 2026`.
- **03_hub_mobile (390x844)**: `fixedFooter = True`, `hasSkipLink = False`, `hasLegendBar = False`.
- **04_bai_viet_publication (`BAI_04`)**: `brokenImgs = 3`, `validSvgs = 2`, `rawMarkdownBoldCount = 0`, `h2Count = 0`.
- **05_report_a4_publication (`BAI_08`)**: `brokenImgs = 2`, `validSvgs = 2`, `rawMarkdownBoldCount = 0`.
- **06_course_slide_deck (`BAI_11`)**: `brokenImgs = 2`, `validSvgs = 2`.
- **07_onbrand_pixel_report (`BAI_01`)**: `brokenImgs = 0`.

## 3. Danh sách phát hiện & hướng khắc phục cho vòng tiếp theo
- **[REV-R1-01] (CRITICAL) `04-bai-viet-publication.png, 05-report-a4-publication.png, 06-course-slide-deck.png`**: Phát hiện 9 ảnh bị vỡ (`naturalWidth == 0`) khi mở qua HTTP server do `media_hoa.py` nhúng đường dẫn tuyệt đối `file:///D:/...` thay vì đường dẫn tương đối (`./...`), bị trình duyệt chặn (`Not allowed to load local resource`).
  - *Cách sửa*: Sửa `skills/BM2_M2_media_hoa/media_hoa.py` dùng đường dẫn tương đối (`./agy_anh_goc_sakedemy.jpg`, `./05-xuat/sakedemy_banner_1920x600.png`, `./05-xuat/sakedemy_social_1080x1080.png`) và tái xuất HTML/PDF cho cả 13 bài.
- **[REV-R1-02] (HIGH) `04-bai-viet-publication.png, 05-report-a4-publication.png`**: Trang đọc HTML hiển thị nguyên dấu sao Markdown `**...**` (0 vị trí) và bỏ qua toàn bộ tiêu đề mục `##` (`h2Count = 0`).
  - *Cách sửa*: Bổ sung bộ chuyển đổi Markdown sang HTML (`<h2>`, `<strong>`, bảng `<table>`) trong `skills/BM2_M2_media_hoa/media_hoa.py` trước khi kết xuất HTML và PDF.
- **[REV-R1-03] (HIGH) `05-report-a4-publication.png, 06-course-slide-deck.png`**: Hộp `.callout-leaf` của Report `BAI_08` (Shadow AI) và tiêu đề Slide 02/04 của `BAI_11` (Buổi 02) vẫn dùng câu chữ cố định của `BAI_02`/`BAI_03` thay vì trích xuất động từ đề tài và biểu đồ `H01`/`H02` của từng bài.
  - *Cách sửa*: Cập nhật `media_hoa.py` để lấy động tiêu đề `exhibits_map[0]['tieu_de']`, `exhibits_map[1]['tieu_de']` và câu mở đầu của từng bài đưa vào `.callout-leaf`, `.photo-caption` và tiêu đề Slide 02/04.
- **[REV-R1-04] (MEDIUM) `01-hub-desktop-all.png, 03-hub-mobile-390x844.png`**: Giao diện Web QA Hub có `fixedFooter=True` đè lên nội dung khi chụp full_page, `smallTapTargets=7` nút bấm nhỏ hơn 32px, `hasSkipLink=False`, `hasLegendBar=False`.
  - *Cách sửa*: Chuyển `footer.app-footer` sang `position: relative; margin-top: auto;`, tăng kích thước nút `.filter-btn`/`.action-link` lên `min-height: 36px`, bổ sung `.skip-link` WCAG và thanh chú giải `.legend-bar`.
