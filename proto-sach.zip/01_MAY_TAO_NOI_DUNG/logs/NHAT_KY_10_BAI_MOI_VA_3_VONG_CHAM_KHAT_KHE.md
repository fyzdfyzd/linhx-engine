# NHẬT KÝ MỞ RỘNG 10 BÀI MỚI (TỔNG 13 BÀI) & 3 VÒNG CHẤM KHẮT KHE 5 TẦNG (`cham_khat_khe.py`)

- **Dự án / Prototype**: `D:\LINHX\PROTO\01_MAY_TAO_NOI_DUNG\`
- **Mã phiên Handoff**: `S-20261025-1149-proto01-may-tao-noi-dung`
- **Thời gian hoàn tất**: `2026-10-25 14:10`
- **Script kiểm định khắt khe**: `scripts/cham_khat_khe.py`
- **File JSON kết quả từng vòng**:
  - Vòng 1: `logs/cham_khat_khe_vong_1.json` (`0/13 PASS` — bắt sống lỗi độ dài câu, lỗi từ sáo tầng học `kiem_van_dich.py` và sót nhãn `[GIẢ LẬP]`/`[BCxx]` ở bản sạch `09b`)
  - Vòng 2: `logs/cham_khat_khe_vong_2.json` (`100%` bài đạt `kiem_van_dich.py = 100/100`, phát hiện thư mục test tạm gây trùng 4-gram và 8 bài còn nhỉnh nhẹ `cau_tb` ở `37.1–44.2`)
  - Vòng 3: `logs/cham_khat_khe_vong_3.json` (**`13/13 PASS (100%)`** — `0` lỗi cứng, `0%` câu hai vế, `100/100` điểm không văn dịch, `97.0–98.2` điểm `CQS`, `99.0/100` điểm Onbrand pixel CIEDE2000, tương đồng 4-gram tối đa giữa 78 cặp bài chỉ `1.60%`)

---

## 1. Bảng So Sánh Tiêu Chí: Chuẩn Mức 1 Thông Thường vs Bộ Chấm Khắt Khe 5 Tầng (`cham_khat_khe.py`)

| Cổng kiểm định | Chuẩn Mức 1 Thông Thường (`verify.py`) | Chuẩn Khắt Khe 5 Tầng (`cham_khat_khe.py`) |
|---|---|---|
| **G1. Cú pháp & Nhịp câu (`cham_cau.py`)** | `cau_tb` trong `[19.0, 39.0]`, `ti_le_hai_ve <= 5%`, `ti_le_cau_dai >= 10%` | `cau_tb` ép hẹp trong **`[21.5, 36.8]`**, **`ti_le_hai_ve == 0.0%`** (cấm tuyệt đối câu hai vế), `ti_le_cau_dai >= 14%`, `0` chữ số Ả Rập trong dòng văn xuôi (trừ năm `2025`, `2026`) |
| **G2. Khử Văn Dịch & Từ Sáo Tinh Vi** | `kiem_van_dich.py >= 90/100`, `CQS >= 85.0`, `APS <= 25.0` | **`kiem_van_dich.py == 100/100`** (`0` lỗi gốc + `0` lỗi tần suất học), quét thêm **25 cụm từ sáo AI tinh vi** (`== 0`), **`CQS >= 94.0`**, **`APS <= 10.0`**, độ tăng `CQS(B09) - CQS(B07) >= +20.0` |
| **G3. Kiểm Toán Bằng Chứng (`soat-su-that`)** | Có gắn mã nguồn `[Nxx]` | `100%` câu văn ở Bước 08 gắn mã `[N01]..[N15]` hoặc `[GIẢ LẬP]`, đối chiếu tồn tại thật trong `03_bang_chung.json`; bản sạch `09b` gỡ sạch `100%` ngoặc vuông `[...]` |
| **G4. Chống Đạo Văn Nội Bộ Giữa 13 Bài** | Không kiểm chéo giữa các bài | Đối chiếu **78 cặp bài (`13 × 12 / 2`)**: độ tương đồng **Jaccard 4-gram `< 8.0%`** (thực tế đạt **`1.60%`**), `0` câu văn trùng lặp giữa bất kỳ 2 bài nào |
| **G5. Thị Giác Onbrand Pixel & Đa Phương Tiện** | `onbrand.py >= 80.0/100`, đủ file bước | Đủ 15 file bước (`01..09`, `09b`, `M1..M5`), ảnh gốc AGY `> 500 KB`, 2 biểu đồ `H01.svg`/`H02.svg` (`LAB028/hinh.py` + `Be Vietnam Pro`), **`onbrand.py >= 98.5/100`**, độ phủ màu thương hiệu `>= 92%` (thực tế **`100.0%`**), PDF màu `> 30 KB`, `LAB066 >= 8.0/10` |

---

## 2. Nhật Ký Thực Thi 3 Vòng Chấm Khắt Khe & Sửa Lỗi Thực Chất

### Vòng 1 (`cham_khat_khe_vong_1.json`) — Khởi tạo 10 bài mới & Quét bẫy lần đầu
- **Hành động**:
  1. Thu thập thêm 3 lô bằng chứng thực tế qua **AGY `search_web`** (Rủi ro rò rỉ dữ liệu Shadow AI 2025–2026; Benchmark ROI AI khối Kinh doanh & CSKH; Hiện tượng mất trí nhớ tổ chức & mất sắc thái khi lạm dụng tóm tắt AI) cập nhật vào `du_lieu_tham_chieu_agy.json`.
  2. Gọi **AGY Subagent `image-generator`** (`conversationId: ea0b3721-a111-43b2-a615-bf032235a101`) sinh mới 3 ảnh chụp thực tế bối cảnh doanh nghiệp/lớp học Việt Nam chuẩn Sakedemy (`agy_data_governance.jpg`, `agy_sales_cs_roi.jpg`, `agy_editorial_lab.jpg` — nâng tổng kho `assets_agy/` lên 6 ảnh gốc).
  3. Chạy `cham_khat_khe.py --gen-10 --grade --round 1` sinh trọn vẹn 10 bài mới (`BAI_04`..`BAI_13`) và chấm khắt khe cả 13 bài.
- **Phát hiện của Bộ chấm khắt khe ở Vòng 1 (`0/13 PASS` — lưu vết tại `[VD-009]`)**:
  1. **`[G1-DoDaiCau]` & `[G1-ChamCau]`**: Văn bản Bước 08 của 10 bài mới có nhiều câu ghép dài `55–68` từ, đẩy `cau_tb` lên `57.6 – 68.4` từ/câu (vượt trần `39.0` của `cham_cau.py` và trần khắt khe `36.8`). Riêng bài gốc `thue-thoi-gian-don-rac-ai` đạt `cau_tb = 38.1` (đạt chuẩn thường `<= 39.0` nhưng vượt trần khắt khe `36.8`).
  2. **`[G2-VanDich]`**: Bắt trúng các cụm từ dịch thuật và cụm lặp tần suất cao của `kiem_van_dich.py`: `'cốt lõi'` (`BAI_04`, `BAI_13`), `'một cách vô'` (`BAI_06`), `'không phải là ... mà là'` (`BAI_07`), `'một cách diễn'` (`BAI_13`), `'trước khi'` lặp 2–3 lần (`BAI_02`, `BAI_03`, `BAI_10`, `BAI_12`), `'câu hỏi'` lặp 2 lần (`BAI_06`, `BAI_11`), `'trả lời'` lặp 2 lần (`BAI_09`), `'cuối cùng'` lặp 3 lần (`BAI_13`), và 1 câu dính cờ `hai-vế` (`còn`) ở `BAI_11`.
  3. **`[G3-BanSach]`**: Lệnh `cham_cau.py --sach` của `LAB049` chỉ gỡ `[N01]`, `[T01]` và `[GIẢ LẬP: ...]`, nhưng chưa gỡ nhãn `[GIẢ LẬP]` đứng độc lập không có dấu hai chấm và chưa gỡ mã `[BC01]` trong bảng của `report_mau`.
  4. **`[G5-File]`**: Tên file `M1..M4` trong hàm kiểm tra đang gõ lệch so với tên chuẩn do `chu_trinh_template.py` xuất ra (`M1_phan_tich_yeu_cau_template.md`, `M2_tham_chieu_va_luat_onbrand.md`, `M3_ba_phuong_an_template.md`, `M4_cham_chon_template_onbrand.md`).

### Vòng 2 (`cham_khat_khe_vong_2.json`) — Khử 100% lỗi văn dịch, Vá bộ lọc bản sạch `09b` & Bắt thư mục test tạm
- **Hành động sửa**:
  1. Bổ sung hậu xử lý regex trong `dieu_phoi.py` ngay sau `cham_cau.py --sach` để gỡ triệt để mọi nhãn `[GIẢ LẬP]` và `[BCxx]` còn sót trong `09b_ban_sach_khong_ma_nguon.md`.
  2. Thay thế toàn bộ cụm từ bị `kiem_van_dich.py` bắt ở cả 13 bài; xóa bỏ hoàn toàn cấu trúc câu hai vế ở `BAI_11` (`ti_le_hai_ve` toàn bộ 13 bài về `0.0%`).
  3. Tách câu đợt 1 cho 10 bài mới trong `scripts/kho_10_bai_moi.py` và bài gốc trong `scripts/noi_dung_3_loai.py`.
- **Phát hiện của Bộ chấm khắt khe ở Vòng 2 (`[VD-010]`)**:
  1. **100% bài đạt `kiem_van_dich.py = 100/100`**, `hai_ve = 0.0%`, `Onbrand CLI = 99.0/100 (100% phủ màu)`, `[G3-BanSach] = PASS`, `[G5-File] = PASS`.
  2. **`[G4-TrungLap4Gram]`**: Phát hiện trong `runs/` còn tồn tại 2 thư mục sinh tạm từ bài test giao kèo trước đó (`2026-10-25_bai_viet_run-muc-1` và `2026-10-25_noi_dung_khoa_hoc_course-os-c-261025-sme-buoi-01`), làm cổng chống đạo văn `G4` báo trùng `100%` với 2 bài gốc!
  3. **`[G1-DoDaiCau]`**: Sau đợt tách câu 1, `BAI_01..BAI_04` đã lọt vào `[34.6, 36.3]` (PASS), nhưng 8 bài (`BAI_05..BAI_13` trừ `BAI_06`) vẫn còn nằm ở mức `37.1 – 44.2` từ/câu (vượt nhẹ ngưỡng khắt khe `36.8`).

### Vòng 3 (`cham_khat_khe_vong_3.json`) — Tinh chỉnh nhịp câu & Nghiệm thu 13/13 PASS Tuyệt Đối
- **Hành động sửa**:
  1. Tự động dọn sạch các thư mục test giao kèo tạm (`run-muc-1`, `course-os-c-261025-sme-buoi-01`, `test-cong-duyet-nguoi-v7`), giữ đúng **13 thư mục Run chính thức** trong `runs/`.
  2. Tách gọn các câu ghép trên 42 chữ ở 8 bài còn lại trong `scripts/kho_10_bai_moi.py` và khử nốt bigram lặp liền kề (`con số`).
- **Kết quả Vòng 3**:
  - **`13/13 BÀI ĐẠT TUYỆT ĐỐI (100% PASS — exit code 0)`**
  - Độ tương đồng **Jaccard 4-gram tối đa trên toàn bộ 78 cặp bài = `1.60%`** (thấp hơn 5 lần so với trần khắt khe `8.0%`), **`0` câu văn trùng lặp**.
  - Bộ kiểm thử hồi quy `verify.py` đạt **`21/21 CHECKS PASSED`** và `test_10_vong_chuyen_sau.py` đạt **`28/28 CHECKS PASSED`**.

---

## 3. Bảng Tổng Hợp Kết Quả 13 Bài Chạy Thực Tế (3 Bài Gốc + 10 Bài Mới)

| # | Mã Bài | Loại | Thư mục Run (`runs/...`) | Ảnh gốc AGY (`assets_agy/`) | Draft 1 `CQS` | Bản cuối `CQS` (Tăng) | `APS` (≤10) | `cau_tb` (`[21.5, 36.8]`) | Hai vế (`0%`) | Văn dịch (`100`) | Onbrand CLI (`≥98.5`) | Phủ màu Sakedemy | Kết quả Vòng 3 |
|---:|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| 01 | `BAI_01` | `bai_viet` | `2026-10-25_bai_viet_thue-thoi-gian-don-rac-ai` | `agy_bai_viet_workslop.jpg` | 69.7 | **97.4** (`+27.7`) | 6.5 | **36.3** | 0.0% | **100** | **99.0** | 100.0% | **PASS** |
| 02 | `BAI_04` | `bai_viet` | `2026-10-25_bai_viet_bay-do-luong-kpi-so-luong-prompt` | `agy_bai_viet_workslop.jpg` | 68.9 | **97.0** (`+28.1`) | 7.5 | **35.9** | 0.0% | **100** | **99.0** | 100.0% | **PASS** |
| 03 | `BAI_05` | `bai_viet` | `2026-10-25_bai_viet_ranh-gioi-bao-mat-du-lieu-shadow-ai` | `agy_data_governance.jpg` | 60.5 | **97.0** (`+36.5`) | 7.5 | **35.6** | 0.0% | **100** | **99.0** | 100.0% | **PASS** |
| 04 | `BAI_06` | `bai_viet` | `2026-10-25_bai_viet_mat-tri-nho-to-chuc-khi-giao-khoan-ai` | `agy_data_governance.jpg` | 64.4 | **97.0** (`+32.6`) | 7.5 | **35.5** | 0.0% | **100** | **99.0** | 100.0% | **PASS** |
| 05 | `BAI_07` | `bai_viet` | `2026-10-25_bai_viet_tu-duy-phan-bien-truoc-con-bao-tom-tat` | `agy_editorial_lab.jpg` | 64.4 | **97.0** (`+32.6`) | 7.5 | **35.4** | 0.0% | **100** | **99.0** | 100.0% | **PASS** |
| 06 | `BAI_02` | `report_mau` | `2026-10-25_report_mau_chan-doan-dao-tao-ai-doanh-nghiep-2026` | `agy_report_diagnostic.jpg` | 71.2 | **97.6** (`+26.4`) | 6.0 | **35.6** | 0.0% | **100** | **99.0** | 100.0% | **PASS** |
| 07 | `BAI_08` | `report_mau` | `2026-10-25_report_mau_kiem-toan-rui-ro-shadow-ai-va-quyen-rieng-tu-2026` | `agy_data_governance.jpg` | 55.1 | **97.6** (`+42.5`) | 6.0 | **34.1** | 0.0% | **100** | **99.0** | 100.0% | **PASS** |
| 08 | `BAI_09` | `report_mau` | `2026-10-25_report_mau_danh-gia-roi-ung-dung-ai-khoi-kinh-doanh-cskh-2026` | `agy_sales_cs_roi.jpg` | 55.1 | **97.0** (`+41.9`) | 7.5 | **35.8** | 0.0% | **100** | **99.0** | 100.0% | **PASS** |
| 09 | `BAI_10` | `report_mau` | `2026-10-25_report_mau_khung-nang-luc-ai-theo-4-khoi-phong-ban-2026` | `agy_report_diagnostic.jpg` | 58.1 | **98.2** (`+40.1`) | 4.5 | **34.4** | 0.0% | **100** | **99.0** | 100.0% | **PASS** |
| 10 | `BAI_03` | `noi_dung_khoa_hoc` | `2026-10-25_noi_dung_khoa_hoc_buoi-01-tu-duy-cung-ai-chong-slop` | `agy_course_anti_slop.jpg` | 70.3 | **97.6** (`+27.3`) | 6.0 | **34.6** | 0.0% | **100** | **99.0** | 100.0% | **PASS** |
| 11 | `BAI_11` | `noi_dung_khoa_hoc` | `2026-10-25_noi_dung_khoa_hoc_buoi-02-thiet-ke-persona-neo-va-thu-dan-y` | `agy_editorial_lab.jpg` | 58.1 | **97.6** (`+39.5`) | 6.0 | **32.7** | 0.0% | **100** | **99.0** | 100.0% | **PASS** |
| 12 | `BAI_12` | `noi_dung_khoa_hoc` | `2026-10-25_noi_dung_khoa_hoc_buoi-03-kiem-toan-so-lieu-va-chong-ao-giac-ai` | `agy_editorial_lab.jpg` | 63.2 | **97.6** (`+34.4`) | 6.0 | **36.7** | 0.0% | **100** | **99.0** | 100.0% | **PASS** |
| 13 | `BAI_13` | `noi_dung_khoa_hoc` | `2026-10-25_noi_dung_khoa_hoc_buoi-04-bien-tap-tach-ngu-canh-6-luot` | `agy_course_anti_slop.jpg` | 58.7 | **97.6** (`+38.9`) | 6.0 | **36.2** | 0.0% | **100** | **99.0** | 100.0% | **PASS** |
