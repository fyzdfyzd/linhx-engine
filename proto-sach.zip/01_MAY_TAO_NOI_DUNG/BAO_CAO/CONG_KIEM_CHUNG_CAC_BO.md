# BÁO CÁO VẬN HÀNH CỔNG KIỂM CHẤT LƯỢNG CHUNG (`_DUNG_CHUNG/may_tao_noi_dung_adapter.py`)

- **Thời điểm chạy kiểm định liên bộ**: `2026-10-25T17:38:43`
- **Cơ chế**: Mọi bộ khác (`03_OPC_OS`, `07_CHANNEL_OS`, `06_COURSE_OS`, `05_AGENT_FORCE_OS`, `02_SERVER_MONG/1_CAFEBIZ`) gọi hàm `kiemChatLuong(dauRa, loai, bo_goi)` qua `D:\LINHX\PROTO\_DUNG_CHUNG\may_tao_noi_dung_adapter.py`.
- **Lưu vết thời gian thực**: `D:\LINHX\PROTO\01_MAY_TAO_NOI_DUNG\logs\cong_kiem_chung_metrics.jsonl` và `logs\nhat_ky_hoat_dong.jsonl`.

## Bảng Đo Thời Gian & Token Mỗi Lần Gọi Kiểm Chất Lượng Liên Bộ

| Bộ gọi (`bo_goi`) | Hạng mục đầu ra kiểm định | Loại chuẩn | Số chữ | Điểm chất lượng (/100) | Kết quả | Thời gian (`ms`) | Token kiểm định | Token API trả phí |
|---|---|---|---:|---:|---|---:|---:|---:|
| `03_OPC_OS` | Report OPC (Chiêm tinh & Prompt Ngân hàng — đã ẩn tên khách) | `report_mau` | 0 | **67.8** | **CẦN SỬA (6 mục)** | `396.61 ms` | `80` | `0` |
| `07_CHANNEL_OS` | Bài truyền thông kênh cá nhân Linh & chiemtinh.vn | `bai_viet` | 0 | **82.7** | **CẦN SỬA (2 mục)** | `347.88 ms` | `80` | `0` |
| `06_COURSE_OS` | Học liệu khoá học EDU008-MAS-SME (Chị Nga) | `noi_dung_khoa_hoc` | 0 | **49.7** | **CẦN SỬA (6 mục)** | `356.03 ms` | `80` | `0` |
| `05_AGENT_FORCE_OS` | Báo cáo & Bản đồ Agent Force cho Khách A (Công ty Dược ẩn tên) | `report_mau` | 0 | **97.0** | **ĐẠT** | `347.68 ms` | `80` | `0` |
| `02_SERVER_MONG/1_CAFEBIZ` | Bài chuyên sâu Tòa soạn CafeBiz (Batch 2026-10-25-poc) | `bai_viet` | 0 | **76.7** | **CẦN SỬA (4 mục)** | `341.12 ms` | `80` | `0` |
