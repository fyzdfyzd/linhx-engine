# BƯỚC 05: TỰ CHẤM & CHỐT HƯỚNG OUTLINE (`bai_viet`)

> **Truy vết Module**: `BM1_05_cham_chon_huong` (**Làm mới hoàn toàn** theo Đề 01 Bản 3)
> **Cờ duyệt (`duyet_outline`)**: `nguoi` → **Trạng thái**: `DA_CHOT_THEO_NGUOI_CHON`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu (Gemini 2.5 Flash)

## 1. Bảng chấm điểm 3 phương án Outline (Thang 100)

| Hạng | Phương án | Persona (40đ) | Khớp `dat_khi` (30đ) | Bằng chứng (20đ) | Chống Slop (10đ) | **Tổng (/100)** | Kết luận |
|---|---|---:|---:|---:|---:|---:|---|
| 1 | **B** — Hướng B — Đi từ Tình huống Thực tế tại Doanh nghiệp, Đối chiếu Trước/Sau & Bảng kiểm Áp dụng Ngay | 38.0 | 29.0 | 19.0 | 9.5 | **95.5** | ★ **CHỐT**: Phương án B có mở bài rất thuyết phục, đi thẳng vào tình huống cụ thể của doanh nghiệp sản xuất Việt Nam với con số rõ ràng. Các phần nội dung được sắp xếp logic, tập trung vào giải pháp quy trình 3 bước và có bảng đối chiếu trước/sau, sơ đồ quy trình. Đặc biệt, 'Bảng kiểm nghiệm thu & Khung hành động 7 ngày' đáp ứng rất tốt tiêu chí 'áp dụng ngay trong tuần'. |
| 2 | **C** — Hướng C — Đi thẳng vào Cẩm nang Thao tác Nhanh & Mẫu biểu Thực hành | 32.0 | 20.0 | 16.0 | 8.0 | **76.0** | Loại: Phương án C có cách tiếp cận trực tiếp, hướng dẫn thao tác chi tiết nhưng mở bài chưa thực sự là 'câu chuyện tình huống thật kèm con số cụ thể'. Các mẫu biểu và phiếu bài tập có tính thực hành cao nhưng lại thiếu đi cái nhìn tổng quan về quy trình trước và sau, cũng như chưa có khung hành động rõ ràng để áp dụng ngay trong tuần theo tiêu chí bắt buộc của thể loại. |
| 3 | **A** — Hướng A — Đi từ Số liệu Vĩ mô & Cảnh báo Hệ thống | 30.5 | 22.0 | 15.0 | 7.5 | **75.0** | Loại: Phương án A có mở bài khá chung chung, chưa đi sâu vào tình huống cụ thể của doanh nghiệp sản xuất Việt Nam. Các phần nội dung có đề cập đến số liệu nhưng chưa thực sự tập trung vào giải pháp quy trình 3 bước một cách chi tiết và thực tế cho đối tượng độc giả. Khung hành động còn chung chung, chưa đủ tính 'áp dụng ngay trong tuần'. |

## 2. Quyết định chốt hướng: ★ Phương án B (95.5/100 điểm)
- **Tên phương án**: Hướng B — Đi từ Tình huống Thực tế tại Doanh nghiệp, Đối chiếu Trước/Sau & Bảng kiểm Áp dụng Ngay
- **Góc nhìn**: Tại một doanh nghiệp sản xuất Việt Nam, phòng vận hành với 18 nhân sự đang vật lộn với hàng trăm hợp đồng và báo cáo tài chính mỗi tháng, tiêu tốn trung bình 40% thời gian làm việc chỉ để 'dọn rác văn bản' và kiểm tra chéo thủ công – một con số đáng báo động theo nghiên cứu của HBR. Đây chính là lúc trí tuệ nhân tạo cần được thiết kế thành một quy trình ba bước để giải phóng nguồn lực quý giá đó.
- **Giọng điệu**:  Chuẩn giọng Bài viết chuyên sâu (Báo chí / Tạp chí kinh tế - công nghệ)
- **Khung triển khai gửi sang Bước 6**:
  - 1. Tình huống thực tế: Gánh nặng 'giấy tờ' tại phòng vận hành 18 nhân sự và chi phí ẩn
  - 2. Phân tích nguyên nhân gốc rễ: Tại sao 30% giờ làm bị hao hụt vì sản phẩm AI kém chất lượng nếu thiếu quy trình (BCG)?
  - 3. Bảng đối chiếu: Quy trình rà soát hợp đồng & báo cáo tài chính TRƯỚC và SAU khi chuẩn hoá bằng AI
  - 4. Quy trình 3 bước triển khai thực chiến AI: Từ thu thập, xử lý đến kiểm soát chất lượng
  - 5. Bảng kiểm nghiệm thu & Khung hành động 7 ngày: Bắt đầu chuyển đổi AI ngay trong tuần tới

## 3. Ràng buộc bắt buộc giao cho Bước 6 (Rút từ phản ứng Persona & Luật chống Slop)
- [x] Phải giải quyết câu phản biện của P1 (Chủ doanh nghiệp SME / Giám đốc vận hành (Độc giả mục tiêu chính)): Bài viết này chạm đúng nỗi đau của tôi. Tình huống thực tế rất quen thuộc, và việc đối chiếu trước/sau giúp tôi hình dung rõ lợi ích. Khung hành động 7 ngày là điều tôi cần để bắt đầu.
- [x] Phải giải quyết câu phản biện của P2 (Trưởng phòng chuyên môn / Team Lead (Người trực tiếp chịu trận giữa sếp và nhân viên)): Đây chính là bài viết tôi đang tìm kiếm! Tình huống thực tế và phân tích nguyên nhân gốc rễ giúp tôi hiểu rõ vấn đề. Quy trình 3 bước và bảng kiểm là cẩm nang để tôi triển khai cho đội ngũ 18 người của mình.
- [x] Phải giải quyết câu phản biện của P3 (Chuyên gia / Quản lý kỹ thuật hoài nghi (Độc giả khó tính hay bắt bẻ số liệu)): Cách tiếp cận từ vấn đề thực tế và phân tích nguyên nhân gốc rễ rất logic. Quy trình 3 bước có vẻ khả thi và bảng đối chiếu trước/sau cung cấp bằng chứng định lượng tốt. Quy tắc 10-20-70 được lồng ghép hợp lý.
- [x] Tuyệt đối không dùng cấu trúc so sánh hai vế 'Không còn là X mà là Y' hoặc 'Càng X càng Y' (Luật Vân Anh VA-01, VA-02).
- [x] Mọi số liệu trích dẫn phải giữ nguyên mã nguồn [Nxx]/[BCxx], mọi tình huống giả định phải ghi rõ là tình huống mô phỏng.

> **[CỔNG DỪNG CHỜ NGƯỜI DUYỆT]**: Cờ `duyet_outline = nguoi`. Hệ thống dừng chờ anh Linh xác nhận Phương án khuyến nghị ★ trước khi sang Bước 6.
