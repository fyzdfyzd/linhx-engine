# BƯỚC 01: ĐỌC KỸ, PHÂN TÍCH ĐỀ BÀI & MỞ RỘNG BỐI CẢNH (`bai_viet`)

> **Truy vết Module**: `BM1_01_phan_tich_de_bai`
> **Đã gọi**: `LAB025/linhx-viet-bai/skills/idea-seeder` (`01_Seed_Input` + `02_Context_Expansion` 11 câu hỏi sâu)
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

### Cấu hình thể loại đã nạp từ `loai/bai_viet/cau_hinh.json`
- **Tên hiển thị**: Bài viết chuyên sâu (Báo chí / Tạp chí kinh tế - công nghệ)
- **Độ dài mục tiêu**: 1300 chữ (950–1800 chữ)
- **Yêu cầu bắt buộc**: Mở bài bằng câu chuyện tình huống thật kèm con số cụ thể, Bảng đối chiếu hoặc ma trận quy trình trước và sau, Khung hành động thực tế áp dụng ngay trong tuần

## 1. Hạt giống ý tưởng (`01_Seed_Input`)
- **Đề bài**: Thiết kế quy trình ba bước rà soát hợp đồng và báo cáo tài chính bằng trí tuệ nhân tạo cho phòng vận hành mười tám nhân sự tại doanh nghiệp sản xuất Việt Nam
- **Góc nhìn tác giả (Linh)**: Không viết thêm một bài tụng ca công nghệ hay hướng dẫn mẹo viết câu lệnh; đi thẳng vào cảnh tượng trớ trêu trong các văn phòng Việt Nam hiện nay: nhân viên dùng máy xuất ra hàng chục trang chữ trong vài chục giây, rồi cấp quản lý phải thức khuya đọc và viết lại từ đầu vì văn bản đầy mùi dịch thuật vô hồn.
- **Nghịch lý trung tâm**: Công cụ sinh ra để cắt giảm thời gian làm việc cơ học, nhưng khi giao việc không có hạt giống và không có cổng biên tập, nó lại tạo ra thứ thuế thời gian mới mang tên "dọn rác câu chữ cho máy".
- **Ràng buộc cứng**:
  - Giọng văn: Hồ sơ `linh/LUAT.md` (tỉnh táo, sắc lạnh, đi từ chuyện thật trong phòng họp sang cấu trúc vận hành).
  - Biên tập: Hồ sơ `van-anh/LUAT.md` (cấm tuyệt đối câu `không còn là... mà là...`, cấm `càng... càng...`, câu so sánh hai vế dưới 5%, chữ số trong văn xuôi viết bằng chữ, mọi dẫn chứng gắn mã `[Nxx]` hoặc `[GIẢ LẬP]`).

## 2. Mười một câu hỏi mở rộng bối cảnh (`LAB025 idea-seeder` — 3 câu mũi nhọn)
1. **Câu hỏi 1 (Ai đang trả giá thật?)**: Khi một nhân viên nộp bản kế hoạch do AI viết tự động, ai là người gánh chi phí đọc hiểu và sửa sai? → *Trưởng bộ phận và giám đốc điều hành.*
2. **Câu hỏi 2 (Ngộ nhận lớn nhất là gì?)**: Vì sao các khoá dạy viết câu lệnh dài hai trang vẫn thất bại? → *Vì câu lệnh dài không thay thế được ý tưởng gốc và trải nghiệm thực địa của người viết.*
3. **Câu hỏi 3 (Bằng chứng thực nghiệm nào chứng minh?)**: Từ thực nghiệm biên tập tại `LAB049`, điều gì xảy ra khi cho máy tự viết bài từ đầu so với khi người viết giữ phần nháp gạch đầu dòng? → *Bản máy tự viết bị biên tập viên gạch bỏ toàn bộ cách diễn đạt; chỉ khi người giữ khung ý và tách riêng sáu lượt biên tập thì bài viết mới giữ được hơi thở người thật.*
4. **Câu hỏi 4–11 (Mở rộng chiều sâu)**: Ranh giới trách nhiệm khi số liệu sai; thói quen đổ lỗi cho công cụ; sự biến mất của cá tính thương hiệu khi dùng chung mô hình; tâm lý ngại cắt bỏ câu chữ bóng bẩy; chi phí cơ hội của sự trơn tru giả tạo; cách phân biệt câu có chủ thể và câu vô chủ; vai trò của độc giả ảo hay cãi; quy tắc giữ chốt hai đầu.
