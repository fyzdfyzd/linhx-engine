# BƯỚC 02: NGHIÊN CỨU NGƯỜI NHẬN & DỰNG 3 PERSONA NEO (`bai_viet`)

> **Truy vết Module**: `BM1_02_persona_neo` (Gộp mới từ `LAB029` + `LAB048` + `LAB049`)
> **Đã gọi**: `LAB029/nhu-cau-doc-gia`, `LAB048/lay_mau_1000.py` (`persona-sample-60.json`), `LAB049/doc-gia-ao`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Phân tích khoảng trống người nhận (Theo `LAB029`)
- **Đề bài**: Thiết kế quy trình kiểm định chất lượng tài liệu tư vấn và tự động sao lưu hàng ngày cho đội ngũ hai mươi chuyên viên tại doanh nghiệp dịch vụ Việt Nam
- **Chủ đề đối chuẩn**: Ứng dụng AI thực chiến trong doanh nghiệp Việt Nam vs. Phong trào mua tool / nói đạo lý AI
- **Khoảng trống trên thị trường hiện tại**: 90% bài viết trên thị trường hoặc hù dọa 'không dùng AI sẽ bị đào thải', hoặc khoe prompt bề nổi; thiếu hẳn góc nhìn giải phẫu quy trình vận hành thực tế và chi phí sửa sai khi nhân sự dùng AI ẩu.
- **Điểm cơ hội khoảng trống (`gap_score`)**: **8.6/10**

## 2. Hồ sơ 3 Persona Neo (Lọc nhân khẩu `LAB048` + Tâm lý phản biện `LAB049`)

### [P1] Chủ doanh nghiệp SME / Giám đốc vận hành (Độc giả mục tiêu chính)
- **Hồ sơ nhân khẩu học (`LAB048` UUID `fad1fdae-a0da-5022-931b-50020fd58a70`)**: 32 tuổi · Nữ · Nông Thôn (Trung du và miền núi phía Bắc) · Học vấn: Trung học phổ thông
- **Bối cảnh tiếp nhận (`LAB049`)**: Đọc trên điện thoại lúc 22h30 sau khi xử lý xong việc công ty hoặc sáng sớm uống cà phê trước giờ họp.
- **Nỗi sợ ẩn**: Sợ tụt hậu nếu không đưa AI vào công ty, nhưng sợ hơn cảnh nhân viên dùng AI xả rác ra báo cáo sai số liệu mà mình không kiểm soát nổi.
- **Câu cửa miệng hay cãi (Phản xạ phòng vệ)**: *"Lý thuyết quy trình nghe thì hay, nhưng nhân sự bên tôi bảo làm thêm bước kiểm tra là họ kêu quá tải ngay."*
- **Ngưỡng bỏ đọc (`trigger_bo_doc`)**: Bỏ đọc ngay ở đoạn 2 nếu thấy giọng hô hào 'kỷ nguyên AI bùng nổ' hoặc liệt kê danh sách 10 công cụ AI.
- **Kỳ vọng mang về sau khi đọc/học**: Một nguyên tắc phân rã công việc rõ ràng để biết khâu nào giao cho máy, khâu nào bắt buộc người phải giữ chốt.

### [P2] Trưởng phòng chuyên môn / Team Lead (Người trực tiếp chịu trận giữa sếp và nhân viên)
- **Hồ sơ nhân khẩu học (`LAB048` UUID `f0aaae05-4e23-51f0-806f-63358f3b38cd`)**: 27 tuổi · Nữ · Đô Thị (Bắc Trung Bộ và Duyên hải miền Trung) · Học vấn: Trung học phổ thông
- **Bối cảnh tiếp nhận (`LAB049`)**: Đọc trên màn hình máy tính văn phòng khi được đồng nghiệp hoặc sếp gửi link qua Zalo nhóm.
- **Nỗi sợ ẩn**: Sếp ép cắt giảm thời gian làm việc vì nghĩ 'có ChatGPT rồi', trong khi thời gian mình ngồi sửa văn phong ngô nghê của AI còn lâu hơn tự viết.
- **Câu cửa miệng hay cãi (Phản xạ phòng vệ)**: *"Sếp chỉ nhìn sản phẩm cuối chứ có ngồi sửa từng câu văn dịch của AI lúc 8 giờ tối như tụi tôi đâu."*
- **Ngưỡng bỏ đọc (`trigger_bo_doc`)**: Bỏ đọc nếu bài viết đổ hết lỗi cho nhân viên 'lười tư duy' mà không chỉ ra lỗi ở cách giao đề bài của cấp quản lý.
- **Kỳ vọng mang về sau khi đọc/học**: Gọi đúng tên nỗi khổ 'sửa rác AI mệt hơn tự làm' để có luận điểm trao đổi thẳng thắn với sếp.

### [P3] Chuyên gia / Quản lý kỹ thuật hoài nghi (Độc giả khó tính hay bắt bẻ số liệu)
- **Hồ sơ nhân khẩu học (`LAB048` UUID `9818391a-4326-5259-9067-09798cc218c7`)**: 30 tuổi · Nữ · Nông Thôn (Đồng bằng sông Cửu Long) · Học vấn: Trung học phổ thông
- **Bối cảnh tiếp nhận (`LAB049`)**: Đọc lướt rất nhanh trên laptop, soi kỹ các con số, nguồn trích dẫn và tính logic của lập luận.
- **Nỗi sợ ẩn**: Ngán ngẩm trước làn sóng 'chuyên gia AI tự phong' dùng câu chữ bóng bẩy nhưng rỗng ruột kỹ thuật.
- **Câu cửa miệng hay cãi (Phản xạ phòng vệ)**: *"Số liệu này lấy ở khảo sát nào, mẫu bao nhiêu, hay tác giả tự suy diễn từ vài quán cà phê?"*
- **Ngưỡng bỏ đọc (`trigger_bo_doc`)**: Bỏ đọc ngay khi gặp ẩn dụ sáo rỗng kéo dài hoặc con số thả nổi không có chủ thể/nguồn gốc.
- **Kỳ vọng mang về sau khi đọc/học**: Một góc nhìn sắc lạnh, có bằng chứng xác thực và chỉ ra đúng giới hạn cấu trúc của mô hình ngôn ngữ.

## 3. Quy tắc neo cho các bước sau
- **Bước 4 (`BM1_04_outline_thu_persona`)**: Cả 3 phương án Outline A/B/C bắt buộc phải đưa qua 3 Persona `P1`, `P2`, `P3` đọc thử và trả lời câu cãi của họ.
- **Bước 8 & 9 (`BM1_08`, `BM1_09`)**: Bản viết cuối không được vi phạm `trigger_bo_doc` của bất kỳ Persona nào và phải trả lời trực diện ít nhất 2/3 câu cãi trên.
