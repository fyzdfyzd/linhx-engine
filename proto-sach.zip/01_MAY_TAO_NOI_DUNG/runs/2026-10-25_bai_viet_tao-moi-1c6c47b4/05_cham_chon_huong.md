# BƯỚC 05: TỰ CHẤM & CHỐT HƯỚNG OUTLINE (`bai_viet`)

> **Truy vết Module**: `BM1_05_cham_chon_huong` (**Làm mới hoàn toàn** theo Đề 01 Bản 3)
> **Cờ duyệt (`duyet_outline`)**: `nguoi` → **Trạng thái**: `DA_CHOT_THEO_NGUOI_CHON`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu (Gemini 2.5 Flash)

## 1. Bảng chấm điểm 3 phương án Outline (Thang 100)

| Hạng | Phương án | Persona (40đ) | Khớp `dat_khi` (30đ) | Bằng chứng (20đ) | Chống Slop (10đ) | **Tổng (/100)** | Kết luận |
|---|---|---:|---:|---:|---:|---:|---|
| 1 | **B** — Hướng B — Đi từ Tình huống Thực tế tại Doanh nghiệp, Đối chiếu Trước/Sau & Bảng kiểm Áp dụng Ngay | 38.0 | 29.0 | 19.0 | 9.5 | **95.5** | ★ **CHỐT**: Phương án B có mở bài rất thuyết phục, đi thẳng vào tình huống cụ thể của doanh nghiệp sản xuất Việt Nam với con số rõ ràng. Các phần nội dung được sắp xếp logic, tập trung vào giải pháp quy trình 3 bước và có bảng đối chiếu trước/sau, sơ đồ quy trình. Đặc biệt, 'Bảng kiểm nghiệm thu & Khung hành động 7 ngày' đáp ứng rất tốt tiêu chí 'áp dụng ngay trong tuần'. |
| 2 | **C** — Hướng C — Đi thẳng vào Cẩm nang Thao tác Nhanh & Mẫu biểu Thực hành | 32.0 | 20.0 | 16.0 | 8.0 | **76.0** | Loại: Phương án C có cách tiếp cận trực tiếp, hướng dẫn thao tác chi tiết nhưng mở bài chưa thực sự là 'câu chuyện tình huống thật kèm con số cụ thể'. Các mẫu biểu và phiếu bài tập có tính thực hành cao nhưng lại thiếu đi cái nhìn tổng quan về quy trình trước và sau, cũng như chưa có khung hành động rõ ràng để áp dụng ngay trong tuần theo tiêu chí bắt buộc của thể loại. |
| 3 | **A** — Hướng A — Đi từ Số liệu Vĩ mô & Cảnh báo Hệ thống | 30.5 | 22.0 | 15.0 | 7.5 | **75.0** | Loại: Phương án A có mở bài khá chung chung, chưa đi sâu vào tình huống cụ thể của doanh nghiệp sản xuất Việt Nam. Các phần nội dung có đề cập đến số liệu nhưng chưa thực sự tập trung vào giải pháp quy trình 3 bước một cách chi tiết và thực tế cho đối tượng độc giả. Khung hành động còn chung chung, chưa đủ tính 'áp dụng ngay trong tuần'. |

## 2. Quyết định chốt hướng: ★ Phương án B (95.5/100 điểm)
- **Tên phương án**: Hướng B — Đi từ Tình huống Thực tế tại Doanh nghiệp, Đối chiếu Trước/Sau & Bảng kiểm Áp dụng Ngay
- **Góc nhìn**: Tại một doanh nghiệp dịch vụ Việt Nam, mỗi sáng thứ Hai, đội ngũ hai mươi chuyên viên lại mất trung bình 2 giờ để tìm kiếm, đối chiếu và chỉnh sửa các phiên bản tài liệu tư vấn khác nhau, tương đương 40 giờ làm việc bị hao phí mỗi tuần chỉ vì thiếu quy trình kiểm định chất lượng và sao lưu tự động.
- **Giọng điệu**:  Chuẩn giọng Bài viết chuyên sâu (Báo chí / Tạp chí kinh tế - công nghệ)
- **Khung triển khai gửi sang Bước 6**:
  - 1. Tình huống thực tế: 40 giờ làm việc 'bốc hơi' mỗi tuần vì tài liệu kém chất lượng
  - 2. Phân tích nguyên nhân gốc rễ: Quy tắc 10-20-70 và 30% giờ làm bị hao hụt
  - 3. Chuyển đổi đột phá: Bảng đối chiếu quy trình kiểm định và sao lưu Trước và Sau
  - 4. Quy trình 3 bước triển khai thực chiến: Kiểm định chất lượng và tự động sao lưu tài liệu
  - 5. Bảng kiểm nghiệm thu & Khung hành động: Áp dụng ngay trong tuần tới

## 3. Ràng buộc bắt buộc giao cho Bước 6 (Rút từ phản ứng Persona & Luật chống Slop)
- [x] Phải giải quyết câu phản biện của P1 (Chủ doanh nghiệp SME / Giám đốc vận hành (Độc giả mục tiêu chính)): Mở bài rất thực tế, tôi thấy hình ảnh doanh nghiệp mình trong đó. Bảng đối chiếu trước/sau và khung hành động cụ thể là thứ tôi cần để triển khai ngay. Rất thiết thực và có tính ứng dụng cao.
- [x] Phải giải quyết câu phản biện của P2 (Trưởng phòng chuyên môn / Team Lead (Người trực tiếp chịu trận giữa sếp và nhân viên)): Đây chính là những gì tôi đang tìm kiếm! Tình huống thực tế và quy tắc 10-20-70 giải thích rõ ràng vấn đề. Bảng đối chiếu và quy trình 3 bước giúp tôi có thể trình bày với sếp và hướng dẫn team ngay lập tức.
- [x] Phải giải quyết câu phản biện của P3 (Chuyên gia / Quản lý kỹ thuật hoài nghi (Độc giả khó tính hay bắt bẻ số liệu)): Cách tiếp cận từ tình huống thực tế và phân tích nguyên nhân gốc rễ rất logic. Quy tắc 10-20-70 và con số 30% hao hụt giờ làm từ Sakedemy là bằng chứng mạnh mẽ. Bảng đối chiếu và sơ đồ quy trình cung cấp cái nhìn tổng quan tốt về mặt kỹ thuật.
- [x] Tuyệt đối không dùng cấu trúc so sánh hai vế 'Không còn là X mà là Y' hoặc 'Càng X càng Y' (Luật Vân Anh VA-01, VA-02).
- [x] Mọi số liệu trích dẫn phải giữ nguyên mã nguồn [Nxx]/[BCxx], mọi tình huống giả định phải ghi rõ là tình huống mô phỏng.

> **[CỔNG DỪNG CHỜ NGƯỜI DUYỆT]**: Cờ `duyet_outline = nguoi`. Hệ thống dừng chờ anh Linh xác nhận Phương án khuyến nghị ★ trước khi sang Bước 6.
