# BƯỚC 05: TỰ CHẤM & CHỐT HƯỚNG OUTLINE (`bai_viet`)

> **Truy vết Module**: `BM1_05_cham_chon_huong` (**Làm mới hoàn toàn** theo Đề 01 Bản 3)
> **Cờ duyệt (`duyet_outline`)**: `nguoi` → **Trạng thái**: `DA_CHOT_THEO_NGUOI_CHON`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu (Gemini 2.5 Flash)

## 1. Bảng chấm điểm 3 phương án Outline (Thang 100)

| Hạng | Phương án | Persona (40đ) | Khớp `dat_khi` (30đ) | Bằng chứng (20đ) | Chống Slop (10đ) | **Tổng (/100)** | Kết luận |
|---|---|---:|---:|---:|---:|---:|---|
| 1 | **B** — Hướng B — Đi từ Tình huống Thực tế tại Doanh nghiệp, Đối chiếu Trước/Sau & Bảng kiểm Áp dụng Ngay | 38.0 | 29.0 | 18.5 | 9.5 | **95.0** | ★ **CHỐT**: Mở bài rất thuyết phục với tình huống thực tế và con số cụ thể, trực tiếp chạm đến vấn đề của người đọc. Các tiêu chí bắt buộc được đáp ứng đầy đủ và rõ ràng (bảng đối chiếu trước/sau, khung hành động thực tế). Mật độ bằng chứng và bảng biểu được đề xuất phù hợp, chống sáo rỗng tốt. |
| 2 | **C** — Hướng C — Đi thẳng vào Cẩm nang Thao tác Nhanh & Mẫu biểu Thực hành | 32.0 | 22.0 | 15.0 | 8.0 | **77.0** | Loại: Mở bài có tính ứng dụng cao nhưng chưa phải là 'câu chuyện tình huống thật' theo yêu cầu. Nội dung đi thẳng vào hướng dẫn thực hành nhưng có thể thiếu đi phần phân tích bối cảnh và lý do cần thiết, khiến bài viết chưa đủ chiều sâu của thể loại chuyên sâu. Các mẫu biểu có nhưng chưa rõ ràng về 'trước và sau'. |
| 3 | **A** — Hướng A — Đi từ Số liệu Vĩ mô & Cảnh báo Hệ thống | 27.5 | 20.0 | 14.0 | 7.5 | **69.0** | Loại: Mở bài bằng số liệu vĩ mô chưa đủ sức hút với người đọc cụ thể. Các phần nội dung có vẻ hơi chung chung, thiếu tính ứng dụng trực tiếp cho đối tượng 25 nhân sự vận hành. Mặc dù có bảng đối chiếu nhưng chưa rõ ràng về 'trước và sau' quy trình. |

## 2. Quyết định chốt hướng: ★ Phương án B (95.0/100 điểm)
- **Tên phương án**: Hướng B — Đi từ Tình huống Thực tế tại Doanh nghiệp, Đối chiếu Trước/Sau & Bảng kiểm Áp dụng Ngay
- **Góc nhìn**: Tại một doanh nghiệp bán lẻ Việt Nam với 25 nhân sự vận hành, mỗi tuần, Trưởng phòng phải dành trung bình 8 giờ để rà soát và chỉnh sửa 50 báo cáo, trong đó 30% báo cáo có lỗi định dạng hoặc thiếu dữ liệu quan trọng, gây lãng phí hàng trăm giờ làm và trì hoãn quyết định kinh doanh. Đây là câu chuyện thật, và AI chính là lời giải.
- **Giọng điệu**:  Chuẩn giọng Bài viết chuyên sâu (Báo chí / Tạp chí kinh tế - công nghệ)
- **Khung triển khai gửi sang Bước 6**:
  - 1. Tình huống thực tế & chi phí ẩn: Khi báo cáo tuần 'ngốn' thời gian và tiền bạc của doanh nghiệp bán lẻ
  - 2. Phân tích nguyên nhân gốc rễ: Tại sao 30% giờ làm bị hao hụt vì 'dọn dẹp' báo cáo kém chất lượng? (N05)
  - 3. Chuyển đổi đột phá: Bảng đối chiếu quy trình kiểm soát chất lượng báo cáo Trước và Sau khi áp dụng AI
  - 4. Quy trình 3 bước triển khai thực chiến: Từ ý tưởng đến hệ thống tự động hoá báo cáo
  - 5. Bảng kiểm nghiệm thu & Hành động ngay trong tuần tới: Đảm bảo AI hoạt động hiệu quả và bền vững

## 3. Ràng buộc bắt buộc giao cho Bước 6 (Rút từ phản ứng Persona & Luật chống Slop)
- [x] Phải giải quyết câu phản biện của P1 (Chủ doanh nghiệp SME / Giám đốc vận hành (Độc giả mục tiêu chính)): Tuyệt vời! Câu chuyện mở đầu rất gần gũi và chạm đúng nỗi đau của tôi. Bảng đối chiếu trước/sau và khung hành động cụ thể giúp tôi hình dung rõ ràng lợi ích và cách triển khai. Tôi thấy được con đường để tiết kiệm chi phí và tối ưu vận hành.
- [x] Phải giải quyết câu phản biện của P2 (Trưởng phòng chuyên môn / Team Lead (Người trực tiếp chịu trận giữa sếp và nhân viên)): Đây chính là thứ tôi cần! Tình huống thực tế mô tả đúng những gì tôi đang trải qua. Quy trình 3 bước và bảng kiểm giúp tôi có thể bắt tay vào làm ngay. Tôi rất mong chờ phần công cụ và cách tích hợp.
- [x] Phải giải quyết câu phản biện của P3 (Chuyên gia / Quản lý kỹ thuật hoài nghi (Độc giả khó tính hay bắt bẻ số liệu)): Cách tiếp cận từ vấn đề thực tế rất hiệu quả. Bảng đối chiếu và sơ đồ quy trình cung cấp cái nhìn tổng quan tốt. Tôi đánh giá cao việc đề cập đến chi phí hao hụt và cần thêm chi tiết về cách AI giải quyết các vấn đề kỹ thuật cụ thể.
- [x] Tuyệt đối không dùng cấu trúc so sánh hai vế 'Không còn là X mà là Y' hoặc 'Càng X càng Y' (Luật Vân Anh VA-01, VA-02).
- [x] Mọi số liệu trích dẫn phải giữ nguyên mã nguồn [Nxx]/[BCxx], mọi tình huống giả định phải ghi rõ là tình huống mô phỏng.

> **[CỔNG DỪNG CHỜ NGƯỜI DUYỆT]**: Cờ `duyet_outline = nguoi`. Hệ thống dừng chờ anh Linh xác nhận Phương án khuyến nghị ★ trước khi sang Bước 6.
