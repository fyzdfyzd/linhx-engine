# BƯỚC 01: ĐỌC KỸ, PHÂN TÍCH ĐỀ BÀI & CÂY VẤN ĐỀ MECE (`report_mau`)

> **Truy vết Module**: `BM1_01_phan_tich_de_bai`
> **Đã gọi**: `LAB028/linhx-report/skills/khung-nghien-cuu` (`01-de-bai.md`, `02-khung.json`) + `LAB025/idea-seeder`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Xác định đề bài báo cáo (`01-de-bai.md` theo chuẩn `LAB028`)
- **Đề bài**: Báo cáo mẫu: Chẩn đoán khoảng trống năng lực AI và lộ trình đào tạo thực chiến chín mươi ngày cho doanh nghiệp Việt Nam 2026 (Phục vụ Pilot & OPC)
- **Đơn vị phát hành**: Sakédemy (`Nhận diện tạm: Sakedemy (LAB043)` — Tagline: *"Khi sáng tạo gặp công nghệ"*).
- **Người đọc mục tiêu**: CEO/HĐQT duyệt ngân sách (`P1`), Giám đốc Nhân sự & Đào tạo (`P2`), Trưởng khối CNTT/Chuyển đổi số (`P3`).
- **Câu hỏi quyết định trung tâm**: Làm thế nào để doanh nghiệp Việt Nam chuyển từ trạng thái "nhân sự dùng thử công cụ AI tự phát" sang "hệ thống vận hành có quy trình, có cổng kiểm chất lượng và đo được giờ công tiết kiệm trong chín mươi ngày"?

## 2. Cây vấn đề MECE 3 nhánh (`02-khung.json`)
1. **Nhánh 1 — Chẩn đoán khoảng trống hiệu quả (Why generic AI training fails)**:
   - Tỷ lệ dùng thử công cụ cao nhưng tỷ lệ ra quy trình chuẩn thấp (`[BC01, BC02]`).
   - Chi phí ẩn của quản lý cấp trung khi phải sửa tài liệu AI lỗi (`[BC03, BC06]`).
2. **Nhánh 2 — Kiến trúc chương trình đào tạo thực chiến (What works)**:
   - Ma trận phân tầng ba mức năng lực × bốn khối phòng ban (`[BC04, BC07]`).
   - Tích hợp cổng kiểm chất lượng mười bảy luật và quy chế an toàn dữ liệu hai lớp (`[BC05, BC09]`).
3. **Nhánh 3 — Lộ trình triển khai & Đo lường ROI (How to execute in 90 days)**:
   - Mô hình nhóm hạt nhân hai mươi nhân sự Pilot, nghiệm thu bằng sản phẩm thật tại lớp (`[BC08, BC10]`).
