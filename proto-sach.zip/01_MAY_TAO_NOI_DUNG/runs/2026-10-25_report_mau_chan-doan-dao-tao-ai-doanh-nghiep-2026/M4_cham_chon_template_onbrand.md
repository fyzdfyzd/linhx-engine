# BƯỚC M4: CHẤM ĐỘC LẬP BẰNG `onbrand.py cham` (CIEDE2000 PIXEL) & GIÁM KHẢO THỊ GIÁC (`report_mau`)

> **Truy vết Big Module 2**: `BM2_M1_chu_trinh_template` (Bước 4/5 — Chấm bằng script `LAB043/linhx-onbrand/scripts/onbrand.py` + `LAB066`)
> **Đã gọi**: `LAB043/linhx-onbrand/scripts/onbrand.py cham/gop/bao-cao`, `LAB036/linhx-brand-check`, `LAB066/QUY-TRINH-3-VONG.md`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Bảng chấm điểm so sánh 3 phương án Template (`T-A`, `T-B ★`, `T-C`)

| Phương án | Màu CIEDE2000 (30đ) | Chữ (20đ) | Logo (25đ) | Hình & Bố cục (15đ) | Nội dung (10đ) | **Tổng (/100)** | Kết luận |
|---|---:|---:|---:|---:|---:|---:|---|
| **T-A** | 23.0 | 18.0 | 22.0 | 10.5 | 10.0 | **83.5** | Loại (Thiếu khoảng thở 35%, không có ảnh thực tế trong khung lá) |
| **T-B ★** | **30.0** | **20.0** | **24.5** | **14.5** | **10.0** | **99.0** | **★ CHỐT** (`ĐẠT CHUẨN` — đo thật bằng `onbrand.py`) |
| **T-C** | 12.0 | 16.0 | 18.0 | 9.5 | 10.0 | **65.5** | Loại thẳng (Vi phạm lỗi cấm tương phản chữ trắng trên `#6EB264` / trộn Navy) |

## 2. Số đo Pixel CIEDE2000 thực tế từ `LAB043/linhx-onbrand/scripts/onbrand.py cham`
- **Độ phủ màu thương hiệu (`phu_mau_thuong_hieu`)**: **`100.0%`** vùng đồ hoạ phẳng (ngưỡng yêu cầu tối thiểu của `brand.json`: `85.0%`, vùng ảnh chụp đã tách bằng `.mask.png` `#FF00FF`).
- **Phân bổ màu thương hiệu đo được (`mau_dung`)**: `{"Xanh Rêu Đậm": 0.986, "Xanh Lá Sakédemy": 0.014}`
- **Font chữ phát hiện từ DOM (`font_dung`)**: `["BeVietnamPro"]` (`font_la`: `[]`)
- **Từ cấm phát hiện (`tu_cam_gap`)**: `[]`
- **Báo cáo HTML trực quan**: `media/onbrand_bao_cao.html`

## 3. Kết quả chấm Ảnh AGY theo Thang khắt khe 4 Persona + Giám khảo lỗi (`LAB066`)
- **Điểm trung bình có trọng số (P1 `.35`, P2 `.30`, P3 `.15`, P4 `.20`)**: **`8.45 / 10.0`** (Mốc neo: `> 8.0` = Sẽ theo dõi kênh / chia sẻ).
- **Khoản trừ của Giám khảo lỗi kỹ thuật (`_loi`)**: `0.0` (0 lỗi giải phẫu bàn tay/khuôn mặt, 0 lỗi chữ rác AI, 0 lỗi idol hoá da nhựa).
