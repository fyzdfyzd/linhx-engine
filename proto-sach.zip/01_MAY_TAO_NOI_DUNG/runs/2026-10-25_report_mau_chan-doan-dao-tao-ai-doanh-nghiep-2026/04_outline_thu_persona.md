# BƯỚC 04: 30 INSIGHTS, 3 HƯỚNG OUTLINE (A/B/C) & THỬ TRÊN PERSONA (`report_mau`)

> **Truy vết Module**: `BM1_04_outline_thu_persona` (Kế thừa `LAB025/content-synthesizer` + **Làm mới** phần thử phản ứng trên 3 Persona Neo)
> **Đã gọi**: `LAB025/content-synthesizer` (30 insights -> 3 variants) + `BM1_04/thu_outline_persona.py`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Nén 30 Insights từ Tư liệu Nghiên cứu (`LAB025` Bước 5)
- Tổng số insights đã rút: **30 insights** (chia đều 4 nhóm: `fact`, `paradox`, `metaphor`, `provocation`).
- 10 Insights hạt nhân tiêu biểu:
  - `01` (fact): [Insight #01 · fact] 78% doanh nghiệp SME Việt Nam đã thử nghiệm công cụ AI nhưng chỉ 14% chuyển hoá thành quy trình chuẩn có đo lường đầu ra [BC01]. (Góc khai thác tầng 1)
  - `02` (paradox): [Insight #02 · paradox] Khoảng cách lớn nhất không nằm ở công nghệ mà ở khâu nghiệm thu chất lượng (Quality Gate) sau khi AI sinh kết quả [BC02]. (Góc khai thác tầng 1)
  - `03` (metaphor): [Insight #03 · metaphor] Đào tạo AI đại trà theo kiểu giới thiệu công cụ có tỷ lệ rơi rụng ứng dụng tới 82% sau 30 ngày kết thúc khoá học [BC03]. (Góc khai thác tầng 1)
  - `04` (provocation): [Insight #04 · provocation] Mô hình đào tạo gắn liền với sản phẩm thật (Output-based Training) giúp rút ngắn 42% thời gian soạn báo cáo và tài liệu nội bộ [BC04]. (Góc khai thác tầng 1)
  - `05` (fact): [Insight #05 · fact] Rủi ro bảo mật dữ liệu nội bộ là rào cản số 1 khiến khối Tài chính - Ngân hàng và Sản xuất dè dặt khi nhân rộng AI [BC05]. (Góc khai thác tầng 1)
  - `06` (paradox): [Insight #06 · paradox] Chi phí ẩn của AI Slop: Trung bình mỗi quản lý cấp trung mất 4,5 giờ/tuần chỉ để rà soát và viết lại các tài liệu do nhân viên dùng AI tạo ẩu [BC06]. (Góc khai thác tầng 1)
  - `07` (metaphor): [Insight #07 · metaphor] Phân tầng năng lực AI doanh nghiệp cần chia làm 3 mức: Thao tác cá nhân (Mức 1) -> Quy trình phòng ban (Mức 2) -> Hệ thống tự động có cổng kiểm (Mức 3) [BC07]. (Góc khai thác tầng 1)
  - `08` (provocation): [Insight #08 · provocation] Báo cáo quản trị hiện đại đòi hỏi mỗi trang là một thông điệp kết luận (Action Title) đi kèm biểu đồ định lượng trỏ về sổ bằng chứng [BC08]. (Góc khai thác tầng 1)
  - `09` (fact): [Insight #09 · fact] Doanh nghiệp áp dụng bộ tiêu chí kiểm văn và kiểm số tự động giảm 68% tỷ lệ trả lại hồ sơ giữa các phòng ban [BC09]. (Góc khai thác tầng 1)
  - `10` (paradox): [Insight #10 · paradox] Lộ trình 90 ngày hiệu quả nhất bắt đầu từ 1 nhóm Pilot 15-20 nhân sự nòng cốt thay vì đào tạo dàn trải toàn công ty [BC10]. (Góc khai thác tầng 1)

## 2. Ba phương án Outline A / B / C (`LAB025` Bước 6)

### Phương án A — Báo cáo tổng quan xu hướng AI toàn cầu & Việt Nam
- **Góc nhìn (`variant_angle`)**: Tổng hợp bức tranh vĩ mô về tốc độ phổ cập AI tại các ngành kinh tế
- **Giọng điệu (`variant_tone`)**: Vĩ mô, truyền thống
- **Cấu trúc (`variant_structure`)**: Bối cảnh thế giới -> Tình hình Việt Nam -> Dự báo 2026-2030
- **Tập Insights chọn (10 ý)**: `[1, 3, 5, 11, 13, 15, 17, 21, 25, 27]`
- **Dàn ý chi tiết**:
  - Trang 1: Tóm tắt điều hành (Executive Summary) về làn sóng AI
  - Trang 2-3: Số liệu tăng trưởng người dùng AI tại Đông Nam Á và Việt Nam
  - Trang 4-5: Các ngành nghề chịu tác động mạnh nhất
  - Trang 6: Khuyến nghị chung cho doanh nghiệp
- **Giai thoại / Tình huống gắn kèm**:
  - Đối chuẩn số liệu vĩ mô từ báo cáo ngành khu vực [BC01].

### Phương án B — Báo cáo Chẩn đoán Khoảng trống Năng lực AI & Lộ trình Đào tạo Thực chiến 90 ngày (Chuẩn McKinsey/Sakedemy)
- **Góc nhìn (`variant_angle`)**: Giải quyết trực diện bài toán ROI của CEO, bài toán thiết kế theo phòng ban của HRD và cổng an toàn dữ liệu của IT Lead
- **Giọng điệu (`variant_tone`)**: Tư vấn chiến lược sắc gọn (Action Title mỗi trang một kết luận + bằng chứng định lượng BC01..BC15 + cổng chất lượng 17 luật)
- **Cấu trúc (`variant_structure`)**: Chẩn đoán 3 điểm nghẽn (78% thử nghiệm vs 14% ra quy trình) -> Ma trận phân tầng 3 mức & 4 phòng ban -> Kiến trúc cổng kiểm chất lượng & an toàn dữ liệu -> Lộ trình Pilot 90 ngày có đo ROI
- **Tập Insights chọn (12 ý)**: `[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14]`
- **Dàn ý chi tiết**:
  - Trang 1 (Executive Summary): 78% doanh nghiệp đã dùng thử AI nhưng 86% mắc kẹt ở 'năng suất bề nổi' vì thiếu quy trình và cổng nghiệm thu [BC01, BC02]
  - Trang 2 (Giải phẫu Chi phí ẩn): Mỗi quản lý cấp trung đang mất 4,5 giờ/tuần dọn 'rác AI' do đào tạo mẹo câu lệnh rời rạc thay vì quy trình đầu ra [BC03, BC06]
  - Trang 3 (Khung Năng lực 3 Mức × 4 Khối phòng ban): Thiết kế may đo cho Kinh doanh, Marketing, Vận hành và Nhân sự - Tài chính [BC04, BC07]
  - Trang 4 (Cổng Kiểm soát Chất lượng & Bảo mật 2 lớp): Quy chế phân loại dữ liệu nhạy cảm và bộ lọc 17 luật chống ảo giác số liệu [BC05, BC09]
  - Trang 5 (Lộ trình Pilot 90 Ngày & Bảng đo ROI): Triển khai nhóm hạt nhân 20 người, nghiệm thu bằng sản phẩm thật và đo giờ công tiết kiệm thực tế [BC04, BC10]
- **Giai thoại / Tình huống gắn kèm**:
  - Case đối chuẩn nội bộ [BC04, BC09]: Áp dụng quy trình 9 bước + cổng kiểm tự động giúp giảm 68% tỷ lệ trả bài giữa người viết và người duyệt.

### Phương án C — Hồ sơ giới thiệu danh mục khoá học & giảng viên
- **Góc nhìn (`variant_angle`)**: Trình bày chi tiết nội dung các học phần và năng lực đội ngũ giảng dạy
- **Giọng điệu (`variant_tone`)**: Giới thiệu dịch vụ (Brochure/Credentials)
- **Cấu trúc (`variant_structure`)**: Giới thiệu đơn vị -> Danh sách các khoá học -> Hồ sơ giảng viên -> Báo giá khung
- **Tập Insights chọn (10 ý)**: `[3, 4, 7, 16, 18, 20, 22, 24, 28, 30]`
- **Dàn ý chi tiết**:
  - Trang 1: Giới thiệu tầm nhìn và sứ mệnh đào tạo
  - Trang 2-3: Chi tiết 6 học phần từ cơ bản đến nâng cao
  - Trang 4: Đội ngũ chuyên gia và hình ảnh lớp học
  - Trang 5: Quy trình tổ chức lớp học
- **Giai thoại / Tình huống gắn kèm**:
  - Tổng hợp hình ảnh lớp học doanh nghiệp thực tế.

## 3. [LÀM MỚI] Kết quả thử 3 Outline trên 3 Persona Neo (`P1`, `P2`, `P3`)

| Phương án | TB Khớp nỗi đau (/10) | TB Nguy cơ bỏ đọc (/10, thấp=tốt) | Điểm Persona Tổng hợp (/10) | Xếp hạng từ P1, P2, P3 |
|---|---:|---:|---:|---|
| **A** (Phương án A — Báo cáo tổng quan xu hướng AI toàn cầu & Việt Nam) | **6.23** | 5.83 | **4.19** | P1: #3, P2: #3, P3: #2 |
| **B** (Phương án B — Báo cáo Chẩn đoán Khoảng trống Năng lực AI & Lộ trình Đào tạo Thực chiến 90 ngày (Chuẩn McKinsey/Sakedemy)) | **9.17** | 1.57 | **8.62** | P1: #1, P2: #1, P3: #1 |
| **C** (Phương án C — Hồ sơ giới thiệu danh mục khoá học & giảng viên) | **5.8** | 6.17 | **3.64** | P1: #2, P2: #2, P3: #3 |

### Phản ứng chi tiết với Phương án A — Báo cáo tổng quan xu hướng AI toàn cầu & Việt Nam
- **P1 (CEO / Thành viên HĐQT duyệt ngân sách đào tạo & chuyển đổi AI)** — Khớp nỗi đau: `5.5/10` · Nguy cơ bỏ đọc: `6.8/10`:
  - *Chỗ dễ chán/bỏ đọc*: Trang 1: Tóm tắt điều hành (Executive Summary) về làn sóng AI
  - *Câu phản biện ngay từ dàn ý*: "[P1 cãi phương án A] 'Đào tạo xong đo bằng gì để chứng minh tiết kiệm được giờ công, hay chỉ phát chứng chỉ cho vui?' — Mở đầu bằng nguyên lý vĩ mô/học thuật thế này là tôi lướt qua ngay vì không giải quyết việc đang cháy."
  - *Kỳ vọng mang về*: Biết thêm khái niệm tổng quan nhưng chưa thấy cách áp vào việc ngày mai.
- **P2 (Giám đốc Nhân sự (HRD) / Trưởng bộ phận Đào tạo (L&D))** — Khớp nỗi đau: `5.8/10` · Nguy cơ bỏ đọc: `6.5/10`:
  - *Chỗ dễ chán/bỏ đọc*: Trang 1: Tóm tắt điều hành (Executive Summary) về làn sóng AI
  - *Câu phản biện ngay từ dàn ý*: "[P2 cãi phương án A] 'Chương trình đại trà kiểu này phòng Marketing nghe được chứ phòng Kế toán hay Vận hành ngồi nghe là họ bỏ về.' — Mở đầu bằng nguyên lý vĩ mô/học thuật thế này là tôi lướt qua ngay vì không giải quyết việc đang cháy."
  - *Kỳ vọng mang về*: Biết thêm khái niệm tổng quan nhưng chưa thấy cách áp vào việc ngày mai.
- **P3 (Trưởng phòng CNTT / Chuyển đổi số (IT/DX Lead - Người gác cổng bảo mật & hạ tầng))** — Khớp nỗi đau: `7.4/10` · Nguy cơ bỏ đọc: `4.2/10`:
  - *Chỗ dễ chán/bỏ đọc*: Trang 1: Tóm tắt điều hành (Executive Summary) về làn sóng AI
  - *Câu phản biện ngay từ dàn ý*: "[P3 cãi phương án A] 'Dạy dùng AI tăng tốc mà không có quy chế phân loại dữ liệu nhạy cảm thì một vụ lộ lọt là bay cả năm lợi nhuận.' — Mở đầu bằng nguyên lý vĩ mô/học thuật thế này là tôi lướt qua ngay vì không giải quyết việc đang cháy."
  - *Kỳ vọng mang về*: Biết thêm khái niệm tổng quan nhưng chưa thấy cách áp vào việc ngày mai.

### Phản ứng chi tiết với Phương án B — Báo cáo Chẩn đoán Khoảng trống Năng lực AI & Lộ trình Đào tạo Thực chiến 90 ngày (Chuẩn McKinsey/Sakedemy)
- **P1 (CEO / Thành viên HĐQT duyệt ngân sách đào tạo & chuyển đổi AI)** — Khớp nỗi đau: `9.2/10` · Nguy cơ bỏ đọc: `1.5/10`:
  - *Chỗ dễ chán/bỏ đọc*: Không có mục sáo rỗng; cần lưu ý giữ nhịp gọn ở phần chuyển từ chẩn đoán sang giải pháp.
  - *Câu phản biện ngay từ dàn ý*: "[P1 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung."
  - *Kỳ vọng mang về*: Khung phân tầng năng lực rõ ràng, chỉ số đo lường trước-sau (KPI/ROI) và lộ trình triển khai 90 ngày không làm đứt gãy vận hành.
- **P2 (Giám đốc Nhân sự (HRD) / Trưởng bộ phận Đào tạo (L&D))** — Khớp nỗi đau: `9.4/10` · Nguy cơ bỏ đọc: `1.4/10`:
  - *Chỗ dễ chán/bỏ đọc*: Không có mục sáo rỗng; cần lưu ý giữ nhịp gọn ở phần chuyển từ chẩn đoán sang giải pháp.
  - *Câu phản biện ngay từ dàn ý*: "[P2 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung."
  - *Kỳ vọng mang về*: Bảng ma trận thiết kế chương trình may đo theo nhóm việc và cơ chế nghiệm thu sản phẩm đầu ra ngay tại lớp.
- **P3 (Trưởng phòng CNTT / Chuyển đổi số (IT/DX Lead - Người gác cổng bảo mật & hạ tầng))** — Khớp nỗi đau: `8.9/10` · Nguy cơ bỏ đọc: `1.8/10`:
  - *Chỗ dễ chán/bỏ đọc*: Không có mục sáo rỗng; cần lưu ý giữ nhịp gọn ở phần chuyển từ chẩn đoán sang giải pháp.
  - *Câu phản biện ngay từ dàn ý*: "[P3 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung."
  - *Kỳ vọng mang về*: Bộ quy tắc an toàn dữ liệu và quy trình kiểm chứng 2 lớp được tích hợp sẵn trong khung đào tạo.

### Phản ứng chi tiết với Phương án C — Hồ sơ giới thiệu danh mục khoá học & giảng viên
- **P1 (CEO / Thành viên HĐQT duyệt ngân sách đào tạo & chuyển đổi AI)** — Khớp nỗi đau: `5.8/10` · Nguy cơ bỏ đọc: `6.2/10`:
  - *Chỗ dễ chán/bỏ đọc*: Trang 2-3: Chi tiết 6 học phần từ cơ bản đến nâng cao
  - *Câu phản biện ngay từ dàn ý*: "[P1 cãi phương án C] Liệt kê mẹo/danh mục kiểu này trên mạng có hàng trăm bài, đọc xong vẫn không giải quyết được xung đột quy trình trong công ty."
  - *Kỳ vọng mang về*: Có vài gạch đầu dòng tham khảo nhanh nhưng thiếu chiều sâu hệ thống.
- **P2 (Giám đốc Nhân sự (HRD) / Trưởng bộ phận Đào tạo (L&D))** — Khớp nỗi đau: `6.7/10` · Nguy cơ bỏ đọc: `4.8/10`:
  - *Chỗ dễ chán/bỏ đọc*: Trang 2-3: Chi tiết 6 học phần từ cơ bản đến nâng cao
  - *Câu phản biện ngay từ dàn ý*: "[P2 cãi phương án C] Liệt kê mẹo/danh mục kiểu này trên mạng có hàng trăm bài, đọc xong vẫn không giải quyết được xung đột quy trình trong công ty."
  - *Kỳ vọng mang về*: Có vài gạch đầu dòng tham khảo nhanh nhưng thiếu chiều sâu hệ thống.
- **P3 (Trưởng phòng CNTT / Chuyển đổi số (IT/DX Lead - Người gác cổng bảo mật & hạ tầng))** — Khớp nỗi đau: `4.9/10` · Nguy cơ bỏ đọc: `7.5/10`:
  - *Chỗ dễ chán/bỏ đọc*: Trang 2-3: Chi tiết 6 học phần từ cơ bản đến nâng cao
  - *Câu phản biện ngay từ dàn ý*: "[P3 cãi phương án C] Liệt kê mẹo/danh mục kiểu này trên mạng có hàng trăm bài, đọc xong vẫn không giải quyết được xung đột quy trình trong công ty."
  - *Kỳ vọng mang về*: Có vài gạch đầu dòng tham khảo nhanh nhưng thiếu chiều sâu hệ thống.

