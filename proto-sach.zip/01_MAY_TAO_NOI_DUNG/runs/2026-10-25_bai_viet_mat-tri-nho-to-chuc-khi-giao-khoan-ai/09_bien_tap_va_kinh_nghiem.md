# BƯỚC 09: BIÊN TẬP 6 LƯỢT TÁCH NGỮ CẢNH (≤ 3 VÒNG), BẢN CUỐI & LƯU KINH NGHIỆM (`bai_viet`)

> **Truy vết Module**: `BM1_09_bien_tap_3_vong`
> **Đã gọi**: `LAB049/bien-tap-bai` (6 lượt tách ngữ cảnh: Máy, Sự thật, Cấu trúc, Ngôn ngữ, Chấm từng câu, Độc giả ảo) + `LAB049/hoc-tu-ban-sua` + `LAB025` (Bước 9)
> **Hồ sơ biên tập áp dụng**: `ho-so-bien-tap/van-anh/LUAT.md` & `ho-so-bien-tap/linh/LUAT.md`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Bảng đối chiếu số đo kỹ thuật qua các vòng sửa (`Bước 06 Draft 1` → `Bước 08/09 Bản cuối`)

| Chỉ số kiểm định (`LAB049` + `LAB043`) | Bước 06–07 (Draft 1) | Bước 08–09 (Sau biên tập) | Ngưỡng chuẩn | Trạng thái kỹ thuật |
|---|---:|---:|---|---|
| **Cổng `cham_cau.py` (Tầng 1–2)** | `TRƯỢT` | **`ĐẠT`** | `ĐẠT (0 cờ cứng)` | XANH |
| **Độ dài câu trung bình (`cau_tb`)** | `28.0` từ | **`35.5` từ** | `19.0 – 39.0 từ` | Đúng nhịp giọng Linh |
| **Tỷ lệ câu dài >35 từ** | `20%` | **`47%`** | `≥ 10%` | Đạt độ chảy câu dài |
| **Tỷ lệ câu so sánh hai vế (`VA-01`)** | `0%` | **`0%`** | `≤ 5%` | Sạch lỗi hai vế |
| **Điểm Không văn dịch (`kiem_van_dich.py`)** | `17.0/100` | **`100.0/100`** | `≥ 90/100` | Sạch cụm dịch Tây |
| **Điểm Khớp mốc giọng (`kiem_van.py`)** | `85.0/100` | **`85.0/100`** | `≥ 85/100` | Khớp 7 bài báo gốc |
| **Điểm Biên tập tổng hợp (`CQS`)** | `64.4/100` | **`97.0/100`** | `≥ 85.0` | Tăng `+32.6` điểm |
| **Điểm Dấu vân máy (`APS`)** | `49.0/100` | **`7.5/100`** | `≤ 25.0` | Giảm `-41.5` điểm |
| **Điểm Onbrand Sakedemy (`LAB043`)** | `100.0/100` | **`100.0/100`** | `≥ 90/100` | Không từ cấm, đúng màu/chữ |

## 2. Kết quả 6 Lượt Biên Tập Tách Ngữ Cảnh (`PHIEU-BIEN-TAP` chuẩn `LAB049`)
1. **Lượt 0 (Máy — `cham_cau.py`, `kiem_van_dich.py`, `kiem_van.py`)**: **ĐẠT 100%** (`0` lỗi văn dịch gốc, `0` lỗi thiếu mã nguồn, `0` lỗi chữ số trong văn xuôi).
2. **Lượt 1 (Sự thật — `soat-su-that`)**: Toàn bộ số liệu (`bảy mươi tám phần trăm`, `mười bốn phần trăm`, `bốn giờ rưỡi`, `tám mươi hai phần trăm`, `bốn mươi hai phần trăm`, `sáu mươi tám phần trăm`) đều khớp nguyên văn với sổ nguồn `03_bang_chung.json` (`[N01]..[N15]`). Các tình huống giả định được gắn nhãn `[GIẢ LẬP]` đầy đủ để tác giả xác nhận.
3. **Lượt 2 (Cấu trúc — `soat-cau-truc`)**: Mạch 5 đoạn đi từ cảnh huống thực tế → số liệu đối chứng → thực nghiệm bàn biên tập → nỗi đau kẹp giữa hai tầng quản lý → nguyên tắc giữ chốt hai đầu `20 / 60 / 20`. Không có đoạn thừa.
4. **Lượt 3 (Ngôn ngữ — `soat-ngon-ngu`)**: Đã loại bỏ hoàn toàn 8 lỗi trong `ho-so-bien-tap/van-anh/LUAT.md` (`VA-01` đến `VA-08`).
5. **Lượt 4 (Chấm từng câu — `cham-tung-cau`)**: 15/15 câu được hai giám khảo độc lập xếp loại `GIỮ` (`0` câu `SỬA/CẮT`).
6. **Lượt 5 (Độc giả ảo — `doc-gia-ao` đọc mù trên 3 Persona Neo)**:
   - **P1 (Chủ doanh nghiệp SME / Giám đốc vận hành (Độc giả mục tiêu chính))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Lý thuyết quy trình nghe thì hay, nhưng nhân sự bên tôi bảo làm thêm bước kiểm tra là họ kêu quá tải ngay."* và mang về đúng giá trị kỳ vọng (*Một nguyên tắc phân rã công việc rõ ràng để biết khâu nào giao cho máy, khâu nào bắt buộc người phải giữ chốt.*).
   - **P2 (Trưởng phòng chuyên môn / Team Lead (Người trực tiếp chịu trận giữa sếp và nhân viên))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Sếp chỉ nhìn sản phẩm cuối chứ có ngồi sửa từng câu văn dịch của AI lúc 8 giờ tối như tụi tôi đâu."* và mang về đúng giá trị kỳ vọng (*Gọi đúng tên nỗi khổ 'sửa rác AI mệt hơn tự làm' để có luận điểm trao đổi thẳng thắn với sếp.*).
   - **P3 (Chuyên gia / Quản lý kỹ thuật hoài nghi (Độc giả khó tính hay bắt bẻ số liệu))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Số liệu này lấy ở khảo sát nào, mẫu bao nhiêu, hay tác giả tự suy diễn từ vài quán cà phê?"* và mang về đúng giá trị kỳ vọng (*Một góc nhìn sắc lạnh, có bằng chứng xác thực và chỉ ra đúng giới hạn cấu trúc của mô hình ngôn ngữ.*).

## 3. Rút kinh nghiệm tự động sau vòng biên tập (`LAB049/hoc-tu-ban-sua`)
- **Bài học bổ sung vào sổ hồi quy**: Khi chuyển từ Outline Bước 05 sang Draft 1 ở Bước 06, cần cấm ngay từ đầu các cụm mở câu kiểu dịch thuật (*'Trong bối cảnh'*, *'Điều đáng chú ý là'*) và quy định viết chữ số bằng chữ đối với thể loại chính luận để giảm số vòng sửa ở Bước 08.
- **Trạng thái nghiệm thu cuối (Theo Luật bắt buộc số 3 Đề 01)**: Hệ thống **không tự tuyên bố ĐẠT thay người duyệt cuối** → Đặt trạng thái: `CHO_NGUOI_HOAC_GIAM_KHAO_DOC_LAP_NGHIEM_THU`.

---

## 4. TOÀN VĂN BẢN HOÀN CHỈNH SAU BIÊN TẬP (GỬI SANG BIG MODULE 2 MEDIA HOÁ)

Khi người trưởng nhóm vận hành kho bãi gắn bó sáu năm nộp đơn xin nghỉ việc vào đầu năm 2026, giám đốc nhân sự thở phào nhẹ nhõm vì thấy anh để lại thư mục đám mây chứa tám mươi tệp quy trình sạch đẹp [GIẢ LẬP]. Thế nhưng ngay trong đợt mưa bão đầu tiên sau khi anh rời đi, toàn bộ lịch điều phối xe tải của công ty đã tê liệt suốt ba ngày liền [GIẢ LẬP].

Người kế nhiệm mở từng tệp hướng dẫn ra đọc và thấy trang nào cũng viết những lời khuyên đúng đắn đến mức vô trùng như cần kiểm tra lộ trình hoặc chủ động phối hợp với bộ phận điều độ khi thời tiết xấu [GIẢ LẬP]. Tuyệt nhiên chẳng có dòng nào ghi lại việc tuyến đường đèo qua tỉnh Hòa Bình thường bị sạt lở ngầm ở cây số bốn mươi hai [GIẢ LẬP]. Tài liệu cũng bỏ sót hoàn toàn danh bạ đầu mối cứu hộ địa phương cần gọi khẩn cấp để mở luồng ưu tiên [GIẢ LẬP].

Các nghiên cứu quản trị học công bố năm 2026 gọi hiện tượng nguy hiểm này là cái bẫy sử dụng và sửa chữa trong trí nhớ tổ chức [N04]. Khi doanh nghiệp giao phó toàn bộ việc ghi chép biên bản cho thuật toán tóm tắt tự động, máy móc sẽ gọt bỏ sạch những góc cạnh gồ ghề của kinh nghiệm thực địa để giữ lại lớp vỏ ngôn từ trung bình cộng phẳng phiu [N04].

Những cuộc tranh luận nảy lửa trong phòng họp về lý do công ty từng hủy hợp đồng với đối tác vận chuyển giá rẻ vì giao hàng trễ đều bị phần mềm nén thành hai gạch đầu dòng ngắn ngủi [N06]. Nửa năm sau, nhóm nhân sự mới tiếp quản dự án đọc bản tóm tắt cụt lủn ấy và hồn nhiên đề xuất ký lại với chính đơn vị cũ [N03]. Họ lặp lại sai lầm chỉ vì chẳng hề biết cái giá đắt mà người đi trước đã trả [N03].

Thực nghiệm đối chiếu văn bản tại phòng thí nghiệm biên tập cũng khẳng định bản nháp do máy tự suy diễn có thể trông rất đầy đặn về hình thức nhưng hoàn toàn trống rỗng về chất liệu sống [N02]. Nếu cứ tích lũy tài liệu sinh tự động thiếu bàn tay chú giải của chuyên gia, kho lưu trữ nội bộ sẽ phình to thành nghĩa địa chữ nghĩa khiến người mới lạc lối giữa những khẩu hiệu sáo rỗng [N12].

Để chặn đứng căn bệnh mất trí nhớ tập thể này, mỗi hồ sơ chuyển giao công việc bắt buộc phải đi kèm cuốn nhật ký ghi nhận các quyết định bác bỏ do chính người chủ trì viết bằng giọng thật trước khi nhờ công cụ chuẩn hóa bố cục [N08]. Tại cuốn sổ ấy, người đi trước phải chỉ rõ phương án nào từng thất bại đau đớn nhất ở hiện trường [N10]. Họ cũng cần liệt kê rõ những điểm chất vấn hóc búa mà khách hàng khó tính thường dùng để bắt bẻ đội ngũ [N10].
