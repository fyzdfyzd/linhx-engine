# BƯỚC 04: 30 INSIGHTS, 3 HƯỚNG OUTLINE (A/B/C) & THỬ TRÊN PERSONA (`de_xuat_pilot`)

> **Truy vết Module**: `BM1_04_outline_thu_persona` (Kế thừa `LAB025/content-synthesizer` + **Làm mới** phần thử phản ứng trên 3 Persona Neo)
> **Đã gọi**: `LAB025/content-synthesizer` (30 insights -> 3 variants) + `BM1_04/thu_outline_persona.py`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu (Gemini 2.5 Flash)

## 1. Nén 30 Insights từ Tư liệu Nghiên cứu (`LAB025` Bước 5)
- Tổng số insights đã rút: **30 insights** (chia đều 4 nhóm: `fact`, `paradox`, `metaphor`, `provocation`).
- 10 Insights hạt nhân tiêu biểu:
  - `01` (fact): [Bối cảnh thực tế] Mặc dù 88% doanh nghiệp đã triển khai AI, chỉ 39% trong số đó ghi nhận tác động tích cực đến EBIT (McKinsey [N02]). Điều này cho thấy việc áp dụng công nghệ mà thiếu quy trình chuẩn hóa có thể không mang lại hiệu quả kinh doanh mong muốn.
  - `02` (paradox): [Điểm nghẽn vận hành] Khảo sát thực địa của Sakedemy cho thấy 30% giờ làm việc bị hao hụt do phải dọn dẹp và chỉnh sửa các sản phẩm AI kém chất lượng hoặc báo cáo thiếu chuẩn hóa. Đây là một điểm nghẽn nghiêm trọng ảnh hưởng đến năng suất và chi phí ẩn của doanh nghiệp.
  - `03` (metaphor): [Bằng chứng định lượng] HBR Workslop chỉ ra rằng 40% thời gian làm việc của nhân viên được dành cho các tác vụ hành chính, bao gồm việc kiểm tra và chỉnh sửa báo cáo. Việc chuẩn hóa quy trình có thể giảm đáng kể con số này, giải phóng thời gian cho các hoạt động có giá trị cao hơn [N01].
  - `04` (provocation): [Quy trình chuyển đổi] Quy tắc 10-20-70 của BCG nhấn mạnh rằng 70% thành công của chuyển đổi nằm ở yếu tố con người và quy trình, không chỉ công nghệ [N03]. Do đó, việc tập trung vào chuẩn hóa quy trình kiểm soát chất lượng là yếu tố then chốt.
  - `05` (fact): [Công cụ áp dụng ngay] Đề xuất sẽ cung cấp các mẫu biểu, checklist và hướng dẫn chi tiết để nhân viên có thể áp dụng ngay lập tức, giảm thiểu thời gian đào tạo và tăng tốc độ triển khai.
  - `06` (paradox): [Chỉ số đo lường] Các chỉ số đo lường bao gồm: giảm thời gian chỉnh sửa báo cáo (mục tiêu 6 giờ/tuần), tăng tỷ lệ báo cáo đạt chuẩn ngay lần đầu, và cải thiện mức độ hài lòng của người nhận báo cáo.
  - `07` (metaphor): [Insight #07 · metaphor] Nhân sự cấp dưới dùng AI như tấm khiên né tránh trách nhiệm cá nhân: 'Máy nó gợi ý thế' [N07]. (Góc khai thác tầng 1)
  - `08` (provocation): [Insight #08 · provocation] Cấp quản lý giao việc kiểu 'hỏi ChatGPT đi' chính là nguồn gốc sinh ra làn sóng báo cáo vô hồn trong nội bộ [N08]. (Góc khai thác tầng 1)
  - `09` (fact): [Insight #09 · fact] Một quy trình tốt tách bạch hoàn toàn ngữ cảnh người viết và ngữ cảnh người biên tập sáu lượt [N09]. (Góc khai thác tầng 1)
  - `10` (paradox): [Insight #10 · paradox] Độc giả báo kinh tế bỏ đọc ngay khi gặp cấu trúc so sánh hai vế máy móc 'Không còn là X mà là Y' [N10]. (Góc khai thác tầng 1)

## 2. Ba phương án Outline A / B / C (`LAB025` Bước 6)

### Hướng A — Đi từ Số liệu Vĩ mô & Cảnh báo Hệ thống
- **Góc nhìn (`variant_angle`)**: Trong bối cảnh 88% doanh nghiệp đã triển khai AI nhưng chỉ 39% ghi nhận tác động tích cực đến EBIT (McKinsey [N02]), việc chuẩn hóa quy trình kiểm soát chất lượng báo cáo không chỉ là một mục tiêu tiết kiệm 6 giờ làm việc mỗi tuần mà còn là yếu tố sống còn để chuyển đổi AI thực sự mang lại giá trị cho doanh nghiệp Việt Nam vào năm 2026.
- **Giọng điệu (`variant_tone`)**:  Chuẩn giọng Đề xuất triển khai thí điểm 90 ngày
- **Cấu trúc (`variant_structure`)**: 1. Tóm tắt điều hành -> 2. Phân tích bối cảnh -> 3. Chẩn đoán điểm nghẽn -> 4. Đề xuất thí điểm 90 ngày
- **Tập Insights chọn (10 ý)**: `[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]`
- **Dàn ý chi tiết**:
  - 1. Tóm tắt điều hành: Tại sao 6 giờ làm việc mỗi tuần là con số quan trọng?
  - 2. Phân tích bối cảnh: Chi phí ẩn của báo cáo kém chất lượng trong kỷ nguyên AI (Dẫn chứng HBR Workslop [N01], McKinsey [N02])
  - 3. Chẩn đoán điểm nghẽn: 30% giờ làm việc bị hao hụt vì 'dọn dẹp' sản phẩm AI kém chất lượng (Khảo sát Sakedemy [N04])
  - 4. Đề xuất thí điểm 90 ngày: Lộ trình 3 giai đoạn chuẩn hóa quy trình kiểm soát chất lượng báo cáo
  - 5. Khung hành động & bảng kiểm: Đảm bảo thu hồi 6 giờ làm việc mỗi tuần và nâng cao chất lượng báo cáo
- **Giai thoại / Tình huống gắn kèm**:
  - Trong bối cảnh 88% doanh nghiệp đã triển khai AI nhưng chỉ 39% ghi nhận tác động tích cực đến EBIT (McKinsey [N02]), việc chuẩn hóa quy trình kiểm soát chất lượng báo cáo không chỉ là một mục tiêu tiết kiệm 6 giờ làm việc mỗi tuần mà còn là yếu tố sống còn để chuyển đổi AI thực sự mang lại giá trị cho doanh nghiệp Việt Nam vào năm 2026.
  - Đối chiếu tiêu chí bắt buộc của Đề xuất triển khai thí điểm 90 ngày: Chẩn đoán điểm nghẽn thời gian thực tế tại phòng ban trước khi thí điểm, Bảng đối chiếu chỉ số đầu ra Trước và Sau 90 ngày thí điểm.

### Hướng B — Đi từ Tình huống Thực tế tại Doanh nghiệp, Đối chiếu Trước/Sau & Bảng kiểm Áp dụng Ngay
- **Góc nhìn (`variant_angle`)**: Hãy hình dung cảnh tượng quen thuộc tại văn phòng Việt Nam: 6 giờ làm việc mỗi tuần bị hao phí vào việc rà soát, chỉnh sửa những báo cáo thiếu chuẩn hóa, một con số mà khảo sát thực địa của Sakedemy [N04] đã chỉ ra là chi phí ẩn đáng kể. Đề xuất thí điểm 90 ngày này sẽ trực tiếp giải quyết vấn đề đó, chuẩn hóa quy trình kiểm soát chất lượng báo cáo và thu hồi lại chính xác 6 giờ làm việc đó cho doanh nghiệp vào năm 2026.
- **Giọng điệu (`variant_tone`)**:  Chuẩn giọng Đề xuất triển khai thí điểm 90 ngày
- **Cấu trúc (`variant_structure`)**: 1. Tóm tắt điều hành -> 2. Chẩn đoán điểm nghẽn thời gian thực tế -> 3. Phân tích nguyên nhân gốc rễ -> 4. Bảng đối chiếu chỉ số đầu ra Trước và Sau 90 ngày thí điểm
- **Tập Insights chọn (10 ý)**: `[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]`
- **Dàn ý chi tiết**:
  - 1. Tóm tắt điều hành: 6 giờ làm việc bị lãng phí – Chi phí ẩn không thể chấp nhận
  - 2. Chẩn đoán điểm nghẽn thời gian thực tế: Tình huống thực tế tại phòng ban và chi phí ẩn của báo cáo kém chất lượng (Dẫn chứng Sakedemy [N04])
  - 3. Phân tích nguyên nhân gốc rễ: Quy tắc 10-20-70 của BCG và vai trò của con người & quy trình trong kiểm soát chất lượng [N03]
  - 4. Bảng đối chiếu chỉ số đầu ra Trước và Sau 90 ngày thí điểm: Minh chứng định lượng cho mục tiêu thu hồi 6 giờ làm việc
  - 5. Lộ trình 3 giai đoạn (Tuần 1-4, Tuần 5-8, Tuần 9-12) và tiêu chí nghiệm thu: Chuẩn hóa quy trình kiểm soát chất lượng báo cáo
- **Giai thoại / Tình huống gắn kèm**:
  - Hãy hình dung cảnh tượng quen thuộc tại văn phòng Việt Nam: 6 giờ làm việc mỗi tuần bị hao phí vào việc rà soát, chỉnh sửa những báo cáo thiếu chuẩn hóa, một con số mà khảo sát thực địa của Sakedemy [N04] đã chỉ ra là chi phí ẩn đáng kể. Đề xuất thí điểm 90 ngày này sẽ trực tiếp giải quyết vấn đề đó, chuẩn hóa quy trình kiểm soát chất lượng báo cáo và thu hồi lại chính xác 6 giờ làm việc đó cho doanh nghiệp vào năm 2026.
  - Đối chiếu tiêu chí bắt buộc của Đề xuất triển khai thí điểm 90 ngày: Chẩn đoán điểm nghẽn thời gian thực tế tại phòng ban trước khi thí điểm, Bảng đối chiếu chỉ số đầu ra Trước và Sau 90 ngày thí điểm.

### Hướng C — Đi thẳng vào Cẩm nang Thao tác Nhanh & Mẫu biểu Thực hành
- **Góc nhìn (`variant_angle`)**: Bạn có muốn thu hồi 6 giờ làm việc mỗi tuần ngay tại bàn làm việc của mình, chỉ bằng cách áp dụng một cẩm nang thao tác nhanh để chuẩn hóa quy trình kiểm soát chất lượng báo cáo? Đề xuất thí điểm 90 ngày này sẽ cung cấp chính xác điều đó cho doanh nghiệp Việt Nam vào năm 2026.
- **Giọng điệu (`variant_tone`)**:  Chuẩn giọng Đề xuất triển khai thí điểm 90 ngày
- **Cấu trúc (`variant_structure`)**: 1. Tóm tắt điều hành -> 2. Hướng dẫn thao tác nhanh -> 3. Mẫu biểu thực hành -> 4. Lộ trình 90 ngày
- **Tập Insights chọn (10 ý)**: `[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]`
- **Dàn ý chi tiết**:
  - 1. Tóm tắt điều hành: Cẩm nang 90 ngày – Giải pháp tức thì cho 6 giờ làm việc bị lãng phí
  - 2. Hướng dẫn thao tác nhanh: 3 bước chuẩn hóa báo cáo ngay lập tức
  - 3. Mẫu biểu thực hành: Checklist kiểm soát chất lượng báo cáo & Phiếu đánh giá nhanh
  - 4. Lộ trình 90 ngày: Áp dụng và tối ưu hóa cẩm nang thực hành
- **Giai thoại / Tình huống gắn kèm**:
  - Bạn có muốn thu hồi 6 giờ làm việc mỗi tuần ngay tại bàn làm việc của mình, chỉ bằng cách áp dụng một cẩm nang thao tác nhanh để chuẩn hóa quy trình kiểm soát chất lượng báo cáo? Đề xuất thí điểm 90 ngày này sẽ cung cấp chính xác điều đó cho doanh nghiệp Việt Nam vào năm 2026.
  - Đối chiếu tiêu chí bắt buộc của Đề xuất triển khai thí điểm 90 ngày: Chẩn đoán điểm nghẽn thời gian thực tế tại phòng ban trước khi thí điểm, Bảng đối chiếu chỉ số đầu ra Trước và Sau 90 ngày thí điểm.

## 3. [LÀM MỚI] Kết quả thử 3 Outline trên 3 Persona Neo (`P1`, `P2`, `P3`)

| Phương án | TB Khớp nỗi đau (/10) | TB Nguy cơ bỏ đọc (/10, thấp=tốt) | Điểm Persona Tổng hợp (/10) | Xếp hạng từ P1, P2, P3 |
|---|---:|---:|---:|---|
| **A** (Hướng A — Đi từ Số liệu Vĩ mô & Cảnh báo Hệ thống) | **7.8** | 2.7 | **6.99** | P1: #2, P2: #3, P3: #3 |
| **B** (Hướng B — Đi từ Tình huống Thực tế tại Doanh nghiệp, Đối chiếu Trước/Sau & Bảng kiểm Áp dụng Ngay) | **9.17** | 1.33 | **8.77** | P1: #1, P2: #1, P3: #1 |
| **C** (Hướng C — Đi thẳng vào Cẩm nang Thao tác Nhanh & Mẫu biểu Thực hành) | **8.33** | 2.17 | **7.68** | P1: #3, P2: #2, P3: #1 |

### Phản ứng chi tiết với Hướng A — Đi từ Số liệu Vĩ mô & Cảnh báo Hệ thống
- **P1 (CEO / Thành viên HĐQT duyệt ngân sách đào tạo & chuyển đổi AI)** — Khớp nỗi đau: `8.1/10` · Nguy cơ bỏ đọc: `2.4/10`:
  - *Chỗ dễ chán/bỏ đọc*: Chưa đi sâu vào chi tiết triển khai và các bước hành động cụ thể cho từng phòng ban.
  - *Câu phản biện ngay từ dàn ý*: "Cách tiếp cận từ số liệu vĩ mô và cảnh báo hệ thống giúp tôi nhìn thấy bức tranh lớn về tác động đến lợi nhuận và chiến lược dài hạn. Tuy nhiên, tôi muốn thấy rõ hơn về ROI cụ thể và các rủi ro tiềm ẩn."
  - *Kỳ vọng mang về*: Dữ liệu mạnh mẽ, liên kết trực tiếp với hiệu quả kinh doanh và chiến lược AI.
- **P2 (Giám đốc Nhân sự (HRD) / Trưởng bộ phận Đào tạo (L&D))** — Khớp nỗi đau: `7.8/10` · Nguy cơ bỏ đọc: `2.7/10`:
  - *Chỗ dễ chán/bỏ đọc*: Thiếu chi tiết về chương trình đào tạo, công cụ hỗ trợ cho nhân viên và kế hoạch quản lý sự thay đổi.
  - *Câu phản biện ngay từ dàn ý*: "Tôi đánh giá cao việc đề cập đến chi phí ẩn và tác động đến năng suất nhân viên. Cần làm rõ hơn về kế hoạch đào tạo và thay đổi văn hóa để đảm bảo nhân viên thích nghi với quy trình mới."
  - *Kỳ vọng mang về*: Nhấn mạnh tác động đến năng suất và thời gian làm việc của nhân viên.
- **P3 (Trưởng phòng CNTT / Chuyển đổi số (IT/DX Lead - Người gác cổng bảo mật & hạ tầng))** — Khớp nỗi đau: `7.5/10` · Nguy cơ bỏ đọc: `3.0/10`:
  - *Chỗ dễ chán/bỏ đọc*: Chưa rõ ràng về yêu cầu công nghệ, tích hợp hệ thống, bảo mật và khả năng mở rộng của giải pháp.
  - *Câu phản biện ngay từ dàn ý*: "Việc liên kết với AI là hợp lý, nhưng tôi cần biết rõ hơn về các công cụ công nghệ cụ thể sẽ được sử dụng để chuẩn hóa quy trình và tích hợp chúng vào hạ tầng hiện có. Liệu có yêu cầu về bảo mật dữ liệu không?"
  - *Kỳ vọng mang về*: Đề cập đến vai trò của AI và tầm quan trọng của quy trình trong bối cảnh chuyển đổi số.

### Phản ứng chi tiết với Hướng B — Đi từ Tình huống Thực tế tại Doanh nghiệp, Đối chiếu Trước/Sau & Bảng kiểm Áp dụng Ngay
- **P1 (CEO / Thành viên HĐQT duyệt ngân sách đào tạo & chuyển đổi AI)** — Khớp nỗi đau: `9.3/10` · Nguy cơ bỏ đọc: `1.2/10`:
  - *Chỗ dễ chán/bỏ đọc*: Có thể bổ sung thêm về tác động dài hạn và khả năng mở rộng ra các phòng ban khác.
  - *Câu phản biện ngay từ dàn ý*: "Cách tiếp cận này rất thực tế và dễ hình dung. Việc có bảng đối chiếu trước/sau và lộ trình rõ ràng giúp tôi tin tưởng vào khả năng đạt được mục tiêu. Tôi thích sự tập trung vào giải quyết vấn đề cụ thể."
  - *Kỳ vọng mang về*: Thực tế, có số liệu đối chiếu rõ ràng, lộ trình cụ thể và giải quyết đúng 'nỗi đau' về chi phí ẩn.
- **P2 (Giám đốc Nhân sự (HRD) / Trưởng bộ phận Đào tạo (L&D))** — Khớp nỗi đau: `9.2/10` · Nguy cơ bỏ đọc: `1.3/10`:
  - *Chỗ dễ chán/bỏ đọc*: Cần làm rõ hơn về các công cụ hỗ trợ đào tạo và tài liệu hướng dẫn cho nhân viên.
  - *Câu phản biện ngay từ dàn ý*: "Đây là hướng đi tôi mong muốn! Việc chẩn đoán điểm nghẽn thực tế và phân tích nguyên nhân gốc rễ giúp tôi hiểu rõ hơn về nhu cầu đào tạo. Lộ trình 3 giai đoạn và tiêu chí nghiệm thu rất hữu ích cho việc lập kế hoạch triển khai."
  - *Kỳ vọng mang về*: Rất chi tiết về quy trình, lộ trình và tiêu chí nghiệm thu, giúp dễ dàng lập kế hoạch đào tạo và quản lý sự thay đổi.
- **P3 (Trưởng phòng CNTT / Chuyển đổi số (IT/DX Lead - Người gác cổng bảo mật & hạ tầng))** — Khớp nỗi đau: `9.0/10` · Nguy cơ bỏ đọc: `1.5/10`:
  - *Chỗ dễ chán/bỏ đọc*: Cần có một phần riêng về các yêu cầu kỹ thuật tối thiểu và khả năng tương thích với hệ thống hiện có.
  - *Câu phản biện ngay từ dàn ý*: "Sơ đồ quy trình 3 bước và bảng đối chiếu trước/sau rất trực quan. Tôi có thể hình dung được cách tích hợp các công cụ hỗ trợ vào quy trình này. Việc tập trung vào quy trình giúp giảm thiểu rủi ro công nghệ."
  - *Kỳ vọng mang về*: Sơ đồ quy trình rõ ràng, dễ hiểu, giúp hình dung việc tích hợp công nghệ. Tập trung vào quy trình giảm rủi ro công nghệ.

### Phản ứng chi tiết với Hướng C — Đi thẳng vào Cẩm nang Thao tác Nhanh & Mẫu biểu Thực hành
- **P1 (CEO / Thành viên HĐQT duyệt ngân sách đào tạo & chuyển đổi AI)** — Khớp nỗi đau: `7.7/10` · Nguy cơ bỏ đọc: `2.8/10`:
  - *Chỗ dễ chán/bỏ đọc*: Thiếu bối cảnh chiến lược, phân tích chi phí/lợi ích tổng thể và tác động dài hạn đến doanh nghiệp.
  - *Câu phản biện ngay từ dàn ý*: "Cách tiếp cận này rất thực tế và tập trung vào hành động. Tuy nhiên, tôi cần một cái nhìn tổng thể hơn về tác động chiến lược và ROI, không chỉ là các bước thực hành. Nó có vẻ quá 'thực hành' mà thiếu 'tầm nhìn'."
  - *Kỳ vọng mang về*: Tập trung vào hành động, dễ hiểu và có thể áp dụng ngay.
- **P2 (Giám đốc Nhân sự (HRD) / Trưởng bộ phận Đào tạo (L&D))** — Khớp nỗi đau: `8.5/10` · Nguy cơ bỏ đọc: `2.0/10`:
  - *Chỗ dễ chán/bỏ đọc*: Thiếu phần về đánh giá hiệu quả đào tạo và kế hoạch duy trì sự thay đổi sau 90 ngày.
  - *Câu phản biện ngay từ dàn ý*: "Cẩm nang thao tác nhanh và mẫu biểu thực hành là tài liệu tuyệt vời cho việc đào tạo và hướng dẫn nhân viên. Tôi có thể dễ dàng tích hợp chúng vào các chương trình đào tạo hiện có. Tuy nhiên, cần bổ sung thêm về cách đo lường hiệu quả đào tạo."
  - *Kỳ vọng mang về*: Cung cấp công cụ thực hành trực tiếp, rất hữu ích cho đào tạo và áp dụng ngay.
- **P3 (Trưởng phòng CNTT / Chuyển đổi số (IT/DX Lead - Người gác cổng bảo mật & hạ tầng))** — Khớp nỗi đau: `8.8/10` · Nguy cơ bỏ đọc: `1.7/10`:
  - *Chỗ dễ chán/bỏ đọc*: Cần có một phần nhỏ về cách các mẫu biểu này có thể được tích hợp vào các hệ thống quản lý tài liệu hoặc quy trình điện tử hiện có.
  - *Câu phản biện ngay từ dàn ý*: "Việc cung cấp các mẫu biểu và checklist giúp chuẩn hóa đầu vào, từ đó giảm thiểu lỗi và tăng hiệu quả xử lý dữ liệu. Tôi có thể xem xét tự động hóa một số phần của checklist này. Đây là một cách tiếp cận rất thực dụng."
  - *Kỳ vọng mang về*: Cung cấp các công cụ chuẩn hóa đầu vào, giúp giảm lỗi và tiềm năng tự động hóa.

