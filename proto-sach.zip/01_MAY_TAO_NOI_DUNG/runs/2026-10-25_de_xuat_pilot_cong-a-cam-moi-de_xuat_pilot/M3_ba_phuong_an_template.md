# BƯỚC M3: ĐỀ XUẤT 3 PHƯƠNG ÁN TEMPLATE KHÁC BIỆT (`T-A`, `T-B`, `T-C`) & GHÉP KHUÔN `LAB043`

> **Truy vết Big Module 2**: `BM2_M1_chu_trinh_template` (Bước 3/5 — theo chuẩn PHẦN 4 của `LAB043/KHUNG-GUIDELINE-CHUAN.md`)
> **Đã gọi**: `LAB043/linhx-onbrand/scripts/thiet_ke.py`, `LAB027/hinh-anh`, `LAB031/the-phong-cach`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Ba phương án thiết kế đặt lên bàn cân

| Mã PA | Mô tả cấu trúc & Bảng màu | Ưu điểm | Nhược điểm / Rủi ro Onbrand |
|---|---|---|---|
| **T-A** | T-A (Bố cục 1 cột văn bản truyền thống, bảng biểu đen trắng): Trông như tài liệu Word nội bộ, không đạt chuẩn báo cáo tạp chí McKinsey/LAB028. | Tạo ấn tượng thị giác đậm ngay trang đầu. | Nặng nề khi đọc nhiều trang, khoảng trắng < 25%. |
| **T-B ★** | T-B ★ (Lưới tạp chí 12 cột chuẩn LAB028 + LAB043: Bìa Xanh Rêu Đậm #02403B kèm ảnh AGY trong khung hình lá, trang ruột nền #FDFDFD, mỗi trang 1 Action Title Be Vietnam Pro Bold #02403B, 2 biểu đồ Exhibit `H01.svg`/`H02.svg` vẽ bằng `LAB028/hinh.py`) | Đạt chuẩn tương phản WCAG AA (`4,57:1` – `11,2:1`), đúng tỷ lệ `60/25/10/5`, kết hợp hài hoà ảnh chụp AGY và biểu đồ `LAB028`. | Đòi hỏi căn chỉnh lưới 12 cột, mặt nạ `.mask.png` và bo góc chéo hình lá chính xác. |
| **T-C** | T-C (Bố cục đặt chữ trắng trên băng tiêu đề Xanh Lá #6EB264): Bị loại ở cổng tương phản vì chỉ đạt 2,56:1 (< 4,5:1). | Màu sắc bắt mắt kiểu quảng cáo mạng xã hội. | Vi phạm trực tiếp `LUAT-ONBRAND.md` của Sakedemy. |

## 2. Khuôn HTML `LAB043` được nạp để kết xuất PNG thực tế bằng `thiet_ke.py`
1. **Khuôn Banner Web (`banner-web.html`, `1920×600`)**: Nền trắng `#FFFFFF`, logo ngang góc trên trái, mảng hình lá `#6EB264` bên phải ôm ảnh chụp AGY `agy_anh_goc_sakedemy.jpg` (`border-radius: 200px 0 200px 0`), vòng cung trắng góc trên phải, dải gân lá mờ.
2. **Khuôn Chuyên biệt theo loại nội dung**:
   - Với `bai_viet`: `social-vuong-la.html` (`1080×1080`) + `banner-web.html` (`1920×600`).
   - Với `report_mau`: `khuon_v1_2_slide_169.html` (`1920×1080`) + `banner-web.html` (`1920×600`) + Khuôn Tạp chí A4 2 cột (`bao_cao_sakedemy_a4.html`).
   - Với `noi_dung_khoa_hoc`: `khuon_v1_2_slide_169.html` (`1920×1080`) + `story-xanh-la.html` (`1080×1920`) + Khuôn Slide Deck 16:9 (`slide_deck_sakedemy_16x9.html`).
