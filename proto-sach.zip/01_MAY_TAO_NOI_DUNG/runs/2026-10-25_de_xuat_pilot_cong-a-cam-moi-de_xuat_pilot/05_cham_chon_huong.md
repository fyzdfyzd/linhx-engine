# BƯỚC 05: TỰ CHẤM & CHỐT HƯỚNG OUTLINE (`de_xuat_pilot`)

> **Truy vết Module**: `BM1_05_cham_chon_huong` (**Làm mới hoàn toàn** theo Đề 01 Bản 3)
> **Cờ duyệt (`duyet_outline`)**: `may` → **Trạng thái**: `DA_CHOT_TU_DONG_MAY`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu (Gemini 2.5 Flash)

## 1. Bảng chấm điểm 3 phương án Outline (Thang 100)

| Hạng | Phương án | Persona (40đ) | Khớp `dat_khi` (30đ) | Bằng chứng (20đ) | Chống Slop (10đ) | **Tổng (/100)** | Kết luận |
|---|---|---:|---:|---:|---:|---:|---|
| 1 | **B** — Hướng B — Đi từ Tình huống Thực tế tại Doanh nghiệp, Đối chiếu Trước/Sau & Bảng kiểm Áp dụng Ngay | 38.0 | 29.0 | 19.0 | 9.5 | **95.5** | ★ **CHỐT**: Phương án B có cách tiếp cận thực tế, đi từ vấn đề cụ thể tại doanh nghiệp, rất thuyết phục cho cả 3 chân dung người đọc. Đã bao gồm đầy đủ các tiêu chí bắt buộc của thể loại, đặc biệt là chẩn đoán điểm nghẽn và lộ trình 3 giai đoạn. Mật độ bằng chứng và bảng biểu đối chiếu tốt, tránh được văn mẫu. |
| 2 | **A** — Hướng A — Đi từ Số liệu Vĩ mô & Cảnh báo Hệ thống | 30.5 | 24.0 | 16.5 | 8.0 | **79.0** | Loại: Phương án A có cách tiếp cận vĩ mô, phù hợp với người đọc cấp cao nhưng có thể thiếu tính thực tiễn cho người quản lý cấp trung. Đề cập đến AI là điểm cộng nhưng chưa thực sự gắn kết chặt chẽ với giải pháp. Đã có bảng đối chiếu nhưng thiếu chẩn đoán điểm nghẽn rõ ràng. |
| 3 | **C** — Hướng C — Đi thẳng vào Cẩm nang Thao tác Nhanh & Mẫu biểu Thực hành | 27.0 | 19.0 | 13.0 | 7.0 | **66.0** | Loại: Phương án C quá tập trung vào 'cẩm nang' và 'thao tác nhanh', có thể hấp dẫn người thực thi nhưng thiếu tính chiến lược và phân tích sâu. Thiếu chẩn đoán điểm nghẽn và bảng đối chiếu trước/sau, không đáp ứng đủ tiêu chí bắt buộc của thể loại đề xuất thí điểm. Dễ rơi vào văn mẫu 'làm theo hướng dẫn'. |

## 2. Quyết định chốt hướng: ★ Phương án B (95.5/100 điểm)
- **Tên phương án**: Hướng B — Đi từ Tình huống Thực tế tại Doanh nghiệp, Đối chiếu Trước/Sau & Bảng kiểm Áp dụng Ngay
- **Góc nhìn**: Hãy hình dung cảnh tượng quen thuộc tại văn phòng Việt Nam: 6 giờ làm việc mỗi tuần bị hao phí vào việc rà soát, chỉnh sửa những báo cáo thiếu chuẩn hóa, một con số mà khảo sát thực địa của Sakedemy [N04] đã chỉ ra là chi phí ẩn đáng kể. Đề xuất thí điểm 90 ngày này sẽ trực tiếp giải quyết vấn đề đó, chuẩn hóa quy trình kiểm soát chất lượng báo cáo và thu hồi lại chính xác 6 giờ làm việc đó cho doanh nghiệp vào năm 2026.
- **Giọng điệu**:  Chuẩn giọng Đề xuất triển khai thí điểm 90 ngày
- **Khung triển khai gửi sang Bước 6**:
  - 1. Tóm tắt điều hành: 6 giờ làm việc bị lãng phí – Chi phí ẩn không thể chấp nhận
  - 2. Chẩn đoán điểm nghẽn thời gian thực tế: Tình huống thực tế tại phòng ban và chi phí ẩn của báo cáo kém chất lượng (Dẫn chứng Sakedemy [N04])
  - 3. Phân tích nguyên nhân gốc rễ: Quy tắc 10-20-70 của BCG và vai trò của con người & quy trình trong kiểm soát chất lượng [N03]
  - 4. Bảng đối chiếu chỉ số đầu ra Trước và Sau 90 ngày thí điểm: Minh chứng định lượng cho mục tiêu thu hồi 6 giờ làm việc
  - 5. Lộ trình 3 giai đoạn (Tuần 1-4, Tuần 5-8, Tuần 9-12) và tiêu chí nghiệm thu: Chuẩn hóa quy trình kiểm soát chất lượng báo cáo

## 3. Ràng buộc bắt buộc giao cho Bước 6 (Rút từ phản ứng Persona & Luật chống Slop)
- [x] Phải giải quyết câu phản biện của P1 (CEO / Thành viên HĐQT duyệt ngân sách đào tạo & chuyển đổi AI): Cách tiếp cận này rất thực tế và dễ hình dung. Việc có bảng đối chiếu trước/sau và lộ trình rõ ràng giúp tôi tin tưởng vào khả năng đạt được mục tiêu. Tôi thích sự tập trung vào giải quyết vấn đề cụ thể.
- [x] Phải giải quyết câu phản biện của P2 (Giám đốc Nhân sự (HRD) / Trưởng bộ phận Đào tạo (L&D)): Đây là hướng đi tôi mong muốn! Việc chẩn đoán điểm nghẽn thực tế và phân tích nguyên nhân gốc rễ giúp tôi hiểu rõ hơn về nhu cầu đào tạo. Lộ trình 3 giai đoạn và tiêu chí nghiệm thu rất hữu ích cho việc lập kế hoạch triển khai.
- [x] Phải giải quyết câu phản biện của P3 (Trưởng phòng CNTT / Chuyển đổi số (IT/DX Lead - Người gác cổng bảo mật & hạ tầng)): Sơ đồ quy trình 3 bước và bảng đối chiếu trước/sau rất trực quan. Tôi có thể hình dung được cách tích hợp các công cụ hỗ trợ vào quy trình này. Việc tập trung vào quy trình giúp giảm thiểu rủi ro công nghệ.
- [x] Tuyệt đối không dùng cấu trúc so sánh hai vế 'Không còn là X mà là Y' hoặc 'Càng X càng Y' (Luật Vân Anh VA-01, VA-02).
- [x] Mọi số liệu trích dẫn phải giữ nguyên mã nguồn [Nxx]/[BCxx], mọi tình huống giả định phải ghi rõ là tình huống mô phỏng.
