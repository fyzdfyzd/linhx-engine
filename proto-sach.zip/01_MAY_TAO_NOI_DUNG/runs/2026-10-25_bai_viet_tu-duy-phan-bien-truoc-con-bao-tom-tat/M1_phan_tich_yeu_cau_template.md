# BƯỚC M1: PHÂN TÍCH YÊU CẦU MEDIA HOÁ, THAM CHIẾU AGY & NẠP NHẬN DIỆN TẠM (`bai_viet`)

> **Truy vết Big Module 2**: `BM2_M1_chu_trinh_template` (Bước 1/5) + `BM2_M2_media_hoa`
> **Đã gọi**: `AGY image-generator + AGY search_web + LAB043 (thiet_ke.py, onbrand.py, brands/sakedemy) + LAB028 (hinh.py) + LAB031 (linhx-kho-minh-hoa) + LAB049 (build_docx) + LAB066 (khung nhân vật)`
> **Nhận diện tạm**: Sakedemy (`vendor/LAB043/brands/sakedemy/brand.json`, `LUAT-ONBRAND.md`)
> **Trạng thái mẫu**: chạy không mẫu

## 1. Yêu cầu đầu ra Media hoá của loại `bai_viet`
- **Đề tài**: Bài viết chuyên sâu: Thói quen đọc bản tóm tắt ba gạch đầu dòng — Khi cấp điều hành ra quyết định sai vì đánh mất các chi tiết gai góc ở hiện trường
- **Hạng mục sản xuất**: Ảnh chụp thực tế AGY (`image-generator`) + Banner Web 1920×600 & Card Social 1080×1080 (`thiet_ke.py`) + 2 Biểu đồ dữ liệu SVG (`LAB028/hinh.py`) + Trang Đọc HTML/PDF & Bản Giao `.docx`
- **Đối tượng sử dụng**: Đồng bộ trực tiếp với 3 Persona Neo (`P1`, `P2`, `P3`) đã khóa ở Bước 02 và bản thảo cuối ở Bước 09.

## 2. Tham chiếu Thị giác & Media thu thập qua AGY (`search_web`)
- **[V1] Sakedemy Brand Guideline v2 (LAB043) — Khuôn Banner Web 1920x600 & Social Vuông Lá 1080x1080**: Nền Trắng #FFFFFF (60%), mảng Xanh Lá #6EB264 (25%) bo góc hình lá (border-radius 240px 0 240px 0) ôm ảnh chụp lớp học/văn phòng Việt Nam thật, chữ tiêu đề Xanh Rêu Đậm #02403B (10%), dải nhấn gradient Lá Non #A3D34F -> Ngọc #26CABE (5%). Cấm đặt chữ trắng trên nền #6EB264.
- **[V2] LAB028 Exhibit Standard (D16) — Biểu đồ Thanh ngang So sánh Thời gian Thực chất**: Action Title là câu kết luận hoàn chỉnh 6–30 tiếng có động từ; nhãn số trực tiếp trên thanh (so_vn); không khung viền; lưới mảnh; một màu nhấn #02403B hoặc #6EB264.

## 3. Thông số Nhận diện tạm Sakedemy đã nạp (`LAB043`)
- **Tên thương hiệu trong văn bản**: `Sakedemy` (tiêu đề trang trọng: `Sakédemy`, tuyệt đối không viết tắt `Sake`).
- **Tagline chuẩn**: *"Khi sáng tạo gặp công nghệ"*
- **Bảng màu bắt buộc**:
  - Màu chính: Xanh Lá Sakédemy (`#6EB264`), Xanh Rêu Đậm (`#02403B`), Xám Chữ (`#414141`).
  - Màu phụ & nền: Trắng (`#FFFFFF`), Trắng Giấy (`#FDFDFD`), Lá Nhạt (`#E9F6D3`), Xanh Lá Sâu (`#118056` cho chữ xanh nhỏ trên nền trắng).
  - Điểm nhấn: Gradient Lá Non sang Ngọc (`linear-gradient(210deg, #A3D34F, #26CABE)` — tối đa 5% diện tích).
- **Kiểu chữ**: `Be Vietnam Pro` (`Light`, `Regular`, `Bold`), tỷ lệ cỡ chữ `3.2 : 1.6 : 1 : 0.8`.
- **Ngôn ngữ hình khối**: Khung hình lá (vuông/chữ nhật bo hai góc chéo trên-trái và dưới-phải), hoạ tiết gân lá 45° dưới 20% độ đậm ở góc.
