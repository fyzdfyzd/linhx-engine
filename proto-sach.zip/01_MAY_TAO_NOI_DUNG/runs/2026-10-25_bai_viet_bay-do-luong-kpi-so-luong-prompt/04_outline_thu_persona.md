# BƯỚC 04: 30 INSIGHTS, 3 HƯỚNG OUTLINE (A/B/C) & THỬ TRÊN PERSONA (`bai_viet`)

> **Truy vết Module**: `BM1_04_outline_thu_persona` (Kế thừa `LAB025/content-synthesizer` + **Làm mới** phần thử phản ứng trên 3 Persona Neo)
> **Đã gọi**: `LAB025/content-synthesizer` (30 insights -> 3 variants) + `BM1_04/thu_outline_persona.py`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Nén 30 Insights từ Tư liệu Nghiên cứu (`LAB025` Bước 5)
- Tổng số insights đã rút: **30 insights** (chia đều 4 nhóm: `fact`, `paradox`, `metaphor`, `provocation`).
- 10 Insights hạt nhân tiêu biểu:
  - `01` (fact): [Insight #01 · fact] Doanh nghiệp mua tài khoản AI hàng loạt nhưng thời gian họp và sửa bài của cấp quản lý lại tăng thêm 35% [N01]. (Góc khai thác tầng 1)
  - `02` (paradox): [Insight #02 · paradox] Nghịch lý năng suất giả: Nhân viên xuất ra 5 trang nháp trong 30 giây, nhưng trưởng phòng mất 2 tiếng dọn rác logic [N02]. (Góc khai thác tầng 1)
  - `03` (metaphor): [Insight #03 · metaphor] Bẫy 'văn dịch Tây': AI viết tiếng Việt theo cấu trúc mệnh đề quan hệ tiếng Anh khiến người đọc mỏi mắt sau 200 chữ [N03]. (Góc khai thác tầng 1)
  - `04` (provocation): [Insight #04 · provocation] Chị Vân Anh (biên tập viên) chỉ ra: Bản máy tự viết từ đầu chỉ lấy được ý, không dùng được một cách diễn đạt nào [N04]. (Góc khai thác tầng 1)
  - `05` (fact): [Insight #05 · fact] Khi mọi công ty dùng chung một mô hình ngôn ngữ mà không có hồ sơ giọng và kho chuyện thật, mọi thương hiệu đều nói giọng giống hệt nhau [N05]. (Góc khai thác tầng 1)
  - `06` (paradox): [Insight #06 · paradox] Sự thật về 'Prompt Engineering': Câu lệnh dài 2 trang không cứu được một đề bài rỗng ý tưởng hạt giống [N06]. (Góc khai thác tầng 1)
  - `07` (metaphor): [Insight #07 · metaphor] Nhân sự cấp dưới dùng AI như tấm khiên né tránh trách nhiệm cá nhân: 'Máy nó gợi ý thế' [N07]. (Góc khai thác tầng 1)
  - `08` (provocation): [Insight #08 · provocation] Cấp quản lý giao việc kiểu 'hỏi ChatGPT đi' chính là nguồn gốc sinh ra làn sóng báo cáo vô hồn trong nội bộ [N08]. (Góc khai thác tầng 1)
  - `09` (fact): [Insight #09 · fact] Một quy trình tốt tách bạch hoàn toàn ngữ cảnh người viết và ngữ cảnh người biên tập sáu lượt [N09]. (Góc khai thác tầng 1)
  - `10` (paradox): [Insight #10 · paradox] Độc giả báo kinh tế bỏ đọc ngay khi gặp cấu trúc so sánh hai vế máy móc 'Không còn là X mà là Y' [N10]. (Góc khai thác tầng 1)

## 2. Ba phương án Outline A / B / C (`LAB025` Bước 6)

### Phương án A — Hàn lâm / Giải phẫu công nghệ
- **Góc nhìn (`variant_angle`)**: Phân tích từ cơ chế xác suất của LLM đến hiện tượng đồng phục hóa văn bản trong doanh nghiệp
- **Giọng điệu (`variant_tone`)**: Lạnh, học thuật, nhiều thuật ngữ mô hình ngôn ngữ
- **Cấu trúc (`variant_structure`)**: Tuyến tính: Nguyên lý kỹ thuật -> Hệ quả bề mặt -> Khuyến nghị công cụ
- **Tập Insights chọn (10 ý)**: `[1, 3, 5, 6, 9, 11, 13, 15, 19, 21]`
- **Dàn ý chi tiết**:
  - 1. Mở bài: Cơ chế dự đoán từ tiếp theo (next-token prediction) và sự ra đời của văn bản trung bình cộng
  - 2. Thân bài 1: Vì sao cấu trúc câu tiếng Anh xâm lấn tiếng Việt qua lớp dịch ngầm của mô hình
  - 3. Thân bài 2: Phân tích định lượng độ lệch nhịp câu giữa văn máy và văn người
  - 4. Kết bài: Khung kỹ thuật cấu hình hệ thống kiểm soát chất lượng văn bản
- **Giai thoại / Tình huống gắn kèm**:
  - [GIẢ LẬP] Một nhóm kỹ sư thử nghiệm đo độ tương đồng cosine trên 500 bài viết marketing tự động.
  - Trích số liệu kiểm chứng từ LAB049 trên bộ bài đối chuẩn 7 bài báo đã đăng của tác giả.

### Phương án B — Giải phẫu nghịch lý vận hành & Chi phí sửa rác AI (Thực chiến doanh nghiệp)
- **Góc nhìn (`variant_angle`)**: Đi thẳng vào nỗi đau thật giữa Sếp - Trưởng phòng - Nhân viên: Tưởng dùng AI để nhàn đi, nhưng thực tế cả công ty đang làm thêm giờ để dọn rác AI cho nhau
- **Giọng điệu (`variant_tone`)**: Sắc lạnh, tỉnh táo, đi từ chuyện đời thực trong văn phòng Việt Nam đến quy tắc cầm cân nảy mực (đúng giọng Linh + kỷ luật biên tập Vân Anh)
- **Cấu trúc (`variant_structure`)**: Nghịch lý mở đầu -> Giải phẫu 3 tầng thất bại (Giao việc ẩu - Viết tự động - Duyệt cảm tính) -> Kiến trúc tách ngữ cảnh & giữ chốt con người
- **Tập Insights chọn (11 ý)**: `[1, 2, 4, 7, 8, 9, 10, 12, 14, 18, 22]`
- **Dàn ý chi tiết**:
  - 1. Mở bài: Căn phòng họp lúc 8 giờ tối và bản kế hoạch 15 trang sinh ra trong 30 giây nhưng mất 3 ngày để đoán xem nhân viên định nói gì
  - 2. Tầng 1 - Ảo giác tốc độ: Khi khẩu hiệu 'hỏi ChatGPT đi' biến người làm chuyên môn thành thợ sửa lỗi văn dịch
  - 3. Tầng 2 - Vì sao bài máy tự viết từ đầu không cứu được: Bài học từ bàn biên tập (chỉ lấy được ý, hỏng toàn bộ diễn đạt vì thiếu nháp gốc của người làm)
  - 4. Tầng 3 - Giữ chốt ở đâu: Máy tìm tư liệu và soi lỗi theo luật cứng; người giữ hạt giống, trải nghiệm thật và quyền gạch bỏ cuối cùng
- **Giai thoại / Tình huống gắn kèm**:
  - Chuyện thật từ kho LAB025/LAB049: Bản nháp PA1 chạy tự động bị biên tập viên Vân Anh nhận xét thẳng 'chỉ dùng được ý, không dùng được một sự diễn đạt nào'.
  - [GIẢ LẬP] Một trưởng phòng vận hành nhận 3 bản đề xuất từ 3 nhân viên khác nhau nhưng cả 3 bản mở đầu bằng cùng một câu ẩn dụ giống hệt nhau.

### Phương án C — Cẩm nang 10 bước hướng dẫn kỹ năng cá nhân
- **Góc nhìn (`variant_angle`)**: Hướng dẫn chi tiết từng bước cho nhân viên văn phòng cách viết bài không bị phát hiện là AI
- **Giọng điệu (`variant_tone`)**: Hướng dẫn thực hành (How-to), chia nhỏ nhiều gạch đầu dòng
- **Cấu trúc (`variant_structure`)**: Danh sách kiểm tra (Checklist) từ bước 1 đến bước 10
- **Tập Insights chọn (10 ý)**: `[2, 3, 6, 10, 16, 17, 20, 23, 25, 28]`
- **Dàn ý chi tiết**:
  - 1. Mở bài: 5 dấu hiệu khiến bài viết của bạn bị nhận ra là dùng ChatGPT
  - 2. Bước 1 đến Bước 5: Cách chuẩn bị dữ liệu và viết câu lệnh chi tiết
  - 3. Bước 6 đến Bước 9: Cách tự đọc lại và xóa các từ nối quen thuộc của AI
  - 4. Kết bài: Bảng tổng kết dành cho người viết nội dung hàng ngày
- **Giai thoại / Tình huống gắn kèm**:
  - [GIẢ LẬP] Một nhân viên content marketing sửa lại bài đăng fanpage trong 15 phút nhờ danh sách từ cấm.

## 3. [LÀM MỚI] Kết quả thử 3 Outline trên 3 Persona Neo (`P1`, `P2`, `P3`)

| Phương án | TB Khớp nỗi đau (/10) | TB Nguy cơ bỏ đọc (/10, thấp=tốt) | Điểm Persona Tổng hợp (/10) | Xếp hạng từ P1, P2, P3 |
|---|---:|---:|---:|---|
| **A** (Phương án A — Hàn lâm / Giải phẫu công nghệ) | **6.23** | 5.83 | **4.19** | P1: #3, P2: #3, P3: #2 |
| **B** (Phương án B — Giải phẫu nghịch lý vận hành & Chi phí sửa rác AI (Thực chiến doanh nghiệp)) | **9.17** | 1.57 | **8.62** | P1: #1, P2: #1, P3: #1 |
| **C** (Phương án C — Cẩm nang 10 bước hướng dẫn kỹ năng cá nhân) | **5.8** | 6.17 | **3.64** | P1: #2, P2: #2, P3: #3 |

### Phản ứng chi tiết với Phương án A — Hàn lâm / Giải phẫu công nghệ
- **P1 (Chủ doanh nghiệp SME / Giám đốc vận hành (Độc giả mục tiêu chính))** — Khớp nỗi đau: `5.5/10` · Nguy cơ bỏ đọc: `6.8/10`:
  - *Chỗ dễ chán/bỏ đọc*: 1. Mở bài: Cơ chế dự đoán từ tiếp theo (next-token prediction) và sự ra đời của văn bản trung bình cộng
  - *Câu phản biện ngay từ dàn ý*: "[P1 cãi phương án A] 'Lý thuyết quy trình nghe thì hay, nhưng nhân sự bên tôi bảo làm thêm bước kiểm tra là họ kêu quá tải ngay.' — Mở đầu bằng nguyên lý vĩ mô/học thuật thế này là tôi lướt qua ngay vì không giải quyết việc đang cháy."
  - *Kỳ vọng mang về*: Biết thêm khái niệm tổng quan nhưng chưa thấy cách áp vào việc ngày mai.
- **P2 (Trưởng phòng chuyên môn / Team Lead (Người trực tiếp chịu trận giữa sếp và nhân viên))** — Khớp nỗi đau: `5.8/10` · Nguy cơ bỏ đọc: `6.5/10`:
  - *Chỗ dễ chán/bỏ đọc*: 1. Mở bài: Cơ chế dự đoán từ tiếp theo (next-token prediction) và sự ra đời của văn bản trung bình cộng
  - *Câu phản biện ngay từ dàn ý*: "[P2 cãi phương án A] 'Sếp chỉ nhìn sản phẩm cuối chứ có ngồi sửa từng câu văn dịch của AI lúc 8 giờ tối như tụi tôi đâu.' — Mở đầu bằng nguyên lý vĩ mô/học thuật thế này là tôi lướt qua ngay vì không giải quyết việc đang cháy."
  - *Kỳ vọng mang về*: Biết thêm khái niệm tổng quan nhưng chưa thấy cách áp vào việc ngày mai.
- **P3 (Chuyên gia / Quản lý kỹ thuật hoài nghi (Độc giả khó tính hay bắt bẻ số liệu))** — Khớp nỗi đau: `7.4/10` · Nguy cơ bỏ đọc: `4.2/10`:
  - *Chỗ dễ chán/bỏ đọc*: 1. Mở bài: Cơ chế dự đoán từ tiếp theo (next-token prediction) và sự ra đời của văn bản trung bình cộng
  - *Câu phản biện ngay từ dàn ý*: "[P3 cãi phương án A] 'Số liệu này lấy ở khảo sát nào, mẫu bao nhiêu, hay tác giả tự suy diễn từ vài quán cà phê?' — Mở đầu bằng nguyên lý vĩ mô/học thuật thế này là tôi lướt qua ngay vì không giải quyết việc đang cháy."
  - *Kỳ vọng mang về*: Biết thêm khái niệm tổng quan nhưng chưa thấy cách áp vào việc ngày mai.

### Phản ứng chi tiết với Phương án B — Giải phẫu nghịch lý vận hành & Chi phí sửa rác AI (Thực chiến doanh nghiệp)
- **P1 (Chủ doanh nghiệp SME / Giám đốc vận hành (Độc giả mục tiêu chính))** — Khớp nỗi đau: `9.2/10` · Nguy cơ bỏ đọc: `1.5/10`:
  - *Chỗ dễ chán/bỏ đọc*: Không có mục sáo rỗng; cần lưu ý giữ nhịp gọn ở phần chuyển từ chẩn đoán sang giải pháp.
  - *Câu phản biện ngay từ dàn ý*: "[P1 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung."
  - *Kỳ vọng mang về*: Một nguyên tắc phân rã công việc rõ ràng để biết khâu nào giao cho máy, khâu nào bắt buộc người phải giữ chốt.
- **P2 (Trưởng phòng chuyên môn / Team Lead (Người trực tiếp chịu trận giữa sếp và nhân viên))** — Khớp nỗi đau: `9.4/10` · Nguy cơ bỏ đọc: `1.4/10`:
  - *Chỗ dễ chán/bỏ đọc*: Không có mục sáo rỗng; cần lưu ý giữ nhịp gọn ở phần chuyển từ chẩn đoán sang giải pháp.
  - *Câu phản biện ngay từ dàn ý*: "[P2 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung."
  - *Kỳ vọng mang về*: Gọi đúng tên nỗi khổ 'sửa rác AI mệt hơn tự làm' để có luận điểm trao đổi thẳng thắn với sếp.
- **P3 (Chuyên gia / Quản lý kỹ thuật hoài nghi (Độc giả khó tính hay bắt bẻ số liệu))** — Khớp nỗi đau: `8.9/10` · Nguy cơ bỏ đọc: `1.8/10`:
  - *Chỗ dễ chán/bỏ đọc*: Không có mục sáo rỗng; cần lưu ý giữ nhịp gọn ở phần chuyển từ chẩn đoán sang giải pháp.
  - *Câu phản biện ngay từ dàn ý*: "[P3 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung."
  - *Kỳ vọng mang về*: Một góc nhìn sắc lạnh, có bằng chứng xác thực và chỉ ra đúng giới hạn cấu trúc của mô hình ngôn ngữ.

### Phản ứng chi tiết với Phương án C — Cẩm nang 10 bước hướng dẫn kỹ năng cá nhân
- **P1 (Chủ doanh nghiệp SME / Giám đốc vận hành (Độc giả mục tiêu chính))** — Khớp nỗi đau: `5.8/10` · Nguy cơ bỏ đọc: `6.2/10`:
  - *Chỗ dễ chán/bỏ đọc*: 2. Bước 1 đến Bước 5: Cách chuẩn bị dữ liệu và viết câu lệnh chi tiết
  - *Câu phản biện ngay từ dàn ý*: "[P1 cãi phương án C] Liệt kê mẹo/danh mục kiểu này trên mạng có hàng trăm bài, đọc xong vẫn không giải quyết được xung đột quy trình trong công ty."
  - *Kỳ vọng mang về*: Có vài gạch đầu dòng tham khảo nhanh nhưng thiếu chiều sâu hệ thống.
- **P2 (Trưởng phòng chuyên môn / Team Lead (Người trực tiếp chịu trận giữa sếp và nhân viên))** — Khớp nỗi đau: `6.7/10` · Nguy cơ bỏ đọc: `4.8/10`:
  - *Chỗ dễ chán/bỏ đọc*: 2. Bước 1 đến Bước 5: Cách chuẩn bị dữ liệu và viết câu lệnh chi tiết
  - *Câu phản biện ngay từ dàn ý*: "[P2 cãi phương án C] Liệt kê mẹo/danh mục kiểu này trên mạng có hàng trăm bài, đọc xong vẫn không giải quyết được xung đột quy trình trong công ty."
  - *Kỳ vọng mang về*: Có vài gạch đầu dòng tham khảo nhanh nhưng thiếu chiều sâu hệ thống.
- **P3 (Chuyên gia / Quản lý kỹ thuật hoài nghi (Độc giả khó tính hay bắt bẻ số liệu))** — Khớp nỗi đau: `4.9/10` · Nguy cơ bỏ đọc: `7.5/10`:
  - *Chỗ dễ chán/bỏ đọc*: 2. Bước 1 đến Bước 5: Cách chuẩn bị dữ liệu và viết câu lệnh chi tiết
  - *Câu phản biện ngay từ dàn ý*: "[P3 cãi phương án C] Liệt kê mẹo/danh mục kiểu này trên mạng có hàng trăm bài, đọc xong vẫn không giải quyết được xung đột quy trình trong công ty."
  - *Kỳ vọng mang về*: Có vài gạch đầu dòng tham khảo nhanh nhưng thiếu chiều sâu hệ thống.

