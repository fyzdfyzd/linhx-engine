# BƯỚC 05: TỰ CHẤM & CHỐT HƯỚNG OUTLINE (`ban_tin_lanh_dao`)

> **Truy vết Module**: `BM1_05_cham_chon_huong` (**Làm mới hoàn toàn** theo Đề 01 Bản 3)
> **Cờ duyệt (`duyet_outline`)**: `may` → **Trạng thái**: `DA_CHOT_TU_DONG_MAY`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu (Gemini 2.5 Flash)

## 1. Bảng chấm điểm 3 phương án Outline (Thang 100)

| Hạng | Phương án | Persona (40đ) | Khớp `dat_khi` (30đ) | Bằng chứng (20đ) | Chống Slop (10đ) | **Tổng (/100)** | Kết luận |
|---|---|---:|---:|---:|---:|---:|---|
| 1 | **B** — Hướng B — Đi từ Tình huống Thực tế tại Doanh nghiệp, Đối chiếu Trước/Sau & Bảng kiểm Áp dụng Ngay | 38.0 | 28.5 | 19.0 | 9.5 | **95.0** | ★ **CHỐT**: Hướng B đi thẳng vào tình huống thực tế, tạo sự đồng cảm mạnh mẽ với người đọc là lãnh đạo doanh nghiệp Việt Nam. Việc đối chiếu trước/sau và bảng kiểm áp dụng ngay rất thiết thực. Mật độ bằng chứng và bảng biểu đối chiếu tốt, giúp củng cố lập luận và đưa ra giải pháp cụ thể, tránh sáo rỗng. |
| 2 | **C** — Hướng C — Đi thẳng vào Cẩm nang Thao tác Nhanh & Mẫu biểu Thực hành | 33.0 | 25.0 | 15.0 | 8.0 | **81.0** | Loại: Hướng C tập trung vào cẩm nang thao tác nhanh và mẫu biểu thực hành, rất trực tiếp và hành động. Tuy nhiên, nó có thể thiếu phần phân tích sâu về nguyên nhân gốc rễ và bối cảnh, khiến người đọc có thể cảm thấy giải pháp hơi 'mì ăn liền' mà chưa hiểu rõ vấn đề. Mật độ bằng chứng và đối chiếu chưa cao. |
| 3 | **A** — Hướng A — Đi từ Số liệu Vĩ mô & Cảnh báo Hệ thống | 30.5 | 22.0 | 16.5 | 7.5 | **76.5** | Loại: Hướng A có cách tiếp cận từ số liệu vĩ mô và cảnh báo hệ thống, có thể thu hút sự chú ý ban đầu nhưng chưa đi sâu vào tình huống cụ thể của nhà quản lý Việt Nam. Các bằng chứng có vẻ học thuật hơn là thực tiễn. Quyết định điều hành có thể hơi chung chung. |

## 2. Quyết định chốt hướng: ★ Phương án B (95.0/100 điểm)
- **Tên phương án**: Hướng B — Đi từ Tình huống Thực tế tại Doanh nghiệp, Đối chiếu Trước/Sau & Bảng kiểm Áp dụng Ngay
- **Góc nhìn**: Mỗi sáng thứ Hai, bạn nhận được 5 báo cáo cần chỉnh sửa, tiêu tốn trung bình 1.2 giờ/báo cáo, tương đương 6 giờ làm việc quý giá mỗi tuần chỉ để 'dọn dẹp' sản phẩm AI kém chất lượng và báo cáo thiếu chuẩn [Khảo sát Sakedemy], đây chính là điểm nghẽn cần chuẩn hóa quy trình kiểm soát chất lượng báo cáo tại doanh nghiệp Việt Nam 2026.
- **Giọng điệu**:  Chuẩn giọng Bản tin điều hành hàng tuần cho lãnh đạo
- **Khung triển khai gửi sang Bước 6**:
  - 1. Tình huống thực tế & chi phí ẩn: 6 giờ làm việc bị 'đánh cắp' mỗi tuần vì báo cáo thiếu chuẩn (Khảo sát Sakedemy)
  - 2. Giải phẫu nguyên nhân gốc rễ theo quy tắc 10-20-70: Tại sao 70% vấn đề nằm ở con người và quy trình, không phải AI?
  - 3. Bảng đối chiếu quy trình: Từ 'chỉnh sửa thủ công' đến 'cổng kiểm duyệt chất lượng' – Cách thu hồi 6 giờ làm việc
  - 4. Quy trình 3 bước triển khai thực chiến: Thiết lập chuẩn, đào tạo, và giám sát liên tục
  - 5. Bảng kiểm nghiệm thu & Hành động ngay trong tuần tới: 3 quyết định điều hành cho sáng thứ Hai

## 3. Ràng buộc bắt buộc giao cho Bước 6 (Rút từ phản ứng Persona & Luật chống Slop)
- [x] Phải giải quyết câu phản biện của P1 (Chủ doanh nghiệp SME / Giám đốc vận hành (Độc giả mục tiêu chính)): Đây chính là thứ tôi cần! Tình huống thực tế rất gần gũi, các bước hành động rõ ràng và bảng đối chiếu giúp tôi hình dung được lợi ích. Tôi có thể áp dụng ngay.
- [x] Phải giải quyết câu phản biện của P2 (Trưởng phòng chuyên môn / Team Lead (Người trực tiếp chịu trận giữa sếp và nhân viên)): Tình huống mở đầu như đang nói về đội của tôi! Quy trình 3 bước và bảng kiểm nghiệm thu là công cụ đắc lực để tôi triển khai cho nhân viên. Rất thiết thực.
- [x] Phải giải quyết câu phản biện của P3 (Chuyên gia / Quản lý kỹ thuật hoài nghi (Độc giả khó tính hay bắt bẻ số liệu)): Cách tiếp cận từ vấn đề thực tế và giải pháp từng bước rất thuyết phục. Việc liên kết với quy tắc 10-20-70 giúp tôi thấy được sự cân bằng giữa công nghệ và quy trình. Bảng đối chiếu Trước/Sau có số liệu định lượng là điểm cộng lớn.
- [x] Tuyệt đối không dùng cấu trúc so sánh hai vế 'Không còn là X mà là Y' hoặc 'Càng X càng Y' (Luật Vân Anh VA-01, VA-02).
- [x] Mọi số liệu trích dẫn phải giữ nguyên mã nguồn [Nxx]/[BCxx], mọi tình huống giả định phải ghi rõ là tình huống mô phỏng.
