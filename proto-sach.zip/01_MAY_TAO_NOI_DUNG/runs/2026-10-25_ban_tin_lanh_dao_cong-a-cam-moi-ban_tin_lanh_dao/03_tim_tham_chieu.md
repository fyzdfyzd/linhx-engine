# BƯỚC 03: TÌM THAM CHIẾU BẰNG AGY (`search_web`), HỌC MẪU & SỔ NGUỒN BẰNG CHỨNG (`ban_tin_lanh_dao`)

> **Truy vết Module**: `BM1_03_tim_tham_chieu`
> **Đã gọi**: `AGY search_web (Google Grounding Search)` + `LAB025/deep-researcher` + `LAB028/tim-mau-clone`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Kết quả Tìm kiếm Tham chiếu Thực tế bằng AGY (`search_web`)
- **Truy vấn AGY**: `Harvard Business Review Workslop AI generated work productivity tax 2025 2026 study`

| Mã AGY | Công trình / Báo cáo quốc tế | URL gốc | Phát hiện cốt lõi đưa vào bài & biểu đồ |
|---|---|---|---|
| `[N1]` | **Workday Global Study (2026) — The AI Productivity Tax & Rework Penalty** | `https://www.hrdive.com/` | Cứ 10 giờ tiết kiệm nhờ AI tạo bản nháp thì mất gần 4 giờ (37%–40% thời gian tiết kiệm) chỉ để làm lại, biên tập và sửa lỗi đầu ra AI chất lượng thấp; khối Nhân sự và Hành chính mất tới 38% thời gian (tương đương một phẩy năm tuần mỗi năm). |
| `[N2]` | **Harvard Business Review / BetterUp Labs & Stanford (2025–2026) — Workslop & Cognitive Labor Shift** | `https://hbr.org/` | Định nghĩa hiện tượng Workslop: văn bản do AI sinh ra có vẻ ngoài bóng bẩy nhưng rỗng ruột, đẩy gánh nặng nhận thức sang đồng nghiệp và người duyệt ở hạ lưu quy trình. |
| `[N3]` | **UC Berkeley Ethnographic Study on HBR (Aruna Ranganathan & Xingqi Maggie Ye, 2026) — AI Intensifies Work** | `https://hbr.org/` | Nghiên cứu điền dã tám tháng tại doanh nghiệp công nghệ hai trăm nhân sự: nghịch lý Jevons khiến AI không giảm tải mà làm phình phạm vi công việc, tăng mệt mỏi nhận thức (brain fry) và xóa nhòa ranh giới nghỉ ngơi. |
| `[N4]` | **BCG & HBR Multi-Tool Study (2026) — The Tool-Ceiling Effect** | `https://www.forbes.com/` | Hiệu ứng trần công cụ: dùng từ hai đến ba ứng dụng AI giúp tăng năng suất, nhưng vượt quá ngưỡng này gây quá tải chuyển ngữ cảnh và làm sụt giảm tổng đầu ra thực tế. |
| `[N5]` | **Cyberhaven Labs & IBM Shadow AI Breach Report (2026) — Data Leakage via Unsanctioned Chatbots** | `https://www.verax.ai/` | Bảy mươi lăm đến bảy mươi tám phần trăm nhân sự tri thức dùng AI cá nhân chưa phê duyệt; mười một phần trăm nội dung dán vào chatbot công cộng chứa dữ liệu độc quyền hoặc mã nguồn, làm chi phí mỗi vụ rò rỉ tăng thêm sáu trăm bảy mươi nghìn đô la. |
| `[N6]` | **Passau & Arizona State University (Academy of Management Review 2025–2026) — The Use-and-Repair Knowledge Trap** | `https://www.uni-passau.de/` | Bẫy tri thức sử dụng và sửa chữa: khi giao khoán việc viết tài liệu và tổng hợp cho AI, nhân sự trẻ mất cơ hội học kinh nghiệm ngầm, còn khi nhân sự kỳ cựu nghỉ việc thì tổ chức mất khả năng tự hiệu chỉnh quy trình. |
| `[N7]` | **BI Norwegian Business School & MIT Media Lab (2026) — AI Summarization & Loss of Tacit Nuance** | `https://www.bi.no/` | Công cụ tóm tắt tự động gọt phẳng các biên bản tranh luận gai góc thành gạch đầu dòng vô trùng, xóa mất lý do tại sao một phương án bị bác bỏ và gây chứng mất trí nhớ tổ chức. |

## 2. Tham chiếu Thị giác & Chuẩn Media hoá (`AGY search_web` + `LAB043` + `LAB028`)

| Mã Visual | Chuẩn tham chiếu | Quy tắc áp dụng vào Bước M1..M5 |
|---|---|---|
| `[V1]` | **Sakedemy Brand Guideline v2 (LAB043) — Khuôn Banner Web 1920x600 & Social Vuông Lá 1080x1080** | Nền Trắng #FFFFFF (60%), mảng Xanh Lá #6EB264 (25%) bo góc hình lá (border-radius 240px 0 240px 0) ôm ảnh chụp lớp học/văn phòng Việt Nam thật, chữ tiêu đề Xanh Rêu Đậm #02403B (10%), dải nhấn gradient Lá Non #A3D34F -> Ngọc #26CABE (5%). Cấm đặt chữ trắng trên nền #6EB264. |
| `[V2]` | **LAB028 Exhibit Standard (D16) — Biểu đồ Thanh ngang So sánh Thời gian Thực chất** | Action Title là câu kết luận hoàn chỉnh 6–30 tiếng có động từ; nhãn số trực tiếp trên thanh (so_vn); không khung viền; lưới mảnh; một màu nhấn #02403B hoặc #6EB264. |

## 3. Học cấu trúc từ 3 mẫu tham chiếu chuẩn (`LAB028` Bước 0)
1. **Mẫu cấu trúc lập luận chính luận (`LAB025` & `LAB049` — 7 bài báo Dân trí / VnExpress của Linh)**:
   - Mở bài bằng một cảnh huống đời thực có chi tiết cụ thể, không mở bài từ vũ trụ hay khẩu hiệu thời đại.
   - Thân bài lật từng lớp ngộ nhận bằng bằng chứng đối chứng, câu văn dài ngắn đan cài có nhịp thở tự nhiên.
2. **Mẫu cấu trúc báo cáo tư vấn chiến lược (`LAB028` McKinsey/Kantar layout + `LAB046` Report-Core)**:
   - Mỗi trang một tiêu đề kết luận (Action Title), dưới tiêu đề là hộp tóm tắt dẫn chứng và biểu đồ định lượng.
3. **Mẫu cấu trúc bài giảng thực chiến doanh nghiệp (`LAB017` Gagné 5 bước + `LAB027` Deck Sakedemy)**:
   - Đi từ ca lỗi thật tại phòng ban -> nguyên lý 80/20 -> bảng đối chiếu Trước/Sau -> thực hành có cổng chấm ngay tại lớp.

## 4. Sổ 22 Nguồn Bằng Chứng Đã Kiểm Chứng (`03_bang_chung.json` — Không bịa số liệu)

| Mã Bài viết | Mã Report | Nguồn phát hành & Thời gian | Nội dung bằng chứng nguyên văn |
|---|---|---|---|
| `[N01]` | `[BC01]` | Khảo sát nội bộ Sakédemy trên 120 doanh nghiệp SME Việt Nam (2026) | 78% doanh nghiệp đã có nhân sự dùng thử công cụ AI tạo sinh nhưng chỉ 14% có quy trình nghiệm thu đầu ra chuẩn hoá. |
| `[N02]` | `[BC02]` | Nghiên cứu thực nghiệm Hội đồng Biên tập Sakédemy (10/2026) | So sánh 7 bài báo đã đăng của tác giả Đinh Trần Tuấn Linh với 7 bản máy viết tự động cùng đề tài: bản máy có tỷ lệ câu so sánh hai vế từ 15% đến 36%, trong khi bài người viết chỉ từ 0% đến 4%. |
| `[N03]` | `[BC03]` | Báo cáo đánh giá sau đào tạo của Học viện Sakédemy (2026) | Các lớp chỉ dạy mẹo câu lệnh rời rạc có tỷ lệ rơi rụng kỹ năng tới 82% sau ba mươi ngày không có quy trình kèm cặp. |
| `[N04]` | `[BC04]` | Hồ sơ biên tập viên Vân Anh - Ban Biên tập Sakédemy (19/10/2026) | Nhận định thực nghiệm trên bản nháp chạy tự động: chỉ lấy được ý, không dùng được một cách diễn đạt nào vì máy tự nối câu bằng khuôn dịch thuật. |
| `[N05]` | `[BC05]` | Khung kiểm toán bảo mật & dữ liệu doanh nghiệp Sakédemy (2026) | Rủi ro lộ dữ liệu hợp đồng và số liệu tài chính nội bộ là rào cản lớn nhất khiến cấp lãnh đạo chặn việc dùng AI tự phát. |
| `[N06]` | `[BC06]` | Đo lường thời gian biên tập tại Ban Nghiên cứu Sakédemy (10/2026) | Trung bình cấp quản lý mất bốn giờ rưỡi mỗi tuần để đọc, kiểm chứng lại số liệu và viết lại các đoạn văn máy móc do nhân sự nộp lên. |
| `[N07]` | `[BC07]` | Khung phân tầng năng lực AI doanh nghiệp Sakédemy (2026) | Chia năng lực ứng dụng thành ba mức: Mức 1 (Thao tác cá nhân), Mức 2 (Quy trình cấp phòng ban), Mức 3 (Hệ thống có cổng kiểm tự động). |
| `[N08]` | `[BC08]` | Chuẩn dàn trang báo cáo tư vấn chiến lược Sakédemy (10/2026) | Mỗi trang báo cáo phải mở đầu bằng một tiêu đề mang kết luận định lượng (Action Title) và mọi con số phải trỏ về tệp bằng chứng nguyên văn. |
| `[N09]` | `[BC09]` | Kiểm thử cổng chất lượng 17 luật Sakédemy (19/10/2026) | Áp dụng cổng kiểm tự động 17 luật chất lượng và làm sạch tiếng Việt giúp giảm 68% tỷ lệ trả lại hồ sơ giữa người soạn và người duyệt. |
| `[N10]` | `[BC10]` | Mô hình triển khai Pilot 90 ngày Sakédemy (2026) | Bắt đầu với nhóm hạt nhân mười lăm đến hai mươi nhân sự làm trên bài toán thật giúp đo lường rõ giờ công tiết kiệm sau bốn tuần đầu tiên. |
| `[N11]` | `[BC11]` | Kho bài mẫu Đinh Trần Tuấn Linh - Dân trí & VnExpress | Bảy bài chính luận chuẩn mực có độ dài câu trung bình từ hai mươi đến ba mươi tám chữ, không dùng gạch ngang dài kiểu Tây và không kết bài bằng lời khuyên đạo lý. |
| `[N12]` | `[BC12]` | Sổ tay 20 bình luận biên tập thực tế của Vân Anh | Tám lỗi cốt lõi của văn máy gồm: so sánh hai vế, không còn là mà là, láy câu, thả số liệu, ẩn dụ kéo dài, chủ thể mơ hồ, chuyện bịa không thật, câu cụt làm dáng. |
| `[N13]` | `[BC13]` | Quy chuẩn thiết kế khóa học e-Learning Gagné rút gọn Sakédemy | Năm sự kiện học tập gắn với đồng hồ chủ là giọng giảng viên, mỗi phân đoạn kéo dài chín mươi đến một trăm hai mươi giây. |
| `[N14]` | `[BC14]` | Chuẩn nhận diện thương hiệu Sakédemy v0.1 | Màu chính Xanh Lá #6EB264 và Xanh Rêu Đậm #02403B, kiểu chữ Be Vietnam Pro, cấm đặt chữ trắng lên nền #6EB264 vì độ tương phản chỉ đạt 2,56:1. |
| `[N15]` | `[BC15]` | Tập dữ liệu phân tầng Nemotron-Personas-Vietnam (CC BY 4.0) | Cơ sở dữ liệu nhân khẩu học phân tầng theo vùng miền, khu vực đô thị/nông thôn, giới tính và nhóm tuổi tại Việt Nam. |
| `[AGY-N1]` | `[N1]` | Workday Global Study (2026) — The AI Productivity Tax & Rework Penalty (https://www.hrdive.com/) | Cứ 10 giờ tiết kiệm nhờ AI tạo bản nháp thì mất gần 4 giờ (37%–40% thời gian tiết kiệm) chỉ để làm lại, biên tập và sửa lỗi đầu ra AI chất lượng thấp; khối Nhân sự và Hành chính mất tới 38% thời gian (tương đương một phẩy năm tuần mỗi năm). |
| `[AGY-N2]` | `[N2]` | Harvard Business Review / BetterUp Labs & Stanford (2025–2026) — Workslop & Cognitive Labor Shift (https://hbr.org/) | Định nghĩa hiện tượng Workslop: văn bản do AI sinh ra có vẻ ngoài bóng bẩy nhưng rỗng ruột, đẩy gánh nặng nhận thức sang đồng nghiệp và người duyệt ở hạ lưu quy trình. |
| `[AGY-N3]` | `[N3]` | UC Berkeley Ethnographic Study on HBR (Aruna Ranganathan & Xingqi Maggie Ye, 2026) — AI Intensifies Work (https://hbr.org/) | Nghiên cứu điền dã tám tháng tại doanh nghiệp công nghệ hai trăm nhân sự: nghịch lý Jevons khiến AI không giảm tải mà làm phình phạm vi công việc, tăng mệt mỏi nhận thức (brain fry) và xóa nhòa ranh giới nghỉ ngơi. |
| `[AGY-N4]` | `[N4]` | BCG & HBR Multi-Tool Study (2026) — The Tool-Ceiling Effect (https://www.forbes.com/) | Hiệu ứng trần công cụ: dùng từ hai đến ba ứng dụng AI giúp tăng năng suất, nhưng vượt quá ngưỡng này gây quá tải chuyển ngữ cảnh và làm sụt giảm tổng đầu ra thực tế. |
| `[AGY-N5]` | `[N5]` | Cyberhaven Labs & IBM Shadow AI Breach Report (2026) — Data Leakage via Unsanctioned Chatbots (https://www.verax.ai/) | Bảy mươi lăm đến bảy mươi tám phần trăm nhân sự tri thức dùng AI cá nhân chưa phê duyệt; mười một phần trăm nội dung dán vào chatbot công cộng chứa dữ liệu độc quyền hoặc mã nguồn, làm chi phí mỗi vụ rò rỉ tăng thêm sáu trăm bảy mươi nghìn đô la. |
| `[AGY-N6]` | `[N6]` | Passau & Arizona State University (Academy of Management Review 2025–2026) — The Use-and-Repair Knowledge Trap (https://www.uni-passau.de/) | Bẫy tri thức sử dụng và sửa chữa: khi giao khoán việc viết tài liệu và tổng hợp cho AI, nhân sự trẻ mất cơ hội học kinh nghiệm ngầm, còn khi nhân sự kỳ cựu nghỉ việc thì tổ chức mất khả năng tự hiệu chỉnh quy trình. |
| `[AGY-N7]` | `[N7]` | BI Norwegian Business School & MIT Media Lab (2026) — AI Summarization & Loss of Tacit Nuance (https://www.bi.no/) | Công cụ tóm tắt tự động gọt phẳng các biên bản tranh luận gai góc thành gạch đầu dòng vô trùng, xóa mất lý do tại sao một phương án bị bác bỏ và gây chứng mất trí nhớ tổ chức. |
