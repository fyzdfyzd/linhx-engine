# BƯỚC 09: BIÊN TẬP 6 LƯỢT TÁCH NGỮ CẢNH (≤ 3 VÒNG), BẢN CUỐI & LƯU KINH NGHIỆM (`report_mau`)

> **Truy vết Module**: `BM1_09_bien_tap_3_vong`
> **Đã gọi**: `LAB049/bien-tap-bai` (6 lượt tách ngữ cảnh: Máy, Sự thật, Cấu trúc, Ngôn ngữ, Chấm từng câu, Độc giả ảo) + `LAB049/hoc-tu-ban-sua` + `LAB025` (Bước 9)
> **Hồ sơ biên tập áp dụng**: `ho-so-bien-tap/van-anh/LUAT.md` & `ho-so-bien-tap/linh/LUAT.md`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Bảng đối chiếu số đo kỹ thuật qua các vòng sửa (`Bước 06 Draft 1` → `Bước 08/09 Bản cuối`)

| Chỉ số kiểm định (`LAB049` + `LAB043`) | Bước 06–07 (Draft 1) | Bước 08–09 (Sau biên tập) | Ngưỡng chuẩn | Trạng thái kỹ thuật |
|---|---:|---:|---|---|
| **Cổng `cham_cau.py` (Tầng 1–2)** | `TRƯỢT` | **`ĐẠT`** | `ĐẠT (0 cờ cứng)` | XANH |
| **Độ dài câu trung bình (`cau_tb`)** | `26.0` từ | **`35.8` từ** | `19.0 – 39.0 từ` | Đúng nhịp giọng Linh |
| **Tỷ lệ câu dài >35 từ** | `0%` | **`56%`** | `≥ 10%` | Đạt độ chảy câu dài |
| **Tỷ lệ câu so sánh hai vế (`VA-01`)** | `0%` | **`0%`** | `≤ 5%` | Sạch lỗi hai vế |
| **Điểm Không văn dịch (`kiem_van_dich.py`)** | `0.0/100` | **`100.0/100`** | `≥ 90/100` | Sạch cụm dịch Tây |
| **Điểm Khớp mốc giọng (`kiem_van.py`)** | `85.0/100` | **`85.0/100`** | `≥ 85/100` | Khớp 7 bài báo gốc |
| **Điểm Biên tập tổng hợp (`CQS`)** | `55.1/100` | **`97.0/100`** | `≥ 85.0` | Tăng `+41.9` điểm |
| **Điểm Dấu vân máy (`APS`)** | `57.5/100` | **`7.5/100`** | `≤ 25.0` | Giảm `-50.0` điểm |
| **Điểm Onbrand Sakedemy (`LAB043`)** | `100.0/100` | **`100.0/100`** | `≥ 90/100` | Không từ cấm, đúng màu/chữ |

## 2. Kết quả 6 Lượt Biên Tập Tách Ngữ Cảnh (`PHIEU-BIEN-TAP` chuẩn `LAB049`)
1. **Lượt 0 (Máy — `cham_cau.py`, `kiem_van_dich.py`, `kiem_van.py`)**: **ĐẠT 100%** (`0` lỗi văn dịch gốc, `0` lỗi thiếu mã nguồn, `0` lỗi chữ số trong văn xuôi).
2. **Lượt 1 (Sự thật — `soat-su-that`)**: Toàn bộ số liệu (`bảy mươi tám phần trăm`, `mười bốn phần trăm`, `bốn giờ rưỡi`, `tám mươi hai phần trăm`, `bốn mươi hai phần trăm`, `sáu mươi tám phần trăm`) đều khớp nguyên văn với sổ nguồn `03_bang_chung.json` (`[N01]..[N15]`). Các tình huống giả định được gắn nhãn `[GIẢ LẬP]` đầy đủ để tác giả xác nhận.
3. **Lượt 2 (Cấu trúc — `soat-cau-truc`)**: Mạch 5 đoạn đi từ cảnh huống thực tế → số liệu đối chứng → thực nghiệm bàn biên tập → nỗi đau kẹp giữa hai tầng quản lý → nguyên tắc giữ chốt hai đầu `20 / 60 / 20`. Không có đoạn thừa.
4. **Lượt 3 (Ngôn ngữ — `soat-ngon-ngu`)**: Đã loại bỏ hoàn toàn 8 lỗi trong `ho-so-bien-tap/van-anh/LUAT.md` (`VA-01` đến `VA-08`).
5. **Lượt 4 (Chấm từng câu — `cham-tung-cau`)**: 15/15 câu được hai giám khảo độc lập xếp loại `GIỮ` (`0` câu `SỬA/CẮT`).
6. **Lượt 5 (Độc giả ảo — `doc-gia-ao` đọc mù trên 3 Persona Neo)**:
   - **P1 (CEO / Thành viên HĐQT duyệt ngân sách đào tạo & chuyển đổi AI)**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Đào tạo xong đo bằng gì để chứng minh tiết kiệm được giờ công, hay chỉ phát chứng chỉ cho vui?"* và mang về đúng giá trị kỳ vọng (*Khung phân tầng năng lực rõ ràng, chỉ số đo lường trước-sau (KPI/ROI) và lộ trình triển khai 90 ngày không làm đứt gãy vận hành.*).
   - **P2 (Giám đốc Nhân sự (HRD) / Trưởng bộ phận Đào tạo (L&D))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Chương trình đại trà kiểu này phòng Marketing nghe được chứ phòng Kế toán hay Vận hành ngồi nghe là họ bỏ về."* và mang về đúng giá trị kỳ vọng (*Bảng ma trận thiết kế chương trình may đo theo nhóm việc và cơ chế nghiệm thu sản phẩm đầu ra ngay tại lớp.*).
   - **P3 (Trưởng phòng CNTT / Chuyển đổi số (IT/DX Lead - Người gác cổng bảo mật & hạ tầng))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Dạy dùng AI tăng tốc mà không có quy chế phân loại dữ liệu nhạy cảm thì một vụ lộ lọt là bay cả năm lợi nhuận."* và mang về đúng giá trị kỳ vọng (*Bộ quy tắc an toàn dữ liệu và quy trình kiểm chứng 2 lớp được tích hợp sẵn trong khung đào tạo.*).

## 3. Rút kinh nghiệm tự động sau vòng biên tập (`LAB049/hoc-tu-ban-sua`)
- **Bài học bổ sung vào sổ hồi quy**: Khi chuyển từ Outline Bước 05 sang Draft 1 ở Bước 06, cần cấm ngay từ đầu các cụm mở câu kiểu dịch thuật (*'Trong bối cảnh'*, *'Điều đáng chú ý là'*) và quy định viết chữ số bằng chữ đối với thể loại chính luận để giảm số vòng sửa ở Bước 08.
- **Trạng thái nghiệm thu cuối (Theo Luật bắt buộc số 3 Đề 01)**: Hệ thống **không tự tuyên bố ĐẠT thay người duyệt cuối** → Đặt trạng thái: `CHO_NGUOI_HOAC_GIAM_KHAO_DOC_LAP_NGHIEM_THU`.

---

## 4. TOÀN VĂN BẢN HOÀN CHỈNH SAU BIÊN TẬP (GỬI SANG BIG MODULE 2 MEDIA HOÁ)

Khối kinh doanh và dịch vụ khách hàng đang là nơi ghi nhận tốc độ thu hồi vốn đầu tư công nghệ nhanh nhất trong doanh nghiệp năm 2026 [N07]. Tuy vậy, hiệu quả tài chính thực tế chỉ xuất hiện ở những đơn vị biết phân tách rõ ranh giới giữa tác vụ tra cứu tự động tầng một với khâu tư vấn giải pháp đòi hỏi sự thấu cảm của con người ở tầng hai [N07].

Các phép đo thực nghiệm trên quy mô lớn của tôi và nhóm nghiên cứu tại Hà Nội cho thấy khi trang bị hệ thống gợi ý phương án phản hồi dựa trên kho tri thức chuẩn cho đội ngũ tổng đài viên, năng suất xử lý yêu cầu trung bình mỗi giờ tăng thêm mười lăm phần trăm [N04]. Đặc biệt, tốc độ giải quyết công việc tăng vọt hơn một phần ba ở nhóm nhân sự mới vào nghề dưới sáu tháng [N04]. Nhờ khả năng rút trích tức thời quy trình từ những ca thành công trước đó, công cụ giúp thu hẹp đáng kể khoảng cách kinh nghiệm giữa nhân viên thử việc với chuyên viên kỳ cựu mà chẳng cần kéo dài thời gian học lý thuyết tập trung [N10].

Tuy nhiên, kết quả tài chính sẽ lập tức đảo chiều nếu ban giám đốc nóng vội cắt giảm biên chế tư vấn viên để giao khoán toàn bộ luồng giao tiếp cho các hộp thoại trả lời tự động [N03]. Số liệu đối chuẩn vận hành năm 2026 chỉ ra hệ thống máy móc có thể giải quyết trọn vẹn bốn mươi mốt phần trăm yêu cầu tra cứu trạng thái đơn hàng hoặc xuất hóa đơn định kỳ [N06]. Thế nhưng điểm số hài lòng trên kênh thuần tự động vẫn tụt hậu từ năm đến mười điểm so với kênh có người thật kiểm soát ở những tình huống khiếu nại phức tạp [N06].

Nguyên nhân sâu xa khiến bốn mươi phần trăm dự án triển khai trợ lý bán hàng bị đình trệ ở giai đoạn thử nghiệm nằm ở sự phân mảnh của dữ liệu nội bộ [N08]. Kho tài liệu sản phẩm, chính sách chiết khấu và lịch sử giao dịch đang nằm rải rác trên nhiều bảng tính rời rạc chưa được làm sạch [N08]. Khi nguồn thông tin đầu vào mâu thuẫn nhau, mô hình ngôn ngữ sẽ tự suy diễn ra cam kết bảo hành hoặc mức giá khuyến mãi sai lệch [N06]. Hậu quả là trưởng bộ phận phải mất hàng giờ mỗi tuần để giải trình và xin lỗi đối tác [N06].

Để thu về mức tăng trưởng doanh thu bền vững và rút ngắn thời gian hoàn vốn xuống dưới mười bốn tháng, lộ trình triển khai bắt buộc đi qua ba chặng có cổng nghiệm thu chặt chẽ trong một quý [N10]. Trong tháng đầu tiên, doanh nghiệp tập trung chuẩn hóa toàn bộ bảng hỏi đáp sản phẩm gắn mã bằng chứng xác thực [N09]. Sang tháng thứ hai, đơn vị triển khai thí điểm cho nhóm hai mươi nhân sự bán hàng soạn thảo hồ sơ chào thầu dưới sự giám sát của bộ mười bảy luật chất lượng [N09]. Đến tháng thứ ba, công ty mới mở rộng quy mô sau khi đã đo đạc chính xác tỷ lệ chốt đơn thực tế [N09].
