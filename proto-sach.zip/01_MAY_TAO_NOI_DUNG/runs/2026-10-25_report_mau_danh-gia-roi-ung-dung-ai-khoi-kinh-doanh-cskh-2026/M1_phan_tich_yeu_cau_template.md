# BƯỚC M1: PHÂN TÍCH YÊU CẦU MEDIA HOÁ, THAM CHIẾU AGY & NẠP NHẬN DIỆN TẠM (`report_mau`)

> **Truy vết Big Module 2**: `BM2_M1_chu_trinh_template` (Bước 1/5) + `BM2_M2_media_hoa`
> **Đã gọi**: `AGY image-generator + AGY search_web + LAB028 (linhx-report: dan-trang, hinh.py) + LAB046 (report-core: 17 luật) + LAB043 (thiet_ke.py, onbrand.py, brands/sakedemy) + LAB036 (brand-check)`
> **Nhận diện tạm**: Sakedemy (`vendor/LAB043/brands/sakedemy/brand.json`, `LUAT-ONBRAND.md`)
> **Trạng thái mẫu**: chạy không mẫu

## 1. Yêu cầu đầu ra Media hoá của loại `report_mau`
- **Đề tài**: Báo cáo mẫu: Đo lường Hiệu quả Đầu tư (ROI) khi Nhúng AI vào Quy trình Kinh doanh và Chăm sóc Khách hàng 2026
- **Hạng mục sản xuất**: Ảnh phòng họp kiểm toán AI thực tế AGY (`image-generator`) + Báo Cáo Chiến Lược Tạp Chí A4 (HTML + PDF in chuẩn màu + Typst) + 2 Biểu đồ Exhibit SVG (`LAB028/hinh.py`) + Slide & Banner Sakedemy (`thiet_ke.py`)
- **Đối tượng sử dụng**: Đồng bộ trực tiếp với 3 Persona Neo (`P1`, `P2`, `P3`) đã khóa ở Bước 02 và bản thảo cuối ở Bước 09.

## 2. Tham chiếu Thị giác & Media thu thập qua AGY (`search_web`)
- **[V1] McKinsey / BCG Consulting Exhibit Architecture (AGY Web Search + LAB028)**: Bố cục bất đối xứng 70–80% bằng chứng (biểu đồ/bảng MECE) đi kèm 20–30% hộp luận giải; Action Title 24–28pt Bold nêu kết luận; bắt buộc dòng Nguồn ở chân biểu đồ.
- **[V2] Sakedemy Brand Guideline v2 (LAB043) — Hồ sơ đào tạo & Report A4**: Trang bìa và các trang ruột A4 dùng font Be Vietnam Pro + Source Serif 4, bảng màu #02403B / #6EB264 / #414141, ảnh thực tế trong khung lá bo góc đối xứng.

## 3. Thông số Nhận diện tạm Sakedemy đã nạp (`LAB043`)
- **Tên thương hiệu trong văn bản**: `Sakedemy` (tiêu đề trang trọng: `Sakédemy`, tuyệt đối không viết tắt `Sake`).
- **Tagline chuẩn**: *"Khi sáng tạo gặp công nghệ"*
- **Bảng màu bắt buộc**:
  - Màu chính: Xanh Lá Sakédemy (`#6EB264`), Xanh Rêu Đậm (`#02403B`), Xám Chữ (`#414141`).
  - Màu phụ & nền: Trắng (`#FFFFFF`), Trắng Giấy (`#FDFDFD`), Lá Nhạt (`#E9F6D3`), Xanh Lá Sâu (`#118056` cho chữ xanh nhỏ trên nền trắng).
  - Điểm nhấn: Gradient Lá Non sang Ngọc (`linear-gradient(210deg, #A3D34F, #26CABE)` — tối đa 5% diện tích).
- **Kiểu chữ**: `Be Vietnam Pro` (`Light`, `Regular`, `Bold`), tỷ lệ cỡ chữ `3.2 : 1.6 : 1 : 0.8`.
- **Ngôn ngữ hình khối**: Khung hình lá (vuông/chữ nhật bo hai góc chéo trên-trái và dưới-phải), hoạ tiết gân lá 45° dưới 20% độ đậm ở góc.
