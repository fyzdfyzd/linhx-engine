# BƯỚC 07: ĐÁNH GIÁ DRAFT 1 BẰNG SCRIPT ĐỊNH LƯỢNG & PHẢN BIỆN (`noi_dung_khoa_hoc`)

> **Truy vết Module**: `BM1_07_danh_gia_draft1`
> **Đã gọi**: `LAB049/cham_cau.py`, `LAB049/kiem_van_dich.py`, `LAB049/kiem_van.py`, `LAB049/soat-cau-truc`, `LAB025/gemini-reviewer` (APS/CQS), `LAB046/quality.py`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Kết quả chạy thật bộ 3 Script Lượt 0 (`LAB049`) trên `06_trien_khai_draft_1.md`
- **Điểm chất lượng tổng hợp (`CQS`)**: `70.3/100` (Ngưỡng yêu cầu: `≥ 85.0`)
- **Điểm dấu vân máy (`APS`)**: `32.0/100` (Ngưỡng yêu cầu: `≤ 25.0`, càng thấp càng tốt)
- **Kết luận cổng `cham_cau.py` trên Draft 1**: **TRƯỢT (CẦN SỬA Ở BƯỚC 08)**
  - Số câu: `7` · Tổng từ: `278` · Độ dài câu TB: `39.7` từ/câu · Tỷ lệ câu >35 từ: `71%` · Tỷ lệ hai vế: `0%`
- **Điểm `kiem_van_dich.py`**: `50/100` (Số lỗi văn dịch gốc bắt được: `2`)
- **Điểm `kiem_van.py` (so mốc giọng Linh)**: `86/100`

## 2. Danh sách lỗi cụ thể máy bắt được trên Draft 1 (Giao cho Bước 08 sửa triệt để)
- **Bắt lỗi**: [LAB049/cham_cau] câu TB 39.7 > 39 (dài quá mức Linh)
- **Bắt lỗi**: [LAB049/cham_cau] 3 câu có cờ cứng (hồi quy, thiếu mã nguồn, văn dịch, chữ số)
- **Bắt lỗi**: [LAB049/kiem_van_dich dòng 9] trong bối cảnh -> bỏ, hoặc "giữa lúc", "khi"
- **Bắt lỗi**: [LAB049/kiem_van_dich dòng 9] không chỉ dài dòng mà còn -> tách hai câu hoặc chọn một ý
- **Bắt lỗi**: [LAB049/kiem_van_dich dòng 13] trước khi ×2 -> văn Linh kỳ vọng ~0.0 lần, LLM gấp 36.7
- **Bắt lỗi**: [LAB049/kiem_van AP-03 dòng 9] Đối lập giả 'không chỉ… mà còn'

## 3. Nhận xét Cấu trúc (`LAB049/soat-cau-truc` & `LAB046/quality.py`)
- **Điểm mạnh của Draft 1**: Đã bám đúng Phương án B chốt ở Bước 05, có gắn mã nguồn `[Nxx]` / `[GIẢ LẬP]`.
- **Điểm yếu bắt buộc phải viết lại ở Bước 08**:
  1. Khử sạch các cụm văn dịch mở đầu câu (*'Trong bối cảnh'*, *'Điều đáng chú ý là'*, *'đóng vai trò quan trọng'*) và cấu trúc khuôn *'không chỉ... mà còn...'*.
  2. Đổi toàn bộ chữ số Ả Rập nằm trong dòng văn xuôi sang chữ viết tiếng Việt (trừ số năm `2026`) theo đúng kỷ luật báo chí của `cham_cau.py`.
  3. Kéo độ dài câu trung bình vào đúng dải nhịp thở `22 – 34 chữ/câu` của hồ sơ giọng tác giả, tăng chiều sâu chi tiết thực địa cho cả 3 Persona Neo (`P1`, `P2`, `P3`).
