# BƯỚC M3: ĐỀ XUẤT 3 PHƯƠNG ÁN TEMPLATE KHÁC BIỆT (`T-A`, `T-B`, `T-C`) & GHÉP KHUÔN `LAB043`

> **Truy vết Big Module 2**: `BM2_M1_chu_trinh_template` (Bước 3/5 — theo chuẩn PHẦN 4 của `LAB043/KHUNG-GUIDELINE-CHUAN.md`)
> **Đã gọi**: `LAB043/linhx-onbrand/scripts/thiet_ke.py`, `LAB027/hinh-anh`, `LAB031/the-phong-cach`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Ba phương án thiết kế đặt lên bàn cân

| Mã PA | Mô tả cấu trúc & Bảng màu | Ưu điểm | Nhược điểm / Rủi ro Onbrand |
|---|---|---|---|
| **T-A** | T-A (Slide nhiều chữ 250 từ/slide, chia 4 ô đều nhau): Học viên đọc chữ trên màn hình thay vì nghe giảng viên nói, vi phạm chuẩn slide LAB027. | Tạo ấn tượng thị giác đậm ngay trang đầu. | Nặng nề khi đọc nhiều trang, khoảng trắng < 25%. |
| **T-B ★** | T-B ★ (Slide 16:9 chuẩn LAB027 + Sakedemy: Mỗi slide đúng 1 điểm chính, 1 tiêu điểm thị giác từ ảnh AGY `image-generator` hoặc biểu đồ `H01.svg`/`H02.svg`, ít nhất 35% khoảng trắng; ô số `.so` dùng chữ `#02403B` trên nền `#6EB264` đạt 4,57:1) | Đạt chuẩn tương phản WCAG AA (`4,57:1` – `11,2:1`), đúng tỷ lệ `60/25/10/5`, kết hợp hài hoà ảnh chụp AGY và biểu đồ `LAB028`. | Đòi hỏi căn chỉnh lưới 12 cột, mặt nạ `.mask.png` và bo góc chéo hình lá chính xác. |
| **T-C** | T-C (Slide trộn chữ tiêu đề màu Navy #051D40 với mảng Xanh Lá #6EB264): Vi phạm LUAT-ONBRAND.md ('không dùng navy cạnh xanh lá trên ấn phẩm mới'). | Màu sắc bắt mắt kiểu quảng cáo mạng xã hội. | Vi phạm trực tiếp `LUAT-ONBRAND.md` của Sakedemy. |

## 2. Khuôn HTML `LAB043` được nạp để kết xuất PNG thực tế bằng `thiet_ke.py`
1. **Khuôn Banner Web (`banner-web.html`, `1920×600`)**: Nền trắng `#FFFFFF`, logo ngang góc trên trái, mảng hình lá `#6EB264` bên phải ôm ảnh chụp AGY `agy_anh_goc_sakedemy.jpg` (`border-radius: 200px 0 200px 0`), vòng cung trắng góc trên phải, dải gân lá mờ.
2. **Khuôn Chuyên biệt theo loại nội dung**:
   - Với `bai_viet`: `social-vuong-la.html` (`1080×1080`) + `banner-web.html` (`1920×600`).
   - Với `report_mau`: `khuon_v1_2_slide_169.html` (`1920×1080`) + `banner-web.html` (`1920×600`) + Khuôn Tạp chí A4 2 cột (`bao_cao_sakedemy_a4.html`).
   - Với `noi_dung_khoa_hoc`: `khuon_v1_2_slide_169.html` (`1920×1080`) + `story-xanh-la.html` (`1080×1920`) + Khuôn Slide Deck 16:9 (`slide_deck_sakedemy_16x9.html`).
