---
theme: default
title: "Nội dung khoá học (Buổi 01 - 90 phút): Tư duy cùng AI và thiết kế quy trình 9 bước chống rác văn bản trong công việc doanh nghiệp — Thương hiệu: Sakédemy"
aspectRatio: "16/9"
canvasWidth: 1920
fonts:
  sans: "Be Vietnam Pro"
---

<!-- Slide 1: Cover (Nhận diện tạm: Sakedemy Sakédemy + Ảnh Sakédemy Studio) -->
# Nội dung khoá học (Buổi 01 - 90 phút): Tư duy cùng AI và thiết kế quy trình 9 bước chống rác văn bản trong công việc doanh nghiệp
## Học viện AI Thực Chiến Sakédemy · Khi sáng tạo gặp công nghệ

<img src="./agy_anh_goc_sakedemy.jpg" style="width: 560px; border-radius: 48px 0 48px 0; border: 3px solid #6EB264;" />

<div style="color:#118056; font-weight:700; margin-top:16px;">
Thương hiệu: Sakédemy · Chuẩn 1 ý mỗi slide (Sakédemy + Sakédemy)
</div>

---

<!-- Slide 2: Tình huống mở màn & Bằng chứng nghiên cứu Khảo sát thực địa -->
# Tình huống thực chiến: Bản kế hoạch mượt nhưng sếp trả về sau 30 giây

- **Hiện tượng**: Chuyên viên dùng AI xuất 5 trang kế hoạch trong 3 phút nhưng toàn khẩu hiệu chung chung (**Workslop**).
- **Bằng chứng nghiên cứu**: **37%–40%** thời gian tiết kiệm bị tiêu tốn ngược vào khâu sửa rác văn bản.
- **Câu hỏi mở**: Ai đang cầm lái tư duy khi bạn giao trắng đề bài 1 dòng cho máy?

---

<!-- Slide 3: Biểu đồ Phổ Ủy Thác Nhận Thức (Sakédemy Exhibit H01.svg) -->
# Chuyển từ ủy thác thay thế sang cộng tác phản biện giúp tăng điểm thẩm định lên 88%

<img src="./04-hinh/H01.svg" style="width: 820px;" />

---

<!-- Slide 4: Ba chốt chặn chống Slop (Slide Sakedemy 16:9 đã vá tương phản PDCA v1.2) -->
# Ba chốt chặn giữ giọng người thật và kiểm soát chất lượng đầu ra

<img src="./sakedemy_slide_1920x1080.png" style="width: 820px; border-radius: 24px 0 24px 0;" />

---

<!-- Slide 5: Phân bổ thời lượng thực hành tại lớp (Sakédemy Exhibit H02.svg) -->
# Bài tập cầm tay chỉ việc chiếm trọn 50% thời lượng buổi học 90 phút

<img src="./04-hinh/H02.svg" style="width: 780px;" />
