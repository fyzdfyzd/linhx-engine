# BƯỚC 06: KỊCH BẢN LỜI GIẢNG GAGNÉ 5 BƯỚC & KHUNG SLIDE — DRAFT 1 (`noi_dung_khoa_hoc`)

> **Truy vết Module**: `BM1_06_trien_khai_draft1`
> **Đã gọi**: `LAB017/linhx-course/skills/lesson-script` (Gagné 5 sự kiện rút gọn + `slides.md`)
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

# KỊCH BẢN BUỔI HỌC THỰC CHIẾN SỐ MỘT: TƯ DUY CÙNG AI VÀ THIẾT KẾ QUY TRÌNH CHỐNG RÁC VĂN BẢN

Trong bối cảnh rất nhiều học viên đi học về vẫn bị sếp trả lại bài viết, buổi học đầu tiên này của Sakédemy đi thẳng vào việc giải phẫu một bản báo cáo thật vừa bị退 trả lúc chín giờ sáng [N03]. Khi nhìn lên màn chiếu, anh chị sẽ thấy đoạn văn mở đầu không chỉ dài dòng mà còn dùng toàn những cụm từ dịch thuật sáo rỗng khiến người đọc mỏi mắt ngay từ câu thứ hai [N02].

Sai lầm phổ biến nhất của người đi làm là gộp cả việc tìm ý tưởng, viết nháp và biên tập vào chung một câu lệnh duy nhất rồi phó mặc cho máy tự xoay xở [N04]. Khi máy không có hạt giống thực tế từ người viết, nó buộc phải lấy trung bình cộng của hàng triệu văn bản trên mạng để lấp đầy trang giấy, tạo ra những câu văn trơn tru bề mặt nhưng hoàn toàn vô hồn [N04].

Trong chín mươi phút hôm nay, tôi cùng anh chị sẽ thực hành quy tắc giữ chốt hai đầu trên chính công việc mà anh chị đang nợ phòng ban của mình [N07]. Trước khi yêu cầu máy viết bất kỳ dòng nào, mỗi người sẽ tự dựng ba độc giả khó tính nhất trong công ty để thử dàn ý, sau đó dùng bảng kiểm tám lỗi văn dịch của bàn biên tập để quét sạch mọi dấu vết máy móc trước khi gửi đi [N12].
