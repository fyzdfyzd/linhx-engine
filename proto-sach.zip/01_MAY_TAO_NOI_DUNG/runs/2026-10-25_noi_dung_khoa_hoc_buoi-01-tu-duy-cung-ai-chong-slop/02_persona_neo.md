# BƯỚC 02: NGHIÊN CỨU NGƯỜI NHẬN & DỰNG 3 PERSONA NEO (`noi_dung_khoa_hoc`)

> **Truy vết Module**: `BM1_02_persona_neo` (Gộp mới từ `LAB029` + `LAB048` + `LAB049`)
> **Đã gọi**: `LAB029/nhu-cau-doc-gia`, `LAB048/lay_mau_1000.py` (`persona-sample-60.json`), `LAB049/doc-gia-ao`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Phân tích khoảng trống người nhận (Theo `LAB029`)
- **Đề bài**: Nội dung khoá học (Buổi 01 - 90 phút): Tư duy cùng AI và thiết kế quy trình 9 bước chống rác văn bản trong công việc doanh nghiệp
- **Chủ đề đối chuẩn**: Khoá học thực chiến (Buổi 1): Tư duy cùng AI & Thiết kế quy trình chống rác AI (AI Slop) trong công việc
- **Khoảng trống trên thị trường hiện tại**: Đa số khoá học dạy mẹo viết câu lệnh (prompt templates) rời rạc; học viên chép về dùng được 2 lần rồi bỏ vì không biết cách biến công việc thành quy trình có bước kiểm duyệt.
- **Điểm cơ hội khoảng trống (`gap_score`)**: **8.8/10**

## 2. Hồ sơ 3 Persona Neo (Lọc nhân khẩu `LAB048` + Tâm lý phản biện `LAB049`)

### [P1] Chuyên viên cao cấp / Quản lý cấp trung đi học để giải quyết việc thật tại công ty
- **Hồ sơ nhân khẩu học (`LAB048` UUID `5a6da93b-c8c7-57ad-bd64-8bcbfb6542bc`)**: 40 tuổi · Nữ · Nông Thôn (Tây Nguyên) · Học vấn: Tiểu học
- **Bối cảnh tiếp nhận (`LAB049`)**: Ngồi trong lớp học doanh nghiệp (hoặc xem slide/video e-learning trên laptop), trước mặt đang mở sẵn 1 báo cáo/kế hoạch thật cần làm xong trong tuần.
- **Nỗi sợ ẩn**: Tốn 2 tiếng ngồi học toàn khái niệm lịch sử AI vĩ mô mà hết buổi vẫn không ra được bản khung cho công việc đang nợ sếp.
- **Câu cửa miệng hay cãi (Phản xạ phòng vệ)**: *"Thầy làm ví dụ trên đề bài mẫu thì mượt thế, chứ đụng vào hồ sơ khách hàng lắt léo của em là AI nó viết ngô nghê ngay."*
- **Ngưỡng bỏ đọc (`trigger_bo_doc`)**: 15 phút đầu toàn định nghĩa học thuật hoặc slide nhiều chữ đọc chép lại y hệt trên màn hình.
- **Kỳ vọng mang về sau khi đọc/học**: Cầm tay chỉ việc 1 khung quy trình 5-9 bước áp dụng ngay vào bài toán thật của mình ngay trong giờ thực hành.

### [P2] Nhân sự lớn tuổi / Trái ngành công nghệ (Sợ thao tác phức tạp, dễ ngợp thuật ngữ tiếng Anh)
- **Hồ sơ nhân khẩu học (`LAB048` UUID `605f7166-1535-5205-88e9-26ac78d51721`)**: 48 tuổi · Nữ · Đô Thị (Đông Nam Bộ) · Học vấn: Trung cấp / Cao đẳng
- **Bối cảnh tiếp nhận (`LAB049`)**: Theo dõi từng bước trên màn chiếu, rất cần ví dụ so sánh trực quan 'Trước khi sửa (bản AI lỗi)' và 'Sau khi sửa (bản đạt chuẩn)'.
- **Nỗi sợ ẩn**: Sợ giảng viên dùng toàn từ tiếng Anh chuyên ngành (token, context window, hallucination, zero-shot) làm mình không theo kịp đám trẻ.
- **Câu cửa miệng hay cãi (Phản xạ phòng vệ)**: *"Nhiều bước thế này nhớ làm sao hết, có bảng kiểm (checklist) 1 trang tiếng Việt dễ hiểu để nhìn vào làm theo không?"*
- **Ngưỡng bỏ đọc (`trigger_bo_doc`)**: Slide nhồi quá 3 thuật ngữ tiếng Anh không giải nghĩa hoặc chuyển cảnh quá nhanh không có hình mẫu đối chiếu.
- **Kỳ vọng mang về sau khi đọc/học**: Checklist tiếng Việt ngắn gọn, dễ nhớ và 3 dấu hiệu nhận biết ngay văn bản do AI viết ẩu để tự sửa.

### [P3] Nhân sự trẻ rành công cụ (Đã dùng ChatGPT/Claude hàng ngày nhưng hay nộp bài bị sếp trả về)
- **Hồ sơ nhân khẩu học (`LAB048` UUID `67b94031-2692-54f7-a51d-641e66491895`)**: 25 tuổi · Nam · Nông Thôn (Đồng bằng sông Cửu Long) · Học vấn: Trung học phổ thông
- **Bối cảnh tiếp nhận (`LAB049`)**: Mở laptop gõ thử ngay khi giảng viên đang giảng; nếu thấy kiến thức cơ bản quá sẽ quay sang làm việc riêng.
- **Nỗi sợ ẩn**: Mình dùng AI làm rất nhanh nhưng sếp đọc 3 dòng là phát hiện ra 'văn ChatGPT' và đánh giá mình làm việc hời hợt.
- **Câu cửa miệng hay cãi (Phản xạ phòng vệ)**: *"Em dùng đủ công thức Role-Task-Context rồi mà sao bài ra vẫn bị chê là sáo rỗng?"*
- **Ngưỡng bỏ đọc (`trigger_bo_doc`)**: Giảng viên dạy lại cách đăng nhập ChatGPT hoặc công thức viết prompt sơ cấp đã tràn lan trên mạng.
- **Kỳ vọng mang về sau khi đọc/học**: Kỹ thuật tách ngữ cảnh phản biện (Persona Neo + 6 lượt biên tập) để khử sạch mùi văn dịch và nâng chất lượng bài lên mức chuyên gia.

## 3. Quy tắc neo cho các bước sau
- **Bước 4 (`BM1_04_outline_thu_persona`)**: Cả 3 phương án Outline A/B/C bắt buộc phải đưa qua 3 Persona `P1`, `P2`, `P3` đọc thử và trả lời câu cãi của họ.
- **Bước 8 & 9 (`BM1_08`, `BM1_09`)**: Bản viết cuối không được vi phạm `trigger_bo_doc` của bất kỳ Persona nào và phải trả lời trực diện ít nhất 2/3 câu cãi trên.
