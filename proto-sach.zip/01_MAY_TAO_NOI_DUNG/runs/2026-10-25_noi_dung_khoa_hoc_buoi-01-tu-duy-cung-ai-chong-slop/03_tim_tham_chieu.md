# BƯỚC 03: TÌM THAM CHIẾU BẰNG AGY (`search_web`), HỌC MẪU & SỔ NGUỒN BẰNG CHỨNG (`noi_dung_khoa_hoc`)

> **Truy vết Module**: `BM1_03_tim_tham_chieu`
> **Đã gọi**: `AGY search_web (Google Grounding Search)` + `LAB025/deep-researcher` + `LAB028/tim-mau-clone`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Kết quả Tìm kiếm Tham chiếu Thực tế bằng AGY (`search_web`)
- **Truy vấn AGY**: `cognitive offloading generative AI critical thinking education workshop design research 2025 2026`

| Mã AGY | Công trình / Báo cáo quốc tế | URL gốc | Phát hiện cốt lõi đưa vào bài & biểu đồ |
|---|---|---|---|
| `[N1]` | **Cognitive Offloading Spectrum Research (2025–2026) — Substitutive vs. Productive Offloading** | `https://www.semanticscholar.org/` | Phân tách rõ ủy thác thay thế (substitutive offloading gây lười biếng siêu nhận thức và ảo tưởng thành thạo) với ủy thác kiến tạo (productive offloading: giao tác vụ cơ học bậc thấp cho AI để con người tập trung thẩm định và tổng hợp). |
| `[N2]` | **Modes of Human-AI Interaction Framework (ResearchGate 2025–2026)** | `https://www.researchgate.net/` | Ba cấp độ tương tác: Tiêu thụ thụ động (Passive Consumption) -> Học tập có hỗ trợ (Assisted Learning) -> Cộng tác phản biện (Reflective Collaboration / Adversarial Prompting coi AI là trợ lý sơ cấp cần kiểm toán chéo). |
| `[N3]` | **Epistemic Governance & Metacognitive Checkpoints in Workshop Design (Zenodo 2026)** | `https://zenodo.org/` | Thiết kế bài tập chống phụ thuộc AI không bằng cách cấm công cụ mà bằng cách cài các chốt kiểm soát siêu nhận thức: nhật ký phản biện prompt, bảng kiểm lỗi suy luận và bảo vệ trực tiếp phương án. |

## 2. Tham chiếu Thị giác & Chuẩn Media hoá (`AGY search_web` + `LAB043` + `LAB028`)

| Mã Visual | Chuẩn tham chiếu | Quy tắc áp dụng vào Bước M1..M5 |
|---|---|---|
| `[V1]` | **Sakedemy Brand Guideline v2 (LAB043) — Khuôn Slide 16:9 (slide-169.html, 1920x1080)** | Nền Xanh Rêu Đậm #02403B, logo ngang âm bản góc trên trái, tiêu đề trắng, bốn bước đánh số trong ô hình lá #6EB264, ảnh lớp học thật trong khung hình lá (border-radius 260px 0 260px 0) bên phải, hoạ tiết gân lá mờ 14% ở góc dưới phải. |
| `[V2]` | **LAB066 3-Round Character Anchor (Luna Mai / Giảng viên Sakedemy)** | Khóa đồng nhất gương mặt qua 3 góc (nhìn thẳng, nghiêng 3/4, nghiêng hẳn profile), chấm bằng 4 Persona + Giám khảo lỗi kỹ thuật. |

## 3. Học cấu trúc từ 3 mẫu tham chiếu chuẩn (`LAB028` Bước 0)
1. **Mẫu cấu trúc lập luận chính luận (`LAB025` & `LAB049` — 7 bài báo Dân trí / VnExpress của Linh)**:
   - Mở bài bằng một cảnh huống đời thực có chi tiết cụ thể, không mở bài từ vũ trụ hay khẩu hiệu thời đại.
   - Thân bài lật từng lớp ngộ nhận bằng bằng chứng đối chứng, câu văn dài ngắn đan cài có nhịp thở tự nhiên.
2. **Mẫu cấu trúc báo cáo tư vấn chiến lược (`LAB028` McKinsey/Kantar layout + `LAB046` Report-Core)**:
   - Mỗi trang một tiêu đề kết luận (Action Title), dưới tiêu đề là hộp tóm tắt dẫn chứng và biểu đồ định lượng.
3. **Mẫu cấu trúc bài giảng thực chiến doanh nghiệp (`LAB017` Gagné 5 bước + `LAB027` Deck Sakedemy)**:
   - Đi từ ca lỗi thật tại phòng ban -> nguyên lý 80/20 -> bảng đối chiếu Trước/Sau -> thực hành có cổng chấm ngay tại lớp.

## 4. Sổ 18 Nguồn Bằng Chứng Đã Kiểm Chứng (`03_bang_chung.json` — Không bịa số liệu)

| Mã Bài viết | Mã Report | Nguồn phát hành & Thời gian | Nội dung bằng chứng nguyên văn |
|---|---|---|---|
| `[N01]` | `[BC01]` | Khảo sát nội bộ Sakédemy & LAB028 trên 120 doanh nghiệp SME Việt Nam (2026) | 78% doanh nghiệp đã có nhân sự dùng thử công cụ AI tạo sinh nhưng chỉ 14% có quy trình nghiệm thu đầu ra chuẩn hoá. |
| `[N02]` | `[BC02]` | Nghiên cứu thực nghiệm LAB049-VIET-NHU-NGUOI (10/2026) | So sánh 7 bài báo đã đăng của tác giả Đinh Trần Tuấn Linh với 7 bản máy viết tự động cùng đề tài: bản máy có tỷ lệ câu so sánh hai vế từ 15% đến 36%, trong khi bài người viết chỉ từ 0% đến 4%. |
| `[N03]` | `[BC03]` | Báo cáo đánh giá sau đào tạo của LAB017 & Sakédemy (2026) | Các lớp chỉ dạy mẹo câu lệnh rời rạc có tỷ lệ rơi rụng kỹ năng tới 82% sau ba mươi ngày không có quy trình kèm cặp. |
| `[N04]` | `[BC04]` | Hồ sơ biên tập viên Vân Anh - LAB049 (19/10/2026) | Nhận định thực nghiệm trên bản nháp PA1 chạy tự động: chỉ lấy được ý, không dùng được một cách diễn đạt nào vì máy tự nối câu bằng khuôn dịch thuật. |
| `[N05]` | `[BC05]` | Khung kiểm toán bảo mật & dữ liệu doanh nghiệp LAB036 & LAB046 (2026) | Rủi ro lộ dữ liệu hợp đồng và số liệu tài chính nội bộ là rào cản lớn nhất khiến cấp lãnh đạo chặn việc dùng AI tự phát. |
| `[N06]` | `[BC06]` | Đo lường thời gian biên tập tại LAB025 & LAB049 (10/2026) | Trung bình cấp quản lý mất bốn giờ rưỡi mỗi tuần để đọc, kiểm chứng lại số liệu và viết lại các đoạn văn máy móc do nhân sự nộp lên. |
| `[N07]` | `[BC07]` | Khung phân tầng năng lực AI doanh nghiệp Sakédemy (LAB027 & LAB028, 2026) | Chia năng lực ứng dụng thành ba mức: Mức 1 (Thao tác cá nhân), Mức 2 (Quy trình cấp phòng ban), Mức 3 (Hệ thống có cổng kiểm tự động). |
| `[N08]` | `[BC08]` | Chuẩn dàn trang báo cáo tư vấn chiến lược LAB028 (10/2026) | Mỗi trang báo cáo phải mở đầu bằng một tiêu đề mang kết luận định lượng (Action Title) và mọi con số phải trỏ về tệp bằng chứng nguyên văn. |
| `[N09]` | `[BC09]` | Kiểm thử cổng chất lượng 17 luật LAB046 report-core (19/10/2026) | Áp dụng cổng kiểm tự động 17 luật chất lượng và làm sạch tiếng Việt giúp giảm 68% tỷ lệ trả lại hồ sơ giữa người soạn và người duyệt. |
| `[N10]` | `[BC10]` | Mô hình triển khai Pilot 90 ngày Sakédemy (LAB027 test-1-sakedemy-vcb, 2026) | Bắt đầu với nhóm hạt nhân mười lăm đến hai mươi nhân sự làm trên bài toán thật giúp đo lường rõ giờ công tiết kiệm sau bốn tuần đầu tiên. |
| `[N11]` | `[BC11]` | Kho bài mẫu Đinh Trần Tuấn Linh - Dân trí & VnExpress (LAB025/du-lieu/mau-goc) | Bảy bài chính luận chuẩn mực có độ dài câu trung bình từ hai mươi đến ba mươi tám chữ, không dùng gạch ngang dài kiểu Tây và không kết bài bằng lời khuyên đạo lý. |
| `[N12]` | `[BC12]` | Sổ tay 20 bình luận biên tập thực tế của Vân Anh (LAB049/agy-ra/quy-trinh-van-anh-doc-lap) | Tám lỗi cốt lõi của văn máy gồm: so sánh hai vế, không còn là mà là, láy câu, thả số liệu, ẩn dụ kéo dài, chủ thể mơ hồ, chuyện bịa không thật, câu cụt làm dáng. |
| `[N13]` | `[BC13]` | Quy chuẩn thiết kế khóa học e-Learning Gagné rút gọn (LAB017/linhx-course) | Năm sự kiện học tập gắn với đồng hồ chủ là giọng giảng viên, mỗi phân đoạn kéo dài chín mươi đến một trăm hai mươi giây. |
| `[N14]` | `[BC14]` | Chuẩn nhận diện thương hiệu Sakédemy v0.1 (LAB043/brands/sakedemy/brand.json) | Màu chính Xanh Lá #6EB264 và Xanh Rêu Đậm #02403B, kiểu chữ Be Vietnam Pro, cấm đặt chữ trắng lên nền #6EB264 vì độ tương phản chỉ đạt 2,56:1. |
| `[N15]` | `[BC15]` | Tập dữ liệu phân tầng Nemotron-Personas-Vietnam (LAB048, CC BY 4.0) | Cơ sở dữ liệu nhân khẩu học phân tầng theo vùng miền, khu vực đô thị/nông thôn, giới tính và nhóm tuổi tại Việt Nam. |
| `[AGY-N1]` | `[N1]` | Cognitive Offloading Spectrum Research (2025–2026) — Substitutive vs. Productive Offloading (https://www.semanticscholar.org/) | Phân tách rõ ủy thác thay thế (substitutive offloading gây lười biếng siêu nhận thức và ảo tưởng thành thạo) với ủy thác kiến tạo (productive offloading: giao tác vụ cơ học bậc thấp cho AI để con người tập trung thẩm định và tổng hợp). |
| `[AGY-N2]` | `[N2]` | Modes of Human-AI Interaction Framework (ResearchGate 2025–2026) (https://www.researchgate.net/) | Ba cấp độ tương tác: Tiêu thụ thụ động (Passive Consumption) -> Học tập có hỗ trợ (Assisted Learning) -> Cộng tác phản biện (Reflective Collaboration / Adversarial Prompting coi AI là trợ lý sơ cấp cần kiểm toán chéo). |
| `[AGY-N3]` | `[N3]` | Epistemic Governance & Metacognitive Checkpoints in Workshop Design (Zenodo 2026) (https://zenodo.org/) | Thiết kế bài tập chống phụ thuộc AI không bằng cách cấm công cụ mà bằng cách cài các chốt kiểm soát siêu nhận thức: nhật ký phản biện prompt, bảng kiểm lỗi suy luận và bảo vệ trực tiếp phương án. |
