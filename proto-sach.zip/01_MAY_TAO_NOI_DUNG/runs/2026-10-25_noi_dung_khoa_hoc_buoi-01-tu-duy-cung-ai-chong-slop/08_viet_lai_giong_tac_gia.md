# BƯỚC 08: VIẾT LẠI THEO GIỌNG TÁC GIẢ & CÂN BẰNG ĐỘC GIẢ (`noi_dung_khoa_hoc`)

| Hạng mục truy vết | Giá trị |
|---|---|
| **Truy vết Module** | `BM1_08_viet_lai_giong_tac_gia` |
| **Đã gọi** | `LAB049/linhx-viet-giong-viet`, `LAB049/luong-hoa`, `ho-so-bien-tap/linh/LUAT.md`, `ho-so-bien-tap/van-anh/LUAT.md` |
| **Nhận diện tạm** | Sakedemy (LAB043) |
| **Trạng thái mẫu** | chạy không mẫu |

# Kịch bản buổi học thực chiến số một: Tư duy cùng máy và thiết kế quy trình chống rác văn bản

Khi bước vào lớp học thực chiến hôm nay của Sakédemy, tôi không mở đầu bằng lịch sử trí tuệ nhân tạo mà mời cả lớp nhìn thẳng lên màn chiếu [N13]. Trên màn hình là một bản đề xuất dài ba trang vừa bị giám đốc trả về lúc chín giờ sáng đầu tuần [N13]. Chỉ cần đọc lướt đến câu thứ ba, bất kỳ người quản lý có kinh nghiệm nào tại Hà Nội hay TP.HCM cũng nhận ra ngay mùi văn dịch máy móc [N02]. Văn bản ấy chứa đầy những cặp câu đối xứng cứng nhắc, những tính từ tán dương rỗng tuếch và những con số thả nổi chẳng ăn nhập gì với bài toán kinh doanh của phòng mình [N02].

Mục tiêu duy nhất của buổi làm việc đầu tiên này là giúp mỗi học viên ngồi đây giải quyết dứt điểm một đầu việc đang nợ sếp ngay trên máy tính cá nhân trước khi rời khỏi phòng học [N03]. Sau buổi rèn luyện theo năm bước sư phạm rút gọn cùng tôi, người học sẽ tự tay tháo bỏ thói quen gõ câu lệnh cầu may để chuyển sang nắm giữ quy trình chín bước có cổng kiểm chất lượng rõ ràng [N13]. Mỗi người cũng sẽ cầm về bảng kiểm tám lỗi văn dịch trên một trang giấy tiếng Việt dễ nhớ để áp dụng ngay vào sáng hôm sau [N12].

Nguyên tắc nền tảng đầu tiên mà tôi đề nghị cả lớp ghi xuống sổ tay là quy luật phân bổ trách nhiệm trong phối hợp giữa con người với công cụ tại doanh nghiệp [N07]. Người làm chuyên môn bắt buộc phải nắm giữ phần mở đầu bao gồm hạt giống ý tưởng rút từ va chạm nghề nghiệp cùng việc dựng lên ba chân dung người đọc khó tính nhất sẽ cầm tờ trình [N09]. Sau đó, chúng ta mới giao khâu tìm kiếm tư liệu đối chứng và làm mượt câu chữ ở giữa cho phần mềm [N09]. Khâu khóa sổ cuối cùng vẫn phải do chính con người cầm bút gạch bỏ những câu văn thừa [N09].

Trong phần thực hành cầm tay chỉ việc tiếp theo, mỗi học viên sẽ mở chính tệp tài liệu công việc đang làm dở ra và viết xuống năm gạch đầu dòng bằng ngôn ngữ đời thường [N04]. Tiếp đó, cả lớp sẽ cho ba độc giả ảo đóng vai sếp, đồng nghiệp phòng bên và khách hàng khó tính đọc thử dàn ý để bắt lỗi ngay từ bước phác thảo [N04]. Ngay khi bản nháp đầu tiên hiện ra trên màn hình, tôi sẽ hướng dẫn từng người dùng bộ lọc sáu lượt biên tập tách rời ngữ cảnh của chị Vân Anh để cắt sạch các cấu trúc câu dịch thuật và giữ lại đúng những câu văn mang dấu ấn cá nhân [N12].

Phần khóa sổ cuối giờ là lúc hai người ngồi cạnh nhau đổi bài cho nhau để chấm chéo theo đúng ba tiêu chí nghiệm thu của Sakédemy [N14]. Cả lớp cũng sẽ trả lời năm câu hỏi tình huống phân loại nhanh trên bảng chiếu vào phút chót của buổi học [N14]. Học viên đạt yêu cầu rời lớp hôm nay là người cầm trên tay bản thảo công việc đã vượt qua ngưỡng điểm chất lượng biên tập, sạch bóng các từ cấm sáo rỗng và sẵn sàng gửi thẳng vào nhóm làm việc của bộ phận mình [N09].
