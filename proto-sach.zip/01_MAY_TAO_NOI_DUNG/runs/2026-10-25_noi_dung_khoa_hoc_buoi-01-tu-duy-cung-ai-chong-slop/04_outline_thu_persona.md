# BƯỚC 04: 30 INSIGHTS, 3 HƯỚNG OUTLINE (A/B/C) & THỬ TRÊN PERSONA (`noi_dung_khoa_hoc`)

> **Truy vết Module**: `BM1_04_outline_thu_persona` (Kế thừa `LAB025/content-synthesizer` + **Làm mới** phần thử phản ứng trên 3 Persona Neo)
> **Đã gọi**: `LAB025/content-synthesizer` (30 insights -> 3 variants) + `BM1_04/thu_outline_persona.py`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Nén 30 Insights từ Tư liệu Nghiên cứu (`LAB025` Bước 5)
- Tổng số insights đã rút: **30 insights** (chia đều 4 nhóm: `fact`, `paradox`, `metaphor`, `provocation`).
- 10 Insights hạt nhân tiêu biểu:
  - `01` (fact): [Insight #01 · fact] Học viên doanh nghiệp quên 70% câu lệnh mẫu sau 1 tuần nếu không hiểu cấu trúc phân rã công việc thành từng bước nhỏ [N01]. (Góc khai thác tầng 1)
  - `02` (paradox): [Insight #02 · paradox] Giọng giảng là đồng hồ chủ của bài học: mỗi phân đoạn chỉ nên tải 1 ý chính trong 90-120 giây để giữ nhịp chú ý [N02]. (Góc khai thác tầng 1)
  - `03` (metaphor): [Insight #03 · metaphor] Cấu trúc 5 sự kiện Gagné rút gọn giúp học viên đi từ tình huống đau thực tế thẳng tới thao tác làm được ngay tại lớp [N03]. (Góc khai thác tầng 1)
  - `04` (provocation): [Insight #04 · provocation] Sai lầm phổ biến nhất của người mới là gộp bước 'Tìm ý', 'Viết nháp' và 'Biên tập' vào chung một câu lệnh duy nhất [N04]. (Góc khai thác tầng 1)
  - `05` (fact): [Insight #05 · fact] Khi cho học viên xem trực tiếp bảng so sánh 'Bản AI viết ẩu' và 'Bản đã qua 6 lượt biên tập', tốc độ nhận diện lỗi tăng gấp 3 lần [N05]. (Góc khai thác tầng 1)
  - `06` (paradox): [Insight #06 · paradox] Nguyên tắc 80/20 trong phối hợp Người - Máy: Người giữ 20% đầu (Hạt giống + Nháp ý) và 20% cuối (Duyệt + Chốt), máy chạy 60% giữa [N06]. (Góc khai thác tầng 1)
  - `07` (metaphor): [Insight #07 · metaphor] Bảng kiểm 8 lỗi văn dịch (so sánh hai vế, láy câu, thả số liệu, ẩn dụ kéo dài...) là công cụ thực hành dễ áp dụng nhất tại lớp [N07]. (Góc khai thác tầng 1)
  - `08` (provocation): [Insight #08 · provocation] Mỗi buổi học 120 phút phải kết thúc bằng 1 sản phẩm thật của chính học viên đã vượt qua cổng chấm tự động [N08]. (Góc khai thác tầng 1)
  - `09` (fact): [Insight #09 · fact] Không dùng thuật ngữ tiếng Anh chuyên sâu khi chưa giải nghĩa bằng hình ảnh đời thường ngay lần đầu xuất hiện [N09]. (Góc khai thác tầng 1)
  - `10` (paradox): [Insight #10 · paradox] Persona độc giả ảo giúp học viên tự soi bài của mình dưới góc nhìn của sếp khó tính trước khi bấm nút gửi [N10]. (Góc khai thác tầng 1)

## 2. Ba phương án Outline A / B / C (`LAB025` Bước 6)

### Phương án A — Bài giảng Lý thuyết Nền tảng về AI & Prompt Engineering
- **Góc nhìn (`variant_angle`)**: Trang bị kiến thức nền tảng từ lịch sử LLM, cơ chế Attention đến các khuôn mẫu câu lệnh chuẩn
- **Giọng điệu (`variant_tone`)**: Giảng đường đại học, tuần tự từ khái niệm đến ví dụ
- **Cấu trúc (`variant_structure`)**: Khái niệm AI -> Cơ chế hoạt động -> 5 công thức Prompt -> Bài tập cuối giờ
- **Tập Insights chọn (10 ý)**: `[1, 2, 4, 11, 13, 15, 17, 21, 25, 29]`
- **Dàn ý chi tiết**:
  - Phần 1 (30 phút): Tổng quan về Trí tuệ nhân tạo tạo sinh và các mô hình lớn
  - Phần 2 (30 phút): Giải thích Token, Context Window, Temperature và Hallucination
  - Phần 3 (30 phút): 5 công thức viết câu lệnh phổ biến trên thế giới
  - Phần 4 (30 phút): Hỏi đáp và làm bài trắc nghiệm 10 câu
- **Giai thoại / Tình huống gắn kèm**:
  - Ví dụ minh hoạ câu lệnh tiếng Anh dịch sang tiếng Việt.

### Phương án B — Buổi học Thực chiến Gagné 5 Bước: Từ 'Hạt giống Ý tưởng' đến 'Bản nháp Sạch Mùi AI' ngay tại lớp
- **Góc nhìn (`variant_angle`)**: Học viên mang đúng 1 việc đang nợ sếp vào lớp; đi qua 5 sự kiện Gagné rút gọn, tự tay dựng Persona Neo, viết nháp gạch đầu dòng và dùng bảng kiểm 8 lỗi Vân Anh để khử sạch mùi văn máy
- **Giọng điệu (`variant_tone`)**: Giảng viên Linh: Thực chiến, sắc sảo, không dùng thuật ngữ Tây khi có từ Việt tương đương, cầm tay chỉ việc trên bài thật
- **Cấu trúc (`variant_structure`)**: Sự kiện 1 (Gây chú ý bằng ca lỗi thật) -> Sự kiện 2 (Mục tiêu đầu ra tại lớp) -> Sự kiện 3 (Quy trình 80/20 & Persona Neo) -> Sự kiện 4 (Thực hành làm mượt + Bảng kiểm 8 lỗi văn dịch) -> Sự kiện 5 (Đo kiểm chéo & Đóng gói)
- **Tập Insights chọn (12 ý)**: `[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 16]`
- **Dàn ý chi tiết**:
  - Slide 01-03 [Gagné 1 - Chạm nỗi đau]: Giải phẫu trực tiếp 1 đoạn văn AI 300 chữ vừa bị sếp trả về lúc 9h sáng — Vì sao đọc 3 câu đã biết máy viết?
  - Slide 04-05 [Gagné 2 - Cam kết đầu ra]: Sau 90 phút hôm nay, mỗi học viên cầm về 1 sản phẩm thật của phòng mình và 1 Bảng kiểm 1 trang tiếng Việt
  - Slide 06-09 [Gagné 3 - Nguyên lý Cốt lõi]: Luật 80/20 (Người giữ 20% Hạt giống + 20% Chốt cuối) & Cách dựng 3 Độc giả ảo hay cãi để thử dàn ý trước khi viết
  - Slide 10-14 [Gagné 4 - Cầm tay chỉ việc]: Thực hành tách bước trên bài thật của học viên + Quét sạch 8 lỗi văn dịch (so sánh 2 vế, láy câu, thả số liệu, chủ thể mơ hồ)
  - Slide 15-18 [Gagné 5 - Nghiệm thu tại lớp & Quiz]: Chấm chéo sản phẩm theo 3 tiêu chí Đạt/Sửa + 5 câu hỏi tình huống phân loại nhanh
- **Giai thoại / Tình huống gắn kèm**:
  - Đối chiếu trực quan trên màn chiếu: Cột trái là câu máy viết ('Không còn là công cụ hỗ trợ đơn thuần mà đã trở thành...'), cột phải là câu người thật viết gọn, có chủ thể rõ ràng.

### Phương án C — Workshop biểu diễn 15 công cụ AI tự động hoá đa phương tiện
- **Góc nhìn (`variant_angle`)**: Trình diễn liên tục các công cụ tạo chữ, tạo ảnh, tạo slide, tạo video trong 1 buổi
- **Giọng điệu (`variant_tone`)**: Sôi nổi, trình diễn công nghệ (Demo-heavy)
- **Cấu trúc (`variant_structure`)**: Công cụ viết -> Công cụ vẽ ảnh -> Công cụ làm slide -> Công cụ làm video
- **Tập Insights chọn (10 ý)**: `[2, 5, 8, 14, 18, 20, 22, 24, 26, 30]`
- **Dàn ý chi tiết**:
  - Phần 1: Demo 4 công cụ viết văn bản nhanh
  - Phần 2: Demo 4 công cụ vẽ ảnh minh hoạ
  - Phần 3: Demo 4 công cụ tạo slide tự động
  - Phần 4: Demo 3 công cụ ghép giọng nói và video
- **Giai thoại / Tình huống gắn kèm**:
  - Biểu diễn tạo nhanh 1 video ngắn trong 5 phút tại lớp.

## 3. [LÀM MỚI] Kết quả thử 3 Outline trên 3 Persona Neo (`P1`, `P2`, `P3`)

| Phương án | TB Khớp nỗi đau (/10) | TB Nguy cơ bỏ đọc (/10, thấp=tốt) | Điểm Persona Tổng hợp (/10) | Xếp hạng từ P1, P2, P3 |
|---|---:|---:|---:|---|
| **A** (Phương án A — Bài giảng Lý thuyết Nền tảng về AI & Prompt Engineering) | **6.23** | 5.83 | **4.19** | P1: #3, P2: #3, P3: #2 |
| **B** (Phương án B — Buổi học Thực chiến Gagné 5 Bước: Từ 'Hạt giống Ý tưởng' đến 'Bản nháp Sạch Mùi AI' ngay tại lớp) | **9.17** | 1.57 | **8.62** | P1: #1, P2: #1, P3: #1 |
| **C** (Phương án C — Workshop biểu diễn 15 công cụ AI tự động hoá đa phương tiện) | **5.8** | 6.17 | **3.64** | P1: #2, P2: #2, P3: #3 |

### Phản ứng chi tiết với Phương án A — Bài giảng Lý thuyết Nền tảng về AI & Prompt Engineering
- **P1 (Chuyên viên cao cấp / Quản lý cấp trung đi học để giải quyết việc thật tại công ty)** — Khớp nỗi đau: `5.5/10` · Nguy cơ bỏ đọc: `6.8/10`:
  - *Chỗ dễ chán/bỏ đọc*: Phần 1 (30 phút): Tổng quan về Trí tuệ nhân tạo tạo sinh và các mô hình lớn
  - *Câu phản biện ngay từ dàn ý*: "[P1 cãi phương án A] 'Thầy làm ví dụ trên đề bài mẫu thì mượt thế, chứ đụng vào hồ sơ khách hàng lắt léo của em là AI nó viết ngô nghê ngay.' — Mở đầu bằng nguyên lý vĩ mô/học thuật thế này là tôi lướt qua ngay vì không giải quyết việc đang cháy."
  - *Kỳ vọng mang về*: Biết thêm khái niệm tổng quan nhưng chưa thấy cách áp vào việc ngày mai.
- **P2 (Nhân sự lớn tuổi / Trái ngành công nghệ (Sợ thao tác phức tạp, dễ ngợp thuật ngữ tiếng Anh))** — Khớp nỗi đau: `5.8/10` · Nguy cơ bỏ đọc: `6.5/10`:
  - *Chỗ dễ chán/bỏ đọc*: Phần 1 (30 phút): Tổng quan về Trí tuệ nhân tạo tạo sinh và các mô hình lớn
  - *Câu phản biện ngay từ dàn ý*: "[P2 cãi phương án A] 'Nhiều bước thế này nhớ làm sao hết, có bảng kiểm (checklist) 1 trang tiếng Việt dễ hiểu để nhìn vào làm theo không?' — Mở đầu bằng nguyên lý vĩ mô/học thuật thế này là tôi lướt qua ngay vì không giải quyết việc đang cháy."
  - *Kỳ vọng mang về*: Biết thêm khái niệm tổng quan nhưng chưa thấy cách áp vào việc ngày mai.
- **P3 (Nhân sự trẻ rành công cụ (Đã dùng ChatGPT/Claude hàng ngày nhưng hay nộp bài bị sếp trả về))** — Khớp nỗi đau: `7.4/10` · Nguy cơ bỏ đọc: `4.2/10`:
  - *Chỗ dễ chán/bỏ đọc*: Phần 1 (30 phút): Tổng quan về Trí tuệ nhân tạo tạo sinh và các mô hình lớn
  - *Câu phản biện ngay từ dàn ý*: "[P3 cãi phương án A] 'Em dùng đủ công thức Role-Task-Context rồi mà sao bài ra vẫn bị chê là sáo rỗng?' — Mở đầu bằng nguyên lý vĩ mô/học thuật thế này là tôi lướt qua ngay vì không giải quyết việc đang cháy."
  - *Kỳ vọng mang về*: Biết thêm khái niệm tổng quan nhưng chưa thấy cách áp vào việc ngày mai.

### Phản ứng chi tiết với Phương án B — Buổi học Thực chiến Gagné 5 Bước: Từ 'Hạt giống Ý tưởng' đến 'Bản nháp Sạch Mùi AI' ngay tại lớp
- **P1 (Chuyên viên cao cấp / Quản lý cấp trung đi học để giải quyết việc thật tại công ty)** — Khớp nỗi đau: `9.2/10` · Nguy cơ bỏ đọc: `1.5/10`:
  - *Chỗ dễ chán/bỏ đọc*: Không có mục sáo rỗng; cần lưu ý giữ nhịp gọn ở phần chuyển từ chẩn đoán sang giải pháp.
  - *Câu phản biện ngay từ dàn ý*: "[P1 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung."
  - *Kỳ vọng mang về*: Cầm tay chỉ việc 1 khung quy trình 5-9 bước áp dụng ngay vào bài toán thật của mình ngay trong giờ thực hành.
- **P2 (Nhân sự lớn tuổi / Trái ngành công nghệ (Sợ thao tác phức tạp, dễ ngợp thuật ngữ tiếng Anh))** — Khớp nỗi đau: `9.4/10` · Nguy cơ bỏ đọc: `1.4/10`:
  - *Chỗ dễ chán/bỏ đọc*: Không có mục sáo rỗng; cần lưu ý giữ nhịp gọn ở phần chuyển từ chẩn đoán sang giải pháp.
  - *Câu phản biện ngay từ dàn ý*: "[P2 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung."
  - *Kỳ vọng mang về*: Checklist tiếng Việt ngắn gọn, dễ nhớ và 3 dấu hiệu nhận biết ngay văn bản do AI viết ẩu để tự sửa.
- **P3 (Nhân sự trẻ rành công cụ (Đã dùng ChatGPT/Claude hàng ngày nhưng hay nộp bài bị sếp trả về))** — Khớp nỗi đau: `8.9/10` · Nguy cơ bỏ đọc: `1.8/10`:
  - *Chỗ dễ chán/bỏ đọc*: Không có mục sáo rỗng; cần lưu ý giữ nhịp gọn ở phần chuyển từ chẩn đoán sang giải pháp.
  - *Câu phản biện ngay từ dàn ý*: "[P3 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung."
  - *Kỳ vọng mang về*: Kỹ thuật tách ngữ cảnh phản biện (Persona Neo + 6 lượt biên tập) để khử sạch mùi văn dịch và nâng chất lượng bài lên mức chuyên gia.

### Phản ứng chi tiết với Phương án C — Workshop biểu diễn 15 công cụ AI tự động hoá đa phương tiện
- **P1 (Chuyên viên cao cấp / Quản lý cấp trung đi học để giải quyết việc thật tại công ty)** — Khớp nỗi đau: `5.8/10` · Nguy cơ bỏ đọc: `6.2/10`:
  - *Chỗ dễ chán/bỏ đọc*: Phần 2: Demo 4 công cụ vẽ ảnh minh hoạ
  - *Câu phản biện ngay từ dàn ý*: "[P1 cãi phương án C] Liệt kê mẹo/danh mục kiểu này trên mạng có hàng trăm bài, đọc xong vẫn không giải quyết được xung đột quy trình trong công ty."
  - *Kỳ vọng mang về*: Có vài gạch đầu dòng tham khảo nhanh nhưng thiếu chiều sâu hệ thống.
- **P2 (Nhân sự lớn tuổi / Trái ngành công nghệ (Sợ thao tác phức tạp, dễ ngợp thuật ngữ tiếng Anh))** — Khớp nỗi đau: `6.7/10` · Nguy cơ bỏ đọc: `4.8/10`:
  - *Chỗ dễ chán/bỏ đọc*: Phần 2: Demo 4 công cụ vẽ ảnh minh hoạ
  - *Câu phản biện ngay từ dàn ý*: "[P2 cãi phương án C] Liệt kê mẹo/danh mục kiểu này trên mạng có hàng trăm bài, đọc xong vẫn không giải quyết được xung đột quy trình trong công ty."
  - *Kỳ vọng mang về*: Có vài gạch đầu dòng tham khảo nhanh nhưng thiếu chiều sâu hệ thống.
- **P3 (Nhân sự trẻ rành công cụ (Đã dùng ChatGPT/Claude hàng ngày nhưng hay nộp bài bị sếp trả về))** — Khớp nỗi đau: `4.9/10` · Nguy cơ bỏ đọc: `7.5/10`:
  - *Chỗ dễ chán/bỏ đọc*: Phần 2: Demo 4 công cụ vẽ ảnh minh hoạ
  - *Câu phản biện ngay từ dàn ý*: "[P3 cãi phương án C] Liệt kê mẹo/danh mục kiểu này trên mạng có hàng trăm bài, đọc xong vẫn không giải quyết được xung đột quy trình trong công ty."
  - *Kỳ vọng mang về*: Có vài gạch đầu dòng tham khảo nhanh nhưng thiếu chiều sâu hệ thống.

