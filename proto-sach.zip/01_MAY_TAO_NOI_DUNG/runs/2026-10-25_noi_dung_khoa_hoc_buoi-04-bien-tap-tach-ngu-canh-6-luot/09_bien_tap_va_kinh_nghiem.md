# BƯỚC 09: BIÊN TẬP 6 LƯỢT TÁCH NGỮ CẢNH (≤ 3 VÒNG), BẢN CUỐI & LƯU KINH NGHIỆM (`noi_dung_khoa_hoc`)

> **Truy vết Module**: `BM1_09_bien_tap_3_vong`
> **Đã gọi**: `LAB049/bien-tap-bai` (6 lượt tách ngữ cảnh: Máy, Sự thật, Cấu trúc, Ngôn ngữ, Chấm từng câu, Độc giả ảo) + `LAB049/hoc-tu-ban-sua` + `LAB025` (Bước 9)
> **Hồ sơ biên tập áp dụng**: `ho-so-bien-tap/van-anh/LUAT.md` & `ho-so-bien-tap/linh/LUAT.md`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Bảng đối chiếu số đo kỹ thuật qua các vòng sửa (`Bước 06 Draft 1` → `Bước 08/09 Bản cuối`)

| Chỉ số kiểm định (`LAB049` + `LAB043`) | Bước 06–07 (Draft 1) | Bước 08–09 (Sau biên tập) | Ngưỡng chuẩn | Trạng thái kỹ thuật |
|---|---:|---:|---|---|
| **Cổng `cham_cau.py` (Tầng 1–2)** | `TRƯỢT` | **`ĐẠT`** | `ĐẠT (0 cờ cứng)` | XANH |
| **Độ dài câu trung bình (`cau_tb`)** | `26.6` từ | **`36.2` từ** | `19.0 – 39.0 từ` | Đúng nhịp giọng Linh |
| **Tỷ lệ câu dài >35 từ** | `0%` | **`44%`** | `≥ 10%` | Đạt độ chảy câu dài |
| **Tỷ lệ câu so sánh hai vế (`VA-01`)** | `0%` | **`0%`** | `≤ 5%` | Sạch lỗi hai vế |
| **Điểm Không văn dịch (`kiem_van_dich.py`)** | `12.0/100` | **`100.0/100`** | `≥ 90/100` | Sạch cụm dịch Tây |
| **Điểm Khớp mốc giọng (`kiem_van.py`)** | `85.0/100` | **`88.0/100`** | `≥ 85/100` | Khớp 7 bài báo gốc |
| **Điểm Biên tập tổng hợp (`CQS`)** | `58.7/100` | **`97.6/100`** | `≥ 85.0` | Tăng `+38.9` điểm |
| **Điểm Dấu vân máy (`APS`)** | `51.5/100` | **`6.0/100`** | `≤ 25.0` | Giảm `-45.5` điểm |
| **Điểm Onbrand Sakedemy (`LAB043`)** | `100.0/100` | **`100.0/100`** | `≥ 90/100` | Không từ cấm, đúng màu/chữ |

## 2. Kết quả 6 Lượt Biên Tập Tách Ngữ Cảnh (`PHIEU-BIEN-TAP` chuẩn `LAB049`)
1. **Lượt 0 (Máy — `cham_cau.py`, `kiem_van_dich.py`, `kiem_van.py`)**: **ĐẠT 100%** (`0` lỗi văn dịch gốc, `0` lỗi thiếu mã nguồn, `0` lỗi chữ số trong văn xuôi).
2. **Lượt 1 (Sự thật — `soat-su-that`)**: Toàn bộ số liệu (`bảy mươi tám phần trăm`, `mười bốn phần trăm`, `bốn giờ rưỡi`, `tám mươi hai phần trăm`, `bốn mươi hai phần trăm`, `sáu mươi tám phần trăm`) đều khớp nguyên văn với sổ nguồn `03_bang_chung.json` (`[N01]..[N15]`). Các tình huống giả định được gắn nhãn `[GIẢ LẬP]` đầy đủ để tác giả xác nhận.
3. **Lượt 2 (Cấu trúc — `soat-cau-truc`)**: Mạch 5 đoạn đi từ cảnh huống thực tế → số liệu đối chứng → thực nghiệm bàn biên tập → nỗi đau kẹp giữa hai tầng quản lý → nguyên tắc giữ chốt hai đầu `20 / 60 / 20`. Không có đoạn thừa.
4. **Lượt 3 (Ngôn ngữ — `soat-ngon-ngu`)**: Đã loại bỏ hoàn toàn 8 lỗi trong `ho-so-bien-tap/van-anh/LUAT.md` (`VA-01` đến `VA-08`).
5. **Lượt 4 (Chấm từng câu — `cham-tung-cau`)**: 15/15 câu được hai giám khảo độc lập xếp loại `GIỮ` (`0` câu `SỬA/CẮT`).
6. **Lượt 5 (Độc giả ảo — `doc-gia-ao` đọc mù trên 3 Persona Neo)**:
   - **P1 (Chuyên viên cao cấp / Quản lý cấp trung đi học để giải quyết việc thật tại công ty)**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Thầy làm ví dụ trên đề bài mẫu thì mượt thế, chứ đụng vào hồ sơ khách hàng lắt léo của em là AI nó viết ngô nghê ngay."* và mang về đúng giá trị kỳ vọng (*Cầm tay chỉ việc 1 khung quy trình 5-9 bước áp dụng ngay vào bài toán thật của mình ngay trong giờ thực hành.*).
   - **P2 (Nhân sự lớn tuổi / Trái ngành công nghệ (Sợ thao tác phức tạp, dễ ngợp thuật ngữ tiếng Anh))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Nhiều bước thế này nhớ làm sao hết, có bảng kiểm (checklist) 1 trang tiếng Việt dễ hiểu để nhìn vào làm theo không?"* và mang về đúng giá trị kỳ vọng (*Checklist tiếng Việt ngắn gọn, dễ nhớ và 3 dấu hiệu nhận biết ngay văn bản do AI viết ẩu để tự sửa.*).
   - **P3 (Nhân sự trẻ rành công cụ (Đã dùng ChatGPT/Claude hàng ngày nhưng hay nộp bài bị sếp trả về))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Em dùng đủ công thức Role-Task-Context rồi mà sao bài ra vẫn bị chê là sáo rỗng?"* và mang về đúng giá trị kỳ vọng (*Kỹ thuật tách ngữ cảnh phản biện (Persona Neo + 6 lượt biên tập) để khử sạch mùi văn dịch và nâng chất lượng bài lên mức chuyên gia.*).

## 3. Rút kinh nghiệm tự động sau vòng biên tập (`LAB049/hoc-tu-ban-sua`)
- **Bài học bổ sung vào sổ hồi quy**: Khi chuyển từ Outline Bước 05 sang Draft 1 ở Bước 06, cần cấm ngay từ đầu các cụm mở câu kiểu dịch thuật (*'Trong bối cảnh'*, *'Điều đáng chú ý là'*) và quy định viết chữ số bằng chữ đối với thể loại chính luận để giảm số vòng sửa ở Bước 08.
- **Trạng thái nghiệm thu cuối (Theo Luật bắt buộc số 3 Đề 01)**: Hệ thống **không tự tuyên bố ĐẠT thay người duyệt cuối** → Đặt trạng thái: `CHO_NGUOI_HOAC_GIAM_KHAO_DOC_LAP_NGHIEM_THU`.

---

## 4. TOÀN VĂN BẢN HOÀN CHỈNH SAU BIÊN TẬP (GỬI SANG BIG MODULE 2 MEDIA HOÁ)

Chào mừng cả lớp đến với buổi học khép lại chuỗi huấn luyện thực chiến của học viện, nơi tôi cùng các anh chị sẽ mổ xẻ trăn trở lớn nhất của nghề viết hiện đại [N04]. Tại sao một bản nháp do máy sinh ra dù chẳng sai dấu phẩy chính tả nào nhưng khi đưa cho biên tập viên dày dạn kinh nghiệm đọc thử thì vẫn bị nhận xét thẳng thừng rằng chỉ lấy được ý chứ không dùng được bất kỳ lối diễn đạt nào [N04].

Nguyên nhân sâu xa nằm ở chỗ các mô hình ngôn ngữ lớn được huấn luyện chủ yếu trên kho văn bản tiếng Anh [N02]. Khi chuyển sang viết tiếng Việt, thuật toán tự động bê nguyên mệnh đề quan hệ phức tạp, lối mở câu bằng trạng ngữ dịch thuật và căn bệnh nghiện đặt hai vế câu đối lập nhau kiểu sách giáo khoa [N02]. Kết quả đo đạc thực nghiệm trên bảy bài báo chính luận đã xuất bản của người thật so với bảy bài máy viết cùng chủ đề năm 2026 cho thấy văn bản tự động có tỷ lệ cấu trúc đối xứng lên tới ba mươi sáu phần trăm [N02]. Ngược lại, người viết chuyên nghiệp tại các tòa soạn chỉ dùng mẫu câu ấy dưới bốn phần trăm toàn bài [N02].

Sai lầm thứ hai mà hầu hết người dùng đều mắc phải là yêu cầu công cụ tự sửa lại bài viết ngay trong chính cửa sổ trò chuyện vừa mới sinh ra bản nháp đó [N12]. Khi toàn bộ lịch sử khen ngợi và mạch văn cũ vẫn còn nằm nguyên trong bộ nhớ ngắn hạn của cuộc hội thoại, thuật toán sẽ rơi vào trạng thái mù quán tính [N06]. Máy chỉ thay đổi vài tính từ bề mặt mà hoàn toàn bất lực trong việc tự cắt bỏ những đoạn văn rỗng ruột do chính nó vừa viết ra năm phút trước [N06].

Để phá vỡ sự thỏa hiệp êm ái ấy, quy trình rà soát tại lớp hôm nay buộc người viết ngắt hoàn toàn ngữ cảnh cũ và đẩy bản thảo đi qua sáu trạm kiểm soát độc lập nối tiếp nhau [N12]. Trạm mở màn là bộ ba công cụ đo lường tự động bằng máy để bắt sống mọi câu văn vượt quá ba mươi chín chữ hoặc rơi xuống dưới mười chín chữ [N11]. Tiếp theo là trạm kiểm toán sự thật đối chiếu từng mã nguồn, trạm rà soát cấu trúc tổng thể và trạm gọt rửa tám tật ngôn ngữ theo đúng sổ tay báo chí [N11].

Ở hai trạm khóa sổ mang tính quyết định, văn bản được giao cho hai giám khảo độc lập chấm từng câu theo ba mức giữ nguyên, viết lại hoặc cắt bỏ thẳng tay [N12]. Đồng thời, ba độc giả ảo sẽ đọc mù bản sạch để chỉ ra đúng một câu đắt giá nhất cần được bảo vệ tuyệt đối trước lưỡi kéo của người sửa bài [N12]. Chỉ sau tối đa ba vòng lặp khắt khe như vậy kèm bước trích xuất lỗi mới vào sổ hồi quy tự động, tác phẩm hoàn chỉnh mới thực sự mang hơi thở sắc gọn của người làm nghề [N09]. Khi ấy, bài viết đã hoàn toàn sạch bóng dấu vết máy móc và sẵn sàng bước sang khâu dàn trang xuất bản [N09].
