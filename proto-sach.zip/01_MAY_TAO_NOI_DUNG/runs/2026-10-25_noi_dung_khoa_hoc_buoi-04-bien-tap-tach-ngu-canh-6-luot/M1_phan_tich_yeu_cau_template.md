# BƯỚC M1: PHÂN TÍCH YÊU CẦU MEDIA HOÁ, THAM CHIẾU AGY & NẠP NHẬN DIỆN TẠM (`noi_dung_khoa_hoc`)

> **Truy vết Big Module 2**: `BM2_M1_chu_trinh_template` (Bước 1/5) + `BM2_M2_media_hoa`
> **Đã gọi**: `AGY image-generator + AGY search_web + LAB027 (linhx-deck: dung-deck, hinh-anh) + LAB017 (linhx-course: lesson-slides) + LAB032 (anh-sang-slide) + LAB043 (thiet_ke.py, onbrand.py) + LAB028 (hinh.py) + LAB066 + LAB042`
> **Nhận diện tạm**: Sakedemy (`vendor/LAB043/brands/sakedemy/brand.json`, `LUAT-ONBRAND.md`)
> **Trạng thái mẫu**: chạy không mẫu

## 1. Yêu cầu đầu ra Media hoá của loại `noi_dung_khoa_hoc`
- **Đề tài**: Nội dung khoá học — Buổi 04 (90 phút): Thực hành Biên tập Tách ngữ cảnh Sáu lượt và Khử sạch Mùi Văn dịch Tây
- **Hạng mục sản xuất**: Ảnh lớp học thảo luận thực tế AGY (`image-generator`) + Bộ Slide Bài Giảng 16:9 (`slides.md` Slidev LAB017 + `10-deck.json` + HTML/PDF 16:9) + Slide/Story/Banner PNG (`thiet_ke.py`) + 2 Biểu đồ SVG (`LAB028/hinh.py`)
- **Đối tượng sử dụng**: Đồng bộ trực tiếp với 3 Persona Neo (`P1`, `P2`, `P3`) đã khóa ở Bước 02 và bản thảo cuối ở Bước 09.

## 2. Tham chiếu Thị giác & Media thu thập qua AGY (`search_web`)
- **[V1] Sakedemy Brand Guideline v2 (LAB043) — Khuôn Slide 16:9 (slide-169.html, 1920x1080)**: Nền Xanh Rêu Đậm #02403B, logo ngang âm bản góc trên trái, tiêu đề trắng, bốn bước đánh số trong ô hình lá #6EB264, ảnh lớp học thật trong khung hình lá (border-radius 260px 0 260px 0) bên phải, hoạ tiết gân lá mờ 14% ở góc dưới phải.
- **[V2] LAB066 3-Round Character Anchor (Luna Mai / Giảng viên Sakedemy)**: Khóa đồng nhất gương mặt qua 3 góc (nhìn thẳng, nghiêng 3/4, nghiêng hẳn profile), chấm bằng 4 Persona + Giám khảo lỗi kỹ thuật.

## 3. Thông số Nhận diện tạm Sakedemy đã nạp (`LAB043`)
- **Tên thương hiệu trong văn bản**: `Sakedemy` (tiêu đề trang trọng: `Sakédemy`, tuyệt đối không viết tắt `Sake`).
- **Tagline chuẩn**: *"Khi sáng tạo gặp công nghệ"*
- **Bảng màu bắt buộc**:
  - Màu chính: Xanh Lá Sakédemy (`#6EB264`), Xanh Rêu Đậm (`#02403B`), Xám Chữ (`#414141`).
  - Màu phụ & nền: Trắng (`#FFFFFF`), Trắng Giấy (`#FDFDFD`), Lá Nhạt (`#E9F6D3`), Xanh Lá Sâu (`#118056` cho chữ xanh nhỏ trên nền trắng).
  - Điểm nhấn: Gradient Lá Non sang Ngọc (`linear-gradient(210deg, #A3D34F, #26CABE)` — tối đa 5% diện tích).
- **Kiểu chữ**: `Be Vietnam Pro` (`Light`, `Regular`, `Bold`), tỷ lệ cỡ chữ `3.2 : 1.6 : 1 : 0.8`.
- **Ngôn ngữ hình khối**: Khung hình lá (vuông/chữ nhật bo hai góc chéo trên-trái và dưới-phải), hoạ tiết gân lá 45° dưới 20% độ đậm ở góc.
