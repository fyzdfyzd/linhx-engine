# BƯỚC 05: TỰ CHẤM & CHỐT HƯỚNG OUTLINE (`bai_viet`)

> **Truy vết Module**: `BM1_05_cham_chon_huong` (**Làm mới hoàn toàn** theo Đề 01 Bản 3)
> **Cờ duyệt (`duyet_outline`)**: `nguoi` → **Trạng thái**: `DA_CHOT_THEO_NGUOI_CHON`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu (Gemini 2.5 Flash)

## 1. Bảng chấm điểm 3 phương án Outline (Thang 100)

| Hạng | Phương án | Persona (40đ) | Khớp `dat_khi` (30đ) | Bằng chứng (20đ) | Chống Slop (10đ) | **Tổng (/100)** | Kết luận |
|---|---|---:|---:|---:|---:|---:|---|
| 1 | **B** — Hướng B — Đi từ Tình huống Thực tế tại Doanh nghiệp, Đối chiếu Trước/Sau & Bảng kiểm Áp dụng Ngay | 38.0 | 29.0 | 19.0 | 9.0 | **95.0** | ★ **CHỐT**: Mở bài bằng câu chuyện tình huống thật kèm con số cụ thể rất tốt. Có bảng đối chiếu quy trình trước và sau rõ ràng. Khung hành động thực tế và bảng kiểm áp dụng ngay trong tuần được nhấn mạnh. Cách tiếp cận thực tế, gần gũi với người đọc. |
| 2 | **A** — Hướng A — Đi từ Số liệu Vĩ mô & Cảnh báo Hệ thống | 30.5 | 22.0 | 15.0 | 7.5 | **75.0** | Loại: Mở bài có số liệu nhưng chưa phải câu chuyện tình huống thật. Có bảng đối chiếu nhưng chưa rõ ràng về quy trình trước và sau. Khung hành động có nhưng chưa đủ chi tiết để áp dụng ngay. Hướng đi vĩ mô có thể hơi xa rời thực tế của một số người đọc. |
| 3 | **C** — Hướng C — Đi thẳng vào Cẩm nang Thao tác Nhanh & Mẫu biểu Thực hành | 33.0 | 20.0 | 14.0 | 8.0 | **75.0** | Loại: Mở bài chưa phải câu chuyện tình huống thật mà là lời kêu gọi hành động. Có khung hành động và mẫu biểu nhưng thiếu bảng đối chiếu quy trình trước và sau. Hướng đi quá tập trung vào 'cẩm nang nhanh' có thể thiếu chiều sâu chuyên môn cần thiết cho thể loại bài viết chuyên sâu. |

## 2. Quyết định chốt hướng: ★ Phương án B (95.0/100 điểm)
- **Tên phương án**: Hướng B — Đi từ Tình huống Thực tế tại Doanh nghiệp, Đối chiếu Trước/Sau & Bảng kiểm Áp dụng Ngay
- **Góc nhìn**: Tại một văn phòng ở TP.HCM, 30% giờ làm việc của đội ngũ bị hao hụt mỗi tuần chỉ để 'dọn dẹp' các báo cáo AI kém chất lượng, gây gián đoạn nghiêm trọng và làm chậm tiến độ dự án - một tình huống đòi hỏi quy trình kiểm soát chất lượng và khôi phục sự cố cấp bách.
- **Giọng điệu**:  Chuẩn giọng Bài viết chuyên sâu (Báo chí / Tạp chí kinh tế - công nghệ)
- **Khung triển khai gửi sang Bước 6**:
  - 1. Tình huống thực tế & chi phí ẩn: Khi báo cáo tuần trở thành 'cơn ác mộng' (Nguồn: Khảo sát thực địa Sakedemy)
  - 2. Phân tích nguyên nhân gốc rễ: Vượt qua 'bẫy' 10-20-70 của BCG trong quản lý chất lượng báo cáo
  - 3. Bảng đối chiếu quy trình: Từ hỗn loạn đến chuẩn hóa - Kiểm soát chất lượng báo cáo tuần
  - 4. Quy trình 3 bước triển khai thực chiến: Xây dựng cơ chế khôi phục tiến trình sau sự cố gián đoạn
  - 5. Bảng kiểm nghiệm thu & Hành động ngay trong tuần tới: Đảm bảo hiệu quả và bền vững

## 3. Ràng buộc bắt buộc giao cho Bước 6 (Rút từ phản ứng Persona & Luật chống Slop)
- [x] Phải giải quyết câu phản biện của P1 (Chủ doanh nghiệp SME / Giám đốc vận hành (Độc giả mục tiêu chính)): Đây chính là thứ tôi cần! Tình huống mở bài rất gần gũi, tôi thấy mình trong đó. Bảng đối chiếu trước/sau và quy trình 3 bước rất rõ ràng, dễ hình dung và áp dụng. Khung hành động ngay trong tuần là điểm cộng lớn, giúp tôi có thể triển khai ngay cho doanh nghiệp mình.
- [x] Phải giải quyết câu phản biện của P2 (Trưởng phòng chuyên môn / Team Lead (Người trực tiếp chịu trận giữa sếp và nhân viên)): Tuyệt vời! Tình huống mở bài rất sát với thực tế tôi đang gặp phải. Quy tắc 10-20-70 và bảng đối chiếu giúp tôi dễ dàng giải thích cho cấp trên và đội nhóm. Quy trình 3 bước và bảng kiểm nghiệm thu là công cụ đắc lực để tôi triển khai ngay lập tức, giảm bớt gánh nặng quản lý.
- [x] Phải giải quyết câu phản biện của P3 (Chuyên gia / Quản lý kỹ thuật hoài nghi (Độc giả khó tính hay bắt bẻ số liệu)): Mở bài bằng câu chuyện thực tế rất thuyết phục. Phân tích nguyên nhân gốc rễ dựa trên quy tắc BCG cho thấy sự hiểu biết sâu sắc. Bảng đối chiếu và quy trình 3 bước cung cấp một khung làm việc có cấu trúc, dễ dàng để đánh giá và cải thiện. Tôi đánh giá cao tính thực tiễn và khả năng đo lường của phương án này.
- [x] Tuyệt đối không dùng cấu trúc so sánh hai vế 'Không còn là X mà là Y' hoặc 'Càng X càng Y' (Luật Vân Anh VA-01, VA-02).
- [x] Mọi số liệu trích dẫn phải giữ nguyên mã nguồn [Nxx]/[BCxx], mọi tình huống giả định phải ghi rõ là tình huống mô phỏng.

> **[CỔNG DỪNG CHỜ NGƯỜI DUYỆT]**: Cờ `duyet_outline = nguoi`. Hệ thống dừng chờ anh Linh xác nhận Phương án khuyến nghị ★ trước khi sang Bước 6.
