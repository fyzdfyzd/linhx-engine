# BƯỚC 06: TRIỂN KHAI TỪNG PHẦN — BẢN NHÁP DRAFT 1 (`bai_viet`)

> **Truy vết Module**: `BM1_06_trien_khai_draft1`
> **Đã gọi**: `LAB049/viet-bai-giong-viet` (chế độ `chay_thu_khong_mau`) + `LAB025/critic-loop-writer`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

# Căn phòng họp lúc tám giờ tối và thứ thuế thời gian mang tên dọn rác cho máy

Trong bối cảnh làn sóng công nghệ đang lan rộng khắp nơi, nhiều doanh nghiệp tin rằng việc mua tài khoản phần mềm cho nhân viên sẽ giúp giải phóng sức lao động ngay lập tức [N01]. Một vị giám đốc vận hành mà tôi từng trò chuyện kể rằng anh vừa duyệt mua 30 tài khoản trợ lý ảo cho cả công ty với kỳ vọng cắt giảm một nửa thời gian làm báo cáo tuần [GIẢ LẬP]. Thế nhưng chỉ sau 2 tuần, chính người trưởng phòng lại phải ngồi ở văn phòng đến 9 giờ tối để đọc và viết lại từng trang kế hoạch do cấp dưới nộp lên [GIẢ LẬP].

Công nghệ mới không chỉ thay đổi cách nhân viên gõ phím mà còn làm lộ ra khoảng trống lớn trong cách người quản lý giao việc [N06]. Khi người sếp buông một câu gọn lỏn rằng cứ hỏi máy đi, nhân viên sẽ hiểu ngay rằng thứ sếp cần là một tệp văn bản đủ số trang chứ không phải một suy nghĩ thấu đáo [N04]. Nhân viên mở màn hình lên, gõ vào vài dòng yêu cầu sơ sài, rồi sao chép nguyên khối chữ bóng bẩy mà máy vừa nhả ra để gửi vào nhóm làm việc chung [N04].

Điều đáng chú ý là những bản nháp chạy tự động từ đầu đến cuối ấy nhìn thoáng qua rất tròn trịa nhưng đọc kỹ tới dòng thứ ba là thấy rỗng ruột [N04]. Biên tập viên đọc thử một bản máy viết tự động đã phải thốt lên rằng cả bài chỉ nhặt lại được vài ý gạch đầu dòng, còn toàn bộ câu chữ đều mang mùi văn dịch cứng nhắc không thể cứu vãn được [N04]. Máy rất giỏi nối câu trước với câu sau bằng những từ chuyển ý mượt mà, nhưng nó hoàn toàn không biết người đọc ngoài đời thực sẽ bỏ đọc ở dòng nào hay sẽ nổi tự ái ở chữ nào [N02].

Để thoát khỏi cái bẫy năng suất giả tạo này, quy trình làm việc đóng vai trò quan trọng trong việc phân định lại ranh giới giữa người và công cụ [N07]. Người làm chuyên môn bắt buộc phải giữ hai đầu của công việc: hai mươi phần trăm đầu tiên là hạt giống ý tưởng cùng dàn ý gạch đầu dòng rút từ va chạm thực tế, và hai mươi phần trăm cuối cùng là quyền gạch bỏ những câu chữ sáo rỗng sau khi đã qua sáu lượt biên tập tách biệt [N09].
