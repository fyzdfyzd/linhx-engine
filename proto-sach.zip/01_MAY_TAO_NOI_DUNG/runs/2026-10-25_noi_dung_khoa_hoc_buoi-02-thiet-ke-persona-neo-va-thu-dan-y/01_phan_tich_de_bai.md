# BƯỚC 01: ĐỌC KỸ, PHÂN TÍCH ĐỀ BÀI & MỤC TIÊU HỌC TẬP BLOOM (`noi_dung_khoa_hoc`)

> **Truy vết Module**: `BM1_01_phan_tich_de_bai`
> **Đã gọi**: `LAB017/linhx-course/skills/course-architect` (`00-brief.yaml`, `01-objectives`) + `LAB025/idea-seeder`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Hồ sơ buổi học (`00-brief.yaml` theo chuẩn `LAB017`)
- **Đề bài**: Nội dung khoá học — Buổi 02 (90 phút): Dựng Chân dung Độc giả ảo Hay cãi và Kỹ thuật Thử Dàn ý trước khi Đặt bút
- **Thương hiệu đào tạo**: Sakédemy (`Nhận diện tạm: Sakedemy (LAB043)` — *"Khi sáng tạo gặp công nghệ"*).
- **Thời lượng**: Chín mươi phút (một buổi học thực chiến doanh nghiệp, kết hợp giảng lý thuyết cốt lõi và cầm tay chỉ việc trên bài thật).
- **Giọng giảng viên**: Anh Linh (`giong-giang-vien-linh`: đi thẳng vào ca lỗi thực tế, câu nói ngắn gọn vừa nhịp thở, không dùng thuật ngữ tiếng Anh khi chưa giải nghĩa tiếng Việt).

## 2. Ba mục tiêu học tập đo lường được theo thang Bloom (`01-objectives/L01.yaml`)
1. **Mục tiêu 1 (Phân tích — Analyze)**: Chỉ ra được chính xác ít nhất năm trên tám dấu hiệu "văn dịch máy móc" (so sánh hai vế, láy câu, thả số liệu không gánh luận điểm, chủ thể mơ hồ) trên một văn bản thực tế tại công ty.
2. **Mục tiêu 2 (Áp dụng — Apply)**: Thực hành dựng ba hồ sơ Độc giả ảo hay cãi (`Persona Neo`) và chạy quy trình thử dàn ý trước khi đặt bút viết nháp.
3. **Mục tiêu 3 (Kiểm định & Sáng tạo — Evaluate & Create)**: Hoàn thành một bản thảo công việc thật ngay tại lớp theo nguyên tắc tám mươi / hai mươi (người giữ hạt giống và quyền duyệt cuối, máy tra cứu và làm mượt), vượt qua cổng kiểm tự động.
