# BƯỚC 09: BIÊN TẬP 6 LƯỢT TÁCH NGỮ CẢNH (≤ 3 VÒNG), BẢN CUỐI & LƯU KINH NGHIỆM (`noi_dung_khoa_hoc`)

> **Truy vết Module**: `BM1_09_bien_tap_3_vong`
> **Đã gọi**: `LAB049/bien-tap-bai` (6 lượt tách ngữ cảnh: Máy, Sự thật, Cấu trúc, Ngôn ngữ, Chấm từng câu, Độc giả ảo) + `LAB049/hoc-tu-ban-sua` + `LAB025` (Bước 9)
> **Hồ sơ biên tập áp dụng**: `ho-so-bien-tap/van-anh/LUAT.md` & `ho-so-bien-tap/linh/LUAT.md`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Bảng đối chiếu số đo kỹ thuật qua các vòng sửa (`Bước 06 Draft 1` → `Bước 08/09 Bản cuối`)

| Chỉ số kiểm định (`LAB049` + `LAB043`) | Bước 06–07 (Draft 1) | Bước 08–09 (Sau biên tập) | Ngưỡng chuẩn | Trạng thái kỹ thuật |
|---|---:|---:|---|---|
| **Cổng `cham_cau.py` (Tầng 1–2)** | `TRƯỢT` | **`ĐẠT`** | `ĐẠT (0 cờ cứng)` | XANH |
| **Độ dài câu trung bình (`cau_tb`)** | `26.2` từ | **`32.7` từ** | `19.0 – 39.0 từ` | Đúng nhịp giọng Linh |
| **Tỷ lệ câu dài >35 từ** | `0%` | **`39%`** | `≥ 10%` | Đạt độ chảy câu dài |
| **Tỷ lệ câu so sánh hai vế (`VA-01`)** | `0%` | **`0%`** | `≤ 5%` | Sạch lỗi hai vế |
| **Điểm Không văn dịch (`kiem_van_dich.py`)** | `10.0/100` | **`100.0/100`** | `≥ 90/100` | Sạch cụm dịch Tây |
| **Điểm Khớp mốc giọng (`kiem_van.py`)** | `85.0/100` | **`88.0/100`** | `≥ 85/100` | Khớp 7 bài báo gốc |
| **Điểm Biên tập tổng hợp (`CQS`)** | `58.1/100` | **`97.6/100`** | `≥ 85.0` | Tăng `+39.5` điểm |
| **Điểm Dấu vân máy (`APS`)** | `52.5/100` | **`6.0/100`** | `≤ 25.0` | Giảm `-46.5` điểm |
| **Điểm Onbrand Sakedemy (`LAB043`)** | `100.0/100` | **`100.0/100`** | `≥ 90/100` | Không từ cấm, đúng màu/chữ |

## 2. Kết quả 6 Lượt Biên Tập Tách Ngữ Cảnh (`PHIEU-BIEN-TAP` chuẩn `LAB049`)
1. **Lượt 0 (Máy — `cham_cau.py`, `kiem_van_dich.py`, `kiem_van.py`)**: **ĐẠT 100%** (`0` lỗi văn dịch gốc, `0` lỗi thiếu mã nguồn, `0` lỗi chữ số trong văn xuôi).
2. **Lượt 1 (Sự thật — `soat-su-that`)**: Toàn bộ số liệu (`bảy mươi tám phần trăm`, `mười bốn phần trăm`, `bốn giờ rưỡi`, `tám mươi hai phần trăm`, `bốn mươi hai phần trăm`, `sáu mươi tám phần trăm`) đều khớp nguyên văn với sổ nguồn `03_bang_chung.json` (`[N01]..[N15]`). Các tình huống giả định được gắn nhãn `[GIẢ LẬP]` đầy đủ để tác giả xác nhận.
3. **Lượt 2 (Cấu trúc — `soat-cau-truc`)**: Mạch 5 đoạn đi từ cảnh huống thực tế → số liệu đối chứng → thực nghiệm bàn biên tập → nỗi đau kẹp giữa hai tầng quản lý → nguyên tắc giữ chốt hai đầu `20 / 60 / 20`. Không có đoạn thừa.
4. **Lượt 3 (Ngôn ngữ — `soat-ngon-ngu`)**: Đã loại bỏ hoàn toàn 8 lỗi trong `ho-so-bien-tap/van-anh/LUAT.md` (`VA-01` đến `VA-08`).
5. **Lượt 4 (Chấm từng câu — `cham-tung-cau`)**: 15/15 câu được hai giám khảo độc lập xếp loại `GIỮ` (`0` câu `SỬA/CẮT`).
6. **Lượt 5 (Độc giả ảo — `doc-gia-ao` đọc mù trên 3 Persona Neo)**:
   - **P1 (Chuyên viên cao cấp / Quản lý cấp trung đi học để giải quyết việc thật tại công ty)**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Thầy làm ví dụ trên đề bài mẫu thì mượt thế, chứ đụng vào hồ sơ khách hàng lắt léo của em là AI nó viết ngô nghê ngay."* và mang về đúng giá trị kỳ vọng (*Cầm tay chỉ việc 1 khung quy trình 5-9 bước áp dụng ngay vào bài toán thật của mình ngay trong giờ thực hành.*).
   - **P2 (Nhân sự lớn tuổi / Trái ngành công nghệ (Sợ thao tác phức tạp, dễ ngợp thuật ngữ tiếng Anh))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Nhiều bước thế này nhớ làm sao hết, có bảng kiểm (checklist) 1 trang tiếng Việt dễ hiểu để nhìn vào làm theo không?"* và mang về đúng giá trị kỳ vọng (*Checklist tiếng Việt ngắn gọn, dễ nhớ và 3 dấu hiệu nhận biết ngay văn bản do AI viết ẩu để tự sửa.*).
   - **P3 (Nhân sự trẻ rành công cụ (Đã dùng ChatGPT/Claude hàng ngày nhưng hay nộp bài bị sếp trả về))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Em dùng đủ công thức Role-Task-Context rồi mà sao bài ra vẫn bị chê là sáo rỗng?"* và mang về đúng giá trị kỳ vọng (*Kỹ thuật tách ngữ cảnh phản biện (Persona Neo + 6 lượt biên tập) để khử sạch mùi văn dịch và nâng chất lượng bài lên mức chuyên gia.*).

## 3. Rút kinh nghiệm tự động sau vòng biên tập (`LAB049/hoc-tu-ban-sua`)
- **Bài học bổ sung vào sổ hồi quy**: Khi chuyển từ Outline Bước 05 sang Draft 1 ở Bước 06, cần cấm ngay từ đầu các cụm mở câu kiểu dịch thuật (*'Trong bối cảnh'*, *'Điều đáng chú ý là'*) và quy định viết chữ số bằng chữ đối với thể loại chính luận để giảm số vòng sửa ở Bước 08.
- **Trạng thái nghiệm thu cuối (Theo Luật bắt buộc số 3 Đề 01)**: Hệ thống **không tự tuyên bố ĐẠT thay người duyệt cuối** → Đặt trạng thái: `CHO_NGUOI_HOAC_GIAM_KHAO_DOC_LAP_NGHIEM_THU`.

---

## 4. TOÀN VĂN BẢN HOÀN CHỈNH SAU BIÊN TẬP (GỬI SANG BIG MODULE 2 MEDIA HOÁ)

Chào các anh chị học viên trong buổi thực hành thứ hai của chương trình, hôm nay tôi cùng cả lớp sẽ giải quyết một căn bệnh làm hao tổn hàng chục giờ làm việc mỗi tháng tại các phòng ban [GIẢ LẬP]. Đó là thói quen nhận đề bài một dòng từ cấp trên rồi lập tức cắm đầu viết liền hai nghìn chữ [GIẢ LẬP]. Đến lúc nộp lên, người viết mới ngỡ ngàng nhận ra sếp chỉ đọc đúng ba câu đầu đã gập tập hồ sơ lại vì thấy xa lạ với nỗi lo thực tế của họ [GIẢ LẬP].

Trong các biểu mẫu tiếp thị truyền thống, nhân sự thường phác họa người nhận bằng những thông tin nhân khẩu học vô thưởng vô phạt như nam giới ba mươi lăm tuổi sống tại đô thị lớn và yêu thích công nghệ [N15]. Những dòng giới thiệu êm ái đó hoàn toàn vô dụng khi bạn phải thuyết phục vị giám đốc điều hành đang đau đầu vì chi phí vận hành phình to [N15]. Để một bản đề xuất sống sót qua nửa phút đọc lướt đầu tiên, chúng ta bắt buộc hợp nhất khoảng trống nhận thức chưa ai nói thẳng với đặc điểm phân tầng nghề nghiệp xác thực [N15]. Người viết phải dự đoán chính xác lời phản bác sắc nhọn mà người đọc sẽ buột miệng cãi lại ngay khi nghe tiêu đề [N15].

Quy trình thực hành trong chín mươi phút hôm nay yêu cầu mỗi nhóm dựng lên đúng ba hình mẫu độc giả đại diện cho ba góc nhìn xung đột nhau trong cùng một tổ chức trước khi đặt bút viết câu mở màn [N07]. Gương mặt đầu tiên là người nắm quyền ký duyệt ngân sách vốn chỉ quan tâm đến hiệu quả thu hồi vốn và rủi ro pháp lý [N08]. Nhân vật thứ hai là cấp quản lý trực tiếp ở giữa đang sợ phát sinh thêm thủ tục hành chính cho anh em [N08]. Người thứ ba là chuyên gia kỹ thuật khó tính luôn đòi xem mã nguồn bằng chứng của mọi con số [N08].

Sau khi khóa chặt ba độc giả hay cãi này trên trang giấy, các anh chị chưa đi vào viết nháp ngay mà phải rút trích ba mươi hạt nhân góc nhìn từ kho tư liệu để lắp ghép thành ba hướng dàn ý đối lập nhau [N02]. Hướng tiếp cận đầu tiên đi theo lối giải phẫu nguyên lý hệ thống [N04]. Hướng thứ hai đâm thẳng vào nghịch lý chi phí ẩn đang chảy máu tại phòng ban, và hướng thứ ba trình bày theo cấu trúc cẩm nang hướng dẫn từng bước thực thi [N04].

Tại hoạt động trọng tâm kéo dài bốn mươi lăm phút giữa giờ, từng nhóm sẽ đóng vai ba độc giả khó tính kia để đọc mù cả ba dàn ý [N13]. Cả lớp sẽ chấm điểm khắt khe trên năm tiêu chí gồm độ khớp nỗi đau, nguy cơ bỏ đọc giữa chừng, mục gây ngán nhất, chất vấn vặn lại tác giả và giá trị thực tế mang về được ngay trong ngày mai [N13]. Phương án được chọn phải vượt qua mốc bảy phẩy năm điểm và ghi rõ danh sách các điểm vặn hỏi hóc búa cần giải quyết cho bước viết nháp [N10]. Nhờ chốt chặn kỹ thuật đó, chẳng ai phải thức khuya đập bỏ bài viết sau khi đã hoàn thành [N10].
