# BƯỚC 06: TRIỂN KHAI TỪNG PHẦN — BẢN NHÁP DRAFT 1 (`noi_dung_khoa_hoc` · `BAI_11`)

> **Truy vết Module**: `BM1_06_trien_khai_draft1`
> **Đã gọi**: `LAB017/lesson-script` + `LAB027/dung-deck`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

Trong bối cảnh đào tạo kỹ năng viết và làm báo cáo năm 2026, việc nghiên cứu chân dung người đọc đóng vai trò quan trọng trước khi bắt đầu soạn thảo [N15]. Thiết kế Persona không còn là việc điền tuổi tác chung chung mà là tìm ra câu cãi thực tế của họ [N15].

Nếu các bạn viết ngay 2.000 chữ mà không thử dàn ý trên 3 nhóm độc giả ảo, 82% trường hợp bài viết sẽ bị sếp trả về vì không trúng vấn đề [N03]. Hơn nữa, việc thử 3 hướng Outline A, B, C giúp tiết kiệm 4,5 giờ sửa bài mỗi tuần [N06].
