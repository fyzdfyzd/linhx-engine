# BƯỚC 08: VIẾT LẠI THEO GIỌNG TÁC GIẢ & CÂN BẰNG ĐỘC GIẢ (`noi_dung_khoa_hoc`)

| Hạng mục truy vết | Giá trị |
|---|---|
| **Truy vết Module** | `BM1_08_viet_lai_giong_tac_gia` |
| **Đã gọi** | `LAB049/linhx-viet-giong-viet`, `LAB049/luong-hoa`, `ho-so-bien-tap/linh/LUAT.md`, `ho-so-bien-tap/van-anh/LUAT.md` |
| **Nhận diện tạm** | Sakedemy (LAB043) |
| **Trạng thái mẫu** | chạy không mẫu |

Chào các anh chị học viên trong buổi thực hành thứ hai của chương trình, hôm nay tôi cùng cả lớp sẽ giải quyết một căn bệnh làm hao tổn hàng chục giờ làm việc mỗi tháng tại các phòng ban [GIẢ LẬP]. Đó là thói quen nhận đề bài một dòng từ cấp trên rồi lập tức cắm đầu viết liền hai nghìn chữ [GIẢ LẬP]. Đến lúc nộp lên, người viết mới ngỡ ngàng nhận ra sếp chỉ đọc đúng ba câu đầu đã gập tập hồ sơ lại vì thấy xa lạ với nỗi lo thực tế của họ [GIẢ LẬP].

Trong các biểu mẫu tiếp thị truyền thống, nhân sự thường phác họa người nhận bằng những thông tin nhân khẩu học vô thưởng vô phạt như nam giới ba mươi lăm tuổi sống tại đô thị lớn và yêu thích công nghệ [N15]. Những dòng giới thiệu êm ái đó hoàn toàn vô dụng khi bạn phải thuyết phục vị giám đốc điều hành đang đau đầu vì chi phí vận hành phình to [N15]. Để một bản đề xuất sống sót qua nửa phút đọc lướt đầu tiên, chúng ta bắt buộc hợp nhất khoảng trống nhận thức chưa ai nói thẳng với đặc điểm phân tầng nghề nghiệp xác thực [N15]. Người viết phải dự đoán chính xác lời phản bác sắc nhọn mà người đọc sẽ buột miệng cãi lại ngay khi nghe tiêu đề [N15].

Quy trình thực hành trong chín mươi phút hôm nay yêu cầu mỗi nhóm dựng lên đúng ba hình mẫu độc giả đại diện cho ba góc nhìn xung đột nhau trong cùng một tổ chức trước khi đặt bút viết câu mở màn [N07]. Gương mặt đầu tiên là người nắm quyền ký duyệt ngân sách vốn chỉ quan tâm đến hiệu quả thu hồi vốn và rủi ro pháp lý [N08]. Nhân vật thứ hai là cấp quản lý trực tiếp ở giữa đang sợ phát sinh thêm thủ tục hành chính cho anh em [N08]. Người thứ ba là chuyên gia kỹ thuật khó tính luôn đòi xem mã nguồn bằng chứng của mọi con số [N08].

Sau khi khóa chặt ba độc giả hay cãi này trên trang giấy, các anh chị chưa đi vào viết nháp ngay mà phải rút trích ba mươi hạt nhân góc nhìn từ kho tư liệu để lắp ghép thành ba hướng dàn ý đối lập nhau [N02]. Hướng tiếp cận đầu tiên đi theo lối giải phẫu nguyên lý hệ thống [N04]. Hướng thứ hai đâm thẳng vào nghịch lý chi phí ẩn đang chảy máu tại phòng ban, và hướng thứ ba trình bày theo cấu trúc cẩm nang hướng dẫn từng bước thực thi [N04].

Tại hoạt động trọng tâm kéo dài bốn mươi lăm phút giữa giờ, từng nhóm sẽ đóng vai ba độc giả khó tính kia để đọc mù cả ba dàn ý [N13]. Cả lớp sẽ chấm điểm khắt khe trên năm tiêu chí gồm độ khớp nỗi đau, nguy cơ bỏ đọc giữa chừng, mục gây ngán nhất, chất vấn vặn lại tác giả và giá trị thực tế mang về được ngay trong ngày mai [N13]. Phương án được chọn phải vượt qua mốc bảy phẩy năm điểm và ghi rõ danh sách các điểm vặn hỏi hóc búa cần giải quyết cho bước viết nháp [N10]. Nhờ chốt chặn kỹ thuật đó, chẳng ai phải thức khuya đập bỏ bài viết sau khi đã hoàn thành [N10].
