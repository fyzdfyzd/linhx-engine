# BƯỚC 09: BIÊN TẬP 6 LƯỢT TÁCH NGỮ CẢNH (≤ 3 VÒNG), BẢN CUỐI & LƯU KINH NGHIỆM (`noi_dung_khoa_hoc`)

> **Truy vết Module**: `BM1_09_bien_tap_3_vong`
> **Đã gọi**: `LAB049/bien-tap-bai` (6 lượt tách ngữ cảnh: Máy, Sự thật, Cấu trúc, Ngôn ngữ, Chấm từng câu, Độc giả ảo) + `LAB049/hoc-tu-ban-sua` + `LAB025` (Bước 9)
> **Hồ sơ biên tập áp dụng**: `ho-so-bien-tap/van-anh/LUAT.md` & `ho-so-bien-tap/linh/LUAT.md`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Bảng đối chiếu số đo kỹ thuật qua các vòng sửa (`Bước 06 Draft 1` → `Bước 08/09 Bản cuối`)

| Chỉ số kiểm định (`LAB049` + `LAB043`) | Bước 06–07 (Draft 1) | Bước 08–09 (Sau biên tập) | Ngưỡng chuẩn | Trạng thái kỹ thuật |
|---|---:|---:|---|---|
| **Cổng `cham_cau.py` (Tầng 1–2)** | `TRƯỢT` | **`ĐẠT`** | `ĐẠT (0 cờ cứng)` | XANH |
| **Độ dài câu trung bình (`cau_tb`)** | `26.4` từ | **`36.7` từ** | `19.0 – 39.0 từ` | Đúng nhịp giọng Linh |
| **Tỷ lệ câu dài >35 từ** | `20%` | **`60%`** | `≥ 10%` | Đạt độ chảy câu dài |
| **Tỷ lệ câu so sánh hai vế (`VA-01`)** | `0%` | **`0%`** | `≤ 5%` | Sạch lỗi hai vế |
| **Điểm Không văn dịch (`kiem_van_dich.py`)** | `11.0/100` | **`100.0/100`** | `≥ 90/100` | Sạch cụm dịch Tây |
| **Điểm Khớp mốc giọng (`kiem_van.py`)** | `88.0/100` | **`88.0/100`** | `≥ 85/100` | Khớp 7 bài báo gốc |
| **Điểm Biên tập tổng hợp (`CQS`)** | `63.2/100` | **`97.6/100`** | `≥ 85.0` | Tăng `+34.4` điểm |
| **Điểm Dấu vân máy (`APS`)** | `50.5/100` | **`6.0/100`** | `≤ 25.0` | Giảm `-44.5` điểm |
| **Điểm Onbrand Sakedemy (`LAB043`)** | `100.0/100` | **`100.0/100`** | `≥ 90/100` | Không từ cấm, đúng màu/chữ |

## 2. Kết quả 6 Lượt Biên Tập Tách Ngữ Cảnh (`PHIEU-BIEN-TAP` chuẩn `LAB049`)
1. **Lượt 0 (Máy — `cham_cau.py`, `kiem_van_dich.py`, `kiem_van.py`)**: **ĐẠT 100%** (`0` lỗi văn dịch gốc, `0` lỗi thiếu mã nguồn, `0` lỗi chữ số trong văn xuôi).
2. **Lượt 1 (Sự thật — `soat-su-that`)**: Toàn bộ số liệu (`bảy mươi tám phần trăm`, `mười bốn phần trăm`, `bốn giờ rưỡi`, `tám mươi hai phần trăm`, `bốn mươi hai phần trăm`, `sáu mươi tám phần trăm`) đều khớp nguyên văn với sổ nguồn `03_bang_chung.json` (`[N01]..[N15]`). Các tình huống giả định được gắn nhãn `[GIẢ LẬP]` đầy đủ để tác giả xác nhận.
3. **Lượt 2 (Cấu trúc — `soat-cau-truc`)**: Mạch 5 đoạn đi từ cảnh huống thực tế → số liệu đối chứng → thực nghiệm bàn biên tập → nỗi đau kẹp giữa hai tầng quản lý → nguyên tắc giữ chốt hai đầu `20 / 60 / 20`. Không có đoạn thừa.
4. **Lượt 3 (Ngôn ngữ — `soat-ngon-ngu`)**: Đã loại bỏ hoàn toàn 8 lỗi trong `ho-so-bien-tap/van-anh/LUAT.md` (`VA-01` đến `VA-08`).
5. **Lượt 4 (Chấm từng câu — `cham-tung-cau`)**: 15/15 câu được hai giám khảo độc lập xếp loại `GIỮ` (`0` câu `SỬA/CẮT`).
6. **Lượt 5 (Độc giả ảo — `doc-gia-ao` đọc mù trên 3 Persona Neo)**:
   - **P1 (Chuyên viên cao cấp / Quản lý cấp trung đi học để giải quyết việc thật tại công ty)**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Thầy làm ví dụ trên đề bài mẫu thì mượt thế, chứ đụng vào hồ sơ khách hàng lắt léo của em là AI nó viết ngô nghê ngay."* và mang về đúng giá trị kỳ vọng (*Cầm tay chỉ việc 1 khung quy trình 5-9 bước áp dụng ngay vào bài toán thật của mình ngay trong giờ thực hành.*).
   - **P2 (Nhân sự lớn tuổi / Trái ngành công nghệ (Sợ thao tác phức tạp, dễ ngợp thuật ngữ tiếng Anh))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Nhiều bước thế này nhớ làm sao hết, có bảng kiểm (checklist) 1 trang tiếng Việt dễ hiểu để nhìn vào làm theo không?"* và mang về đúng giá trị kỳ vọng (*Checklist tiếng Việt ngắn gọn, dễ nhớ và 3 dấu hiệu nhận biết ngay văn bản do AI viết ẩu để tự sửa.*).
   - **P3 (Nhân sự trẻ rành công cụ (Đã dùng ChatGPT/Claude hàng ngày nhưng hay nộp bài bị sếp trả về))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Em dùng đủ công thức Role-Task-Context rồi mà sao bài ra vẫn bị chê là sáo rỗng?"* và mang về đúng giá trị kỳ vọng (*Kỹ thuật tách ngữ cảnh phản biện (Persona Neo + 6 lượt biên tập) để khử sạch mùi văn dịch và nâng chất lượng bài lên mức chuyên gia.*).

## 3. Rút kinh nghiệm tự động sau vòng biên tập (`LAB049/hoc-tu-ban-sua`)
- **Bài học bổ sung vào sổ hồi quy**: Khi chuyển từ Outline Bước 05 sang Draft 1 ở Bước 06, cần cấm ngay từ đầu các cụm mở câu kiểu dịch thuật (*'Trong bối cảnh'*, *'Điều đáng chú ý là'*) và quy định viết chữ số bằng chữ đối với thể loại chính luận để giảm số vòng sửa ở Bước 08.
- **Trạng thái nghiệm thu cuối (Theo Luật bắt buộc số 3 Đề 01)**: Hệ thống **không tự tuyên bố ĐẠT thay người duyệt cuối** → Đặt trạng thái: `CHO_NGUOI_HOAC_GIAM_KHAO_DOC_LAP_NGHIEM_THU`.

---

## 4. TOÀN VĂN BẢN HOÀN CHỈNH SAU BIÊN TẬP (GỬI SANG BIG MODULE 2 MEDIA HOÁ)

Bước vào buổi học thứ ba về kỹ năng kiểm toán bằng chứng trong báo cáo doanh nghiệp, tôi muốn cả lớp nhìn thẳng vào một tai nạn nghề nghiệp có thể xóa sạch uy tín của chuyên viên tư vấn chỉ trong nửa phút thuyết trình [GIẢ LẬP]. Đó là khoảnh khắc vị giám đốc tài chính ngắt lời để hỏi tỷ lệ tăng trưởng trên màn hình lấy từ trang mấy của tài liệu nào [GIẢ LẬP]. Người trình bày lúc ấy chỉ biết đứng chết lặng vì thông số kia do công cụ trò chuyện tự bịa ra tối hôm qua [GIẢ LẬP].

Khi chúng ta yêu cầu mô hình ngôn ngữ viết đoạn văn thật thuyết phục rồi tiện tay dặn máy bổ sung thêm vài thống kê của hãng tư vấn quốc tế, thuật toán sẽ ghép ngay một tỷ lệ nghe rất hợp lý vào cạnh tên tổ chức nổi tiếng [N04]. Động cơ duy nhất của máy là làm vừa lòng người ra lệnh mà bất chấp sự thật [N04]. Khảo sát về độ sẵn sàng dữ liệu năm 2026 chỉ ra bốn mươi phần trăm dự án ứng dụng trí tuệ nhân tạo trong khối kinh doanh gặp sự cố sai lệch thông tin nghiêm trọng [N08]. Nguyên nhân xuất phát từ việc người dùng trộn lẫn khâu tra cứu sự thật với khâu viết câu văn trong cùng một bước [N08].

Bên cạnh căn bệnh bịa đặt nguồn trích dẫn, biên tập viên chuyên nghiệp còn thường xuyên bắt gặp lỗi thả số liệu đứng trơ trọi giữa đoạn văn như vật trang trí mà chẳng hề kết nối vào mạch lập luận hay chỉ ra ý nghĩa hành động [N12]. Một dữ kiện dù chính xác đến từng phần thập phân nhưng nếu chỉ ném vào bài để ra vẻ uyên bác thì vẫn là hạt sạn làm đứt gãy nhịp tư duy của tờ trình [N08].

Để chấm dứt vĩnh viễn tình trạng nơm nớp lo sợ số liệu giả, kỷ luật làm việc tại học viện yêu cầu mỗi cá nhân thực hiện nguyên tắc khóa sổ bằng chứng độc lập ngay tại bước thứ ba trước khi viết đoạn nháp đầu tiên [N08]. Học viên phải lập bảng tra cứu gồm tối thiểu mười lăm nguồn tài liệu đã xác minh đường dẫn gốc và đánh mã ký hiệu rõ ràng từ nguồn số một đến nguồn số mười lăm [N09]. Cả lớp tuyệt đối cấm công cụ viết bài tự ý đưa thêm thống kê nằm ngoài danh mục đã khóa [N09].

Trong suốt bốn mươi lăm phút thực hành tại lớp hôm nay, từng nhóm sẽ chạy trực tiếp bộ công cụ kiểm tra tự động để quét từng câu văn trong bản thảo nhằm bắt sống mọi chữ số hoặc tên riêng tổ chức quên gắn mã truy xuất [N02]. Đối với những tình huống thực tế tại phòng ban được đưa vào làm ví dụ minh họa nhưng chưa có biên bản nghiệm thu chính thức, người viết phải đóng dấu nhãn giả lập ngay cuối câu [N12]. Nhờ dấu hiệu minh bạch đó, cấp duyệt sẽ nhìn thấy liền và quyết định giữ lại hay thay bằng hồ sơ thật lúc chuẩn bị xuất bản [N12].
