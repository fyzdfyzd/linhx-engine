# BƯỚC M2: TẠO ẢNH GỐC BẰNG AGY (`image-generator`), VẼ EXHIBIT (`LAB028`) & LUẬT ONBRAND (`noi_dung_khoa_hoc`)

> **Truy vết Big Module 2**: `BM2_M1_chu_trinh_template` (Bước 2/5)
> **Đã gọi**: `AGY image-generator (subagent c4037b95-4d7f-4e7b-90b7-9f05e8f462b1)`, `LAB028/linhx-report/scripts/hinh.py`, `LAB043/brands/sakedemy/LUAT-ONBRAND.md`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Hồ sơ Ảnh gốc Photorealistic do AGY (`image-generator`) tạo mới
- **File ảnh gốc trong Run**: `media/agy_anh_goc_sakedemy.jpg` (`838,959 bytes`)
- **Subagent thực thi**: `ea0b3721-a111-43b2-a615-bf032235a101` (`TypeName: image-generator`)
- **Prompt thiết kế theo chuẩn `LAB043/04-hinh-anh/PROMPT-CHATGPT-V2.md`**:
  > `Candid photorealistic 16:9 photo of a Vietnamese corporate training workshop where participants work in pairs at wooden tables, cross-checking printed documents with red/green pens alongside laptops while a Vietnamese instructor guides them, bright airy room with tropical green plants (#6EB264, #02403B).`
- **Kiểm tra đối chiếu `LUAT-ONBRAND.md` & `LAB066`**:
  - [x] Bối cảnh lớp học / phòng họp doanh nghiệp Việt Nam thật, ánh sáng tự nhiên ban ngày.
  - [x] Tông màu chủ đạo Trắng sáng kết hợp điểm nhấn Xanh Lá (`#6EB264`) và Xanh Rêu Đậm (`#02403B`).
  - [x] Không chứa chữ méo, không chứa logo rác, không có robot hay não phát sáng kiểu sci-fi stock.

## 2. Biểu đồ Dữ liệu Chuẩn Tư Vấn (`LAB028/linhx-report/scripts/hinh.py`)
- **`H01.svg`** (`thanh-ngang`): *Bốn mươi phần trăm báo cáo dùng AI tự do mắc lỗi ảo giác số liệu hoặc râu ông nọ cắm cằm bà kia [AGY-N7].* — Nguồn: `Omdia & Snowflake Readiness Benchmark 2026 [AGY-N7] + Luật soat-su-that LAB049 [N08]`
- **`H02.svg`** (`cot`): *Cổng kiểm tra sự thật tự động giúp phát hiện một trăm phần trăm câu chứa số liệu quên gắn mã nguồn [N09].* — Nguồn: `Kiểm thử thực nghiệm LAB049 cham_cau.py & LAB028 report.py kiem-so (2026) [N08, N09]`

## 3. Năm Luật Cấm Tuyệt Đối khi dựng Template Sakedemy
- [x] **Cấm 1 (Tương phản)**: Không bao giờ đặt chữ trắng (`#FFFFFF`) lên nền Xanh Lá (`#6EB264`) vì độ tương phản chỉ đạt `2,56:1`. Chữ trên nền `#6EB264` bắt buộc dùng Xanh Rêu Đậm (`#02403B` — đạt `4,57:1`).
- [x] **Cấm 2 (Màu cũ)**: Không dùng màu Navy (`#051D40`) cạnh màu Xanh Lá trên ấn phẩm mới.
- [x] **Cấm 3 (Font chữ)**: Không dùng Poppins, Montserrat, serif hay font viết tay; chỉ dùng `Be Vietnam Pro`.
- [x] **Cấm 4 (Logo)**: Không đặt logo bản màu lên nền `#6EB264` (phải dùng bản âm bản trắng hoặc đặt trên nền sáng/nền `#02403B`).
- [x] **Cấm 5 (Từ cấm)**: Không xuất hiện bất kỳ từ nào trong `voice.words_banned` (`lorem ipsum`, `số 1 Việt Nam`, `cam kết tối ưu 30%`, `bị đào thải`, `siêu khoá`...).
