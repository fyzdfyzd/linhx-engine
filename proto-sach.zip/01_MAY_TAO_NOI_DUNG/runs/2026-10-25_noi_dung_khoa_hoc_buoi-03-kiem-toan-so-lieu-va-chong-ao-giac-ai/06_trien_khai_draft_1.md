# BƯỚC 06: TRIỂN KHAI TỪNG PHẦN — BẢN NHÁP DRAFT 1 (`noi_dung_khoa_hoc` · `BAI_12`)

> **Truy vết Module**: `BM1_06_trien_khai_draft1`
> **Đã gọi**: `LAB017/lesson-script` + `LAB027/dung-deck`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

Trong bối cảnh làm báo cáo quản trị năm 2026, việc kiểm chứng số liệu do AI sinh ra đóng vai trò quan trọng để giữ uy tín cho người viết [N08]. Kiểm toán bằng chứng không còn là bước phụ ở cuối bài mà là điều kiện tiên quyết từ đầu [N08].

Rất nhiều nhân viên có thói quen bảo AI "hãy thêm vài số liệu của McKinsey vào đoạn này cho thuyết phục", dẫn đến 40% con số trong báo cáo là số liệu ảo giác [N04]. Hơn nữa, việc thả số liệu 78% hay 82% mà không có mã nguồn sẽ bị đánh trượt ngay lập tức [N01].
