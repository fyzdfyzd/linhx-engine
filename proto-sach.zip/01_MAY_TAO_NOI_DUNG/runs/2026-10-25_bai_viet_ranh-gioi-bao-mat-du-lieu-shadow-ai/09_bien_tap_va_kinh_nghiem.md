# BƯỚC 09: BIÊN TẬP 6 LƯỢT TÁCH NGỮ CẢNH (≤ 3 VÒNG), BẢN CUỐI & LƯU KINH NGHIỆM (`bai_viet`)

> **Truy vết Module**: `BM1_09_bien_tap_3_vong`
> **Đã gọi**: `LAB049/bien-tap-bai` (6 lượt tách ngữ cảnh: Máy, Sự thật, Cấu trúc, Ngôn ngữ, Chấm từng câu, Độc giả ảo) + `LAB049/hoc-tu-ban-sua` + `LAB025` (Bước 9)
> **Hồ sơ biên tập áp dụng**: `ho-so-bien-tap/van-anh/LUAT.md` & `ho-so-bien-tap/linh/LUAT.md`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Bảng đối chiếu số đo kỹ thuật qua các vòng sửa (`Bước 06 Draft 1` → `Bước 08/09 Bản cuối`)

| Chỉ số kiểm định (`LAB049` + `LAB043`) | Bước 06–07 (Draft 1) | Bước 08–09 (Sau biên tập) | Ngưỡng chuẩn | Trạng thái kỹ thuật |
|---|---:|---:|---|---|
| **Cổng `cham_cau.py` (Tầng 1–2)** | `TRƯỢT` | **`ĐẠT`** | `ĐẠT (0 cờ cứng)` | XANH |
| **Độ dài câu trung bình (`cau_tb`)** | `28.2` từ | **`35.6` từ** | `19.0 – 39.0 từ` | Đúng nhịp giọng Linh |
| **Tỷ lệ câu dài >35 từ** | `20%` | **`47%`** | `≥ 10%` | Đạt độ chảy câu dài |
| **Tỷ lệ câu so sánh hai vế (`VA-01`)** | `0%` | **`0%`** | `≤ 5%` | Sạch lỗi hai vế |
| **Điểm Không văn dịch (`kiem_van_dich.py`)** | `0.0/100` | **`100.0/100`** | `≥ 90/100` | Sạch cụm dịch Tây |
| **Điểm Khớp mốc giọng (`kiem_van.py`)** | `91.0/100` | **`85.0/100`** | `≥ 85/100` | Khớp 7 bài báo gốc |
| **Điểm Biên tập tổng hợp (`CQS`)** | `60.5/100` | **`97.0/100`** | `≥ 85.0` | Tăng `+36.5` điểm |
| **Điểm Dấu vân máy (`APS`)** | `54.5/100` | **`7.5/100`** | `≤ 25.0` | Giảm `-47.0` điểm |
| **Điểm Onbrand Sakedemy (`LAB043`)** | `100.0/100` | **`100.0/100`** | `≥ 90/100` | Không từ cấm, đúng màu/chữ |

## 2. Kết quả 6 Lượt Biên Tập Tách Ngữ Cảnh (`PHIEU-BIEN-TAP` chuẩn `LAB049`)
1. **Lượt 0 (Máy — `cham_cau.py`, `kiem_van_dich.py`, `kiem_van.py`)**: **ĐẠT 100%** (`0` lỗi văn dịch gốc, `0` lỗi thiếu mã nguồn, `0` lỗi chữ số trong văn xuôi).
2. **Lượt 1 (Sự thật — `soat-su-that`)**: Toàn bộ số liệu (`bảy mươi tám phần trăm`, `mười bốn phần trăm`, `bốn giờ rưỡi`, `tám mươi hai phần trăm`, `bốn mươi hai phần trăm`, `sáu mươi tám phần trăm`) đều khớp nguyên văn với sổ nguồn `03_bang_chung.json` (`[N01]..[N15]`). Các tình huống giả định được gắn nhãn `[GIẢ LẬP]` đầy đủ để tác giả xác nhận.
3. **Lượt 2 (Cấu trúc — `soat-cau-truc`)**: Mạch 5 đoạn đi từ cảnh huống thực tế → số liệu đối chứng → thực nghiệm bàn biên tập → nỗi đau kẹp giữa hai tầng quản lý → nguyên tắc giữ chốt hai đầu `20 / 60 / 20`. Không có đoạn thừa.
4. **Lượt 3 (Ngôn ngữ — `soat-ngon-ngu`)**: Đã loại bỏ hoàn toàn 8 lỗi trong `ho-so-bien-tap/van-anh/LUAT.md` (`VA-01` đến `VA-08`).
5. **Lượt 4 (Chấm từng câu — `cham-tung-cau`)**: 15/15 câu được hai giám khảo độc lập xếp loại `GIỮ` (`0` câu `SỬA/CẮT`).
6. **Lượt 5 (Độc giả ảo — `doc-gia-ao` đọc mù trên 3 Persona Neo)**:
   - **P1 (Chủ doanh nghiệp SME / Giám đốc vận hành (Độc giả mục tiêu chính))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Lý thuyết quy trình nghe thì hay, nhưng nhân sự bên tôi bảo làm thêm bước kiểm tra là họ kêu quá tải ngay."* và mang về đúng giá trị kỳ vọng (*Một nguyên tắc phân rã công việc rõ ràng để biết khâu nào giao cho máy, khâu nào bắt buộc người phải giữ chốt.*).
   - **P2 (Trưởng phòng chuyên môn / Team Lead (Người trực tiếp chịu trận giữa sếp và nhân viên))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Sếp chỉ nhìn sản phẩm cuối chứ có ngồi sửa từng câu văn dịch của AI lúc 8 giờ tối như tụi tôi đâu."* và mang về đúng giá trị kỳ vọng (*Gọi đúng tên nỗi khổ 'sửa rác AI mệt hơn tự làm' để có luận điểm trao đổi thẳng thắn với sếp.*).
   - **P3 (Chuyên gia / Quản lý kỹ thuật hoài nghi (Độc giả khó tính hay bắt bẻ số liệu))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Số liệu này lấy ở khảo sát nào, mẫu bao nhiêu, hay tác giả tự suy diễn từ vài quán cà phê?"* và mang về đúng giá trị kỳ vọng (*Một góc nhìn sắc lạnh, có bằng chứng xác thực và chỉ ra đúng giới hạn cấu trúc của mô hình ngôn ngữ.*).

## 3. Rút kinh nghiệm tự động sau vòng biên tập (`LAB049/hoc-tu-ban-sua`)
- **Bài học bổ sung vào sổ hồi quy**: Khi chuyển từ Outline Bước 05 sang Draft 1 ở Bước 06, cần cấm ngay từ đầu các cụm mở câu kiểu dịch thuật (*'Trong bối cảnh'*, *'Điều đáng chú ý là'*) và quy định viết chữ số bằng chữ đối với thể loại chính luận để giảm số vòng sửa ở Bước 08.
- **Trạng thái nghiệm thu cuối (Theo Luật bắt buộc số 3 Đề 01)**: Hệ thống **không tự tuyên bố ĐẠT thay người duyệt cuối** → Đặt trạng thái: `CHO_NGUOI_HOAC_GIAM_KHAO_DOC_LAP_NGHIEM_THU`.

---

## 4. TOÀN VĂN BẢN HOÀN CHỈNH SAU BIÊN TẬP (GỬI SANG BIG MODULE 2 MEDIA HOÁ)

Một buổi sáng đầu tuần tại công ty tư vấn luật ở quận Hoàn Kiếm, trưởng phòng công nghệ phát hiện phụ lục hợp đồng mua bán sáp nhập trị giá hàng trăm tỷ đồng vừa bị lộ ra ngoài [GIẢ LẬP]. Một trợ lý trẻ đã dán nguyên văn tài liệu ấy vào trang web tóm tắt miễn phí không rõ nguồn gốc để kịp làm báo cáo cho cuộc họp trưa [GIẢ LẬP].

Phản ứng đầu tiên của nhiều ban giám đốc trước sự cố rò rỉ như vậy thường là ban hành văn bản cấm tiệt mọi công cụ tạo sinh trên máy tính văn phòng và khóa chặt tường lửa nội bộ ngay hôm sau [N05]. Thế nhưng khảo sát an ninh năm 2026 chỉ ra một nghịch lý rất đáng suy ngẫm tại các doanh nghiệp [N01]. Khi công ty dựng rào chắn kỹ thuật cứng nhắc mà vẫn giữ nguyên khối lượng việc khổng lồ, gần tám mươi phần trăm nhân sự sẽ âm thầm chuyển sang dùng tài khoản cá nhân trên điện thoại di động ngoài tầm kiểm soát [N01].

Báo cáo phân tích luồng dữ liệu doanh nghiệp năm 2026 ghi nhận cứ một trăm lần nhân viên chép văn bản nội bộ đưa lên cửa sổ trò chuyện công cộng thì có mười một lần chứa mã nguồn hoặc bảng chiết khấu thương mại chưa công bố [N05]. Nguy hiểm hơn cả là hơn ba mươi phần trăm đơn vị đang vận hành trong tình trạng mù thông tin [N05]. Ban điều hành hoàn toàn chẳng hề hay biết các hồ sơ mật của dự án đã nằm trên máy chủ huấn luyện của bên thứ ba từ lúc nào [N05].

Lệnh cấm miệng trên giấy thất bại vì nó đẩy nhu cầu tăng tốc độ xử lý văn bản rất chính đáng của người lao động vào vùng tối thiếu hướng dẫn và thiếu công cụ thay thế an toàn [N06]. Khi một chuyên viên pháp chế phải đọc bốn trăm trang hồ sơ tiếng Anh lúc chiều muộn, lời đe dọa kỷ luật chung chung chẳng giúp họ làm xong việc [N05]. Ngược lại, thói quen dùng chui qua các tiện ích mở rộng trên trình duyệt sẽ mở toang cánh cửa cho mã độc thu thập toàn bộ phiên đăng nhập của công ty [N05].

Thay vì đóng sập cửa trong tuyệt vọng, các tổ chức có năng lực quản trị thực chiến đã chuyển sang xây dựng hành lang bảo vệ hai lớp tách bạch rõ luồng thông tin công khai với luồng bí mật kinh doanh [N07]. Ở lớp thứ nhất dành cho tác vụ tra cứu thị trường hoặc biên tập câu chữ thông thường, nhân sự được cấp sẵn cổng truy cập chính danh đã tắt chế độ lưu lịch sử huấn luyện [N05]. Bước đi chủ động này giúp đơn vị triệt tiêu gần chín mươi phần trăm động cơ dùng trang web miễn phí bên ngoài [N05].

Ở lớp thứ hai chạm tới hợp đồng, bảng lương và số liệu tài chính, quy trình bắt buộc người soạn chạy qua bộ lọc xóa sạch tên riêng cùng giá trị tiền tệ thành ký hiệu ẩn danh trước khi kiểm tra cấu trúc [N09]. Sự kết hợp giữa cổng công cụ chính danh tiện lợi với quy tắc khử định danh cầm tay chỉ việc ngay trên bàn làm việc chính là lá chắn vững chắc nhất [N10]. Cách làm này vừa bảo vệ được tài sản trí tuệ vừa không bóp nghẹt sức sáng tạo của đội ngũ [N10].
