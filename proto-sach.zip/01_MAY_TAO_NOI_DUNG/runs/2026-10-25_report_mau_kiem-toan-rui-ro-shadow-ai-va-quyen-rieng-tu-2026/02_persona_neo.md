# BƯỚC 02: NGHIÊN CỨU NGƯỜI NHẬN & DỰNG 3 PERSONA NEO (`report_mau`)

> **Truy vết Module**: `BM1_02_persona_neo` (Gộp mới từ `LAB029` + `LAB048` + `LAB049`)
> **Đã gọi**: `LAB029/nhu-cau-doc-gia`, `LAB048/lay_mau_1000.py` (`persona-sample-60.json`), `LAB049/doc-gia-ao`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Phân tích khoảng trống người nhận (Theo `LAB029`)
- **Đề bài**: Báo cáo mẫu: Kiểm toán Rủi ro Shadow AI và Khung Quản trị Dữ liệu Hai Lớp cho Doanh nghiệp vừa và nhỏ Việt Nam 2026
- **Chủ đề đối chuẩn**: Báo cáo chẩn đoán & lộ trình đào tạo AI thực chiến cho doanh nghiệp Việt Nam 2026
- **Khoảng trống trên thị trường hiện tại**: Các báo cáo thị trường hiện tại hoặc dịch nguyên xi số liệu toàn cầu của McKinsey/Gartner (không sát thực tế SME Việt Nam), hoặc là brochure bán khoá học trá hình không có ma trận đo lường ROI.
- **Điểm cơ hội khoảng trống (`gap_score`)**: **8.9/10**

## 2. Hồ sơ 3 Persona Neo (Lọc nhân khẩu `LAB048` + Tâm lý phản biện `LAB049`)

### [P1] CEO / Thành viên HĐQT duyệt ngân sách đào tạo & chuyển đổi AI
- **Hồ sơ nhân khẩu học (`LAB048` UUID `e1dc46d3-36cb-5d5b-b1df-707006b548bf`)**: 49 tuổi · Nữ · Nông Thôn (Trung du và miền núi phía Bắc) · Học vấn: Trung học phổ thông
- **Bối cảnh tiếp nhận (`LAB049`)**: Xem bản PDF trên iPad hoặc bản in A4 trong cuộc họp duyệt ngân sách quý (chỉ dành 5 phút đầu quét Executive Summary và biểu đồ).
- **Nỗi sợ ẩn**: Chi hàng trăm triệu đào tạo xong nhân viên chỉ biết viết email bằng AI, sau 3 tháng đâu lại vào đấy, không đo được năng suất tăng thật.
- **Câu cửa miệng hay cãi (Phản xạ phòng vệ)**: *"Đào tạo xong đo bằng gì để chứng minh tiết kiệm được giờ công, hay chỉ phát chứng chỉ cho vui?"*
- **Ngưỡng bỏ đọc (`trigger_bo_doc`)**: Trang đầu toàn chữ đặc kín không có biểu đồ định lượng, hoặc dùng toàn số liệu Mỹ/Châu Âu không có đối chuẩn Việt Nam.
- **Kỳ vọng mang về sau khi đọc/học**: Khung phân tầng năng lực rõ ràng, chỉ số đo lường trước-sau (KPI/ROI) và lộ trình triển khai 90 ngày không làm đứt gãy vận hành.

### [P2] Giám đốc Nhân sự (HRD) / Trưởng bộ phận Đào tạo (L&D)
- **Hồ sơ nhân khẩu học (`LAB048` UUID `b79dbd24-5e9c-599a-a8e8-f2b4aee20403`)**: 32 tuổi · Nữ · Đô Thị (Đông Nam Bộ) · Học vấn: Trung học cơ sở
- **Bối cảnh tiếp nhận (`LAB049`)**: Đọc kỹ từng trang trên máy tính để lấy căn cứ làm tờ trình bảo vệ kế hoạch đào tạo trước Ban Giám đốc.
- **Nỗi sợ ẩn**: Tổ chức lớp học mà tỷ lệ hoàn thành bài tập thấp, các trưởng bộ phận phàn nàn chương trình xa rời công việc hàng ngày của họ.
- **Câu cửa miệng hay cãi (Phản xạ phòng vệ)**: *"Chương trình đại trà kiểu này phòng Marketing nghe được chứ phòng Kế toán hay Vận hành ngồi nghe là họ bỏ về."*
- **Ngưỡng bỏ đọc (`trigger_bo_doc`)**: Báo cáo thiếu phân tách nhu cầu theo phòng ban (Marketing, Sales, vận hành, HR) và thiếu phương pháp kèm cặp sau khoá học.
- **Kỳ vọng mang về sau khi đọc/học**: Bảng ma trận thiết kế chương trình may đo theo nhóm việc và cơ chế nghiệm thu sản phẩm đầu ra ngay tại lớp.

### [P3] Trưởng phòng CNTT / Chuyển đổi số (IT/DX Lead - Người gác cổng bảo mật & hạ tầng)
- **Hồ sơ nhân khẩu học (`LAB048` UUID `e630436c-d061-511f-844a-280985c41444`)**: 44 tuổi · Nữ · Nông Thôn (Đồng bằng sông Hồng) · Học vấn: Trung học phổ thông
- **Bối cảnh tiếp nhận (`LAB049`)**: Đọc phần phương pháp luận, quy trình dữ liệu và rủi ro bảo mật trong báo cáo.
- **Nỗi sợ ẩn**: Nhân viên học xong đem hợp đồng mật, bảng lương, dữ liệu khách hàng dán thẳng lên các công cụ AI công cộng.
- **Câu cửa miệng hay cãi (Phản xạ phòng vệ)**: *"Dạy dùng AI tăng tốc mà không có quy chế phân loại dữ liệu nhạy cảm thì một vụ lộ lọt là bay cả năm lợi nhuận."*
- **Ngưỡng bỏ đọc (`trigger_bo_doc`)**: Báo cáo chỉ tô hồng lợi ích tốc độ mà bỏ qua hoàn toàn cổng kiểm soát rủi ro dữ liệu và ảo giác số liệu (hallucination).
- **Kỳ vọng mang về sau khi đọc/học**: Bộ quy tắc an toàn dữ liệu và quy trình kiểm chứng 2 lớp được tích hợp sẵn trong khung đào tạo.

## 3. Quy tắc neo cho các bước sau
- **Bước 4 (`BM1_04_outline_thu_persona`)**: Cả 3 phương án Outline A/B/C bắt buộc phải đưa qua 3 Persona `P1`, `P2`, `P3` đọc thử và trả lời câu cãi của họ.
- **Bước 8 & 9 (`BM1_08`, `BM1_09`)**: Bản viết cuối không được vi phạm `trigger_bo_doc` của bất kỳ Persona nào và phải trả lời trực diện ít nhất 2/3 câu cãi trên.
