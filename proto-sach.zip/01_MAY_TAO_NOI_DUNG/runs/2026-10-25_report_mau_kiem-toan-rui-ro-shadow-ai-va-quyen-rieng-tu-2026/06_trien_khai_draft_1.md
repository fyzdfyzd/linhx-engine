# BƯỚC 06: TRIỂN KHAI TỪNG PHẦN — BẢN NHÁP DRAFT 1 (`report_mau` · `BAI_08`)

> **Truy vết Module**: `BM1_06_trien_khai_draft1`
> **Đã gọi**: `LAB028/viet-bao-cao` + `LAB046/report-core`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

Trong bối cảnh năm 2026, rủi ro lộ dữ liệu qua Shadow AI đóng vai trò quan trọng trong quản trị doanh nghiệp [N05]. Quản trị bảo mật không còn là việc cài phần mềm diệt virus mà là kiểm soát hành vi dán dữ liệu vào khung chat [N05].

Theo số liệu, 78% nhân sự tự dùng AI nhưng chỉ 14% công ty có quy trình nghiệm thu và kiểm soát bảo mật [N01]. Điều đáng chú ý là 83% dữ liệu nội bộ đang chảy vào các công cụ miễn phí không an toàn [N05].
