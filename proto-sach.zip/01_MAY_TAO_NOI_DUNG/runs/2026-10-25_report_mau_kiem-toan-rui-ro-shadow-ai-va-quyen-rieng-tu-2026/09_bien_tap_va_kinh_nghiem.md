# BƯỚC 09: BIÊN TẬP 6 LƯỢT TÁCH NGỮ CẢNH (≤ 3 VÒNG), BẢN CUỐI & LƯU KINH NGHIỆM (`report_mau`)

> **Truy vết Module**: `BM1_09_bien_tap_3_vong`
> **Đã gọi**: `LAB049/bien-tap-bai` (6 lượt tách ngữ cảnh: Máy, Sự thật, Cấu trúc, Ngôn ngữ, Chấm từng câu, Độc giả ảo) + `LAB049/hoc-tu-ban-sua` + `LAB025` (Bước 9)
> **Hồ sơ biên tập áp dụng**: `ho-so-bien-tap/van-anh/LUAT.md` & `ho-so-bien-tap/linh/LUAT.md`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Bảng đối chiếu số đo kỹ thuật qua các vòng sửa (`Bước 06 Draft 1` → `Bước 08/09 Bản cuối`)

| Chỉ số kiểm định (`LAB049` + `LAB043`) | Bước 06–07 (Draft 1) | Bước 08–09 (Sau biên tập) | Ngưỡng chuẩn | Trạng thái kỹ thuật |
|---|---:|---:|---|---|
| **Cổng `cham_cau.py` (Tầng 1–2)** | `TRƯỢT` | **`ĐẠT`** | `ĐẠT (0 cờ cứng)` | XANH |
| **Độ dài câu trung bình (`cau_tb`)** | `23.6` từ | **`34.1` từ** | `19.0 – 39.0 từ` | Đúng nhịp giọng Linh |
| **Tỷ lệ câu dài >35 từ** | `0%` | **`29%`** | `≥ 10%` | Đạt độ chảy câu dài |
| **Tỷ lệ câu so sánh hai vế (`VA-01`)** | `0%` | **`0%`** | `≤ 5%` | Sạch lỗi hai vế |
| **Điểm Không văn dịch (`kiem_van_dich.py`)** | `0.0/100` | **`100.0/100`** | `≥ 90/100` | Sạch cụm dịch Tây |
| **Điểm Khớp mốc giọng (`kiem_van.py`)** | `85.0/100` | **`88.0/100`** | `≥ 85/100` | Khớp 7 bài báo gốc |
| **Điểm Biên tập tổng hợp (`CQS`)** | `55.1/100` | **`97.6/100`** | `≥ 85.0` | Tăng `+42.5` điểm |
| **Điểm Dấu vân máy (`APS`)** | `57.5/100` | **`6.0/100`** | `≤ 25.0` | Giảm `-51.5` điểm |
| **Điểm Onbrand Sakedemy (`LAB043`)** | `100.0/100` | **`100.0/100`** | `≥ 90/100` | Không từ cấm, đúng màu/chữ |

## 2. Kết quả 6 Lượt Biên Tập Tách Ngữ Cảnh (`PHIEU-BIEN-TAP` chuẩn `LAB049`)
1. **Lượt 0 (Máy — `cham_cau.py`, `kiem_van_dich.py`, `kiem_van.py`)**: **ĐẠT 100%** (`0` lỗi văn dịch gốc, `0` lỗi thiếu mã nguồn, `0` lỗi chữ số trong văn xuôi).
2. **Lượt 1 (Sự thật — `soat-su-that`)**: Toàn bộ số liệu (`bảy mươi tám phần trăm`, `mười bốn phần trăm`, `bốn giờ rưỡi`, `tám mươi hai phần trăm`, `bốn mươi hai phần trăm`, `sáu mươi tám phần trăm`) đều khớp nguyên văn với sổ nguồn `03_bang_chung.json` (`[N01]..[N15]`). Các tình huống giả định được gắn nhãn `[GIẢ LẬP]` đầy đủ để tác giả xác nhận.
3. **Lượt 2 (Cấu trúc — `soat-cau-truc`)**: Mạch 5 đoạn đi từ cảnh huống thực tế → số liệu đối chứng → thực nghiệm bàn biên tập → nỗi đau kẹp giữa hai tầng quản lý → nguyên tắc giữ chốt hai đầu `20 / 60 / 20`. Không có đoạn thừa.
4. **Lượt 3 (Ngôn ngữ — `soat-ngon-ngu`)**: Đã loại bỏ hoàn toàn 8 lỗi trong `ho-so-bien-tap/van-anh/LUAT.md` (`VA-01` đến `VA-08`).
5. **Lượt 4 (Chấm từng câu — `cham-tung-cau`)**: 15/15 câu được hai giám khảo độc lập xếp loại `GIỮ` (`0` câu `SỬA/CẮT`).
6. **Lượt 5 (Độc giả ảo — `doc-gia-ao` đọc mù trên 3 Persona Neo)**:
   - **P1 (CEO / Thành viên HĐQT duyệt ngân sách đào tạo & chuyển đổi AI)**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Đào tạo xong đo bằng gì để chứng minh tiết kiệm được giờ công, hay chỉ phát chứng chỉ cho vui?"* và mang về đúng giá trị kỳ vọng (*Khung phân tầng năng lực rõ ràng, chỉ số đo lường trước-sau (KPI/ROI) và lộ trình triển khai 90 ngày không làm đứt gãy vận hành.*).
   - **P2 (Giám đốc Nhân sự (HRD) / Trưởng bộ phận Đào tạo (L&D))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Chương trình đại trà kiểu này phòng Marketing nghe được chứ phòng Kế toán hay Vận hành ngồi nghe là họ bỏ về."* và mang về đúng giá trị kỳ vọng (*Bảng ma trận thiết kế chương trình may đo theo nhóm việc và cơ chế nghiệm thu sản phẩm đầu ra ngay tại lớp.*).
   - **P3 (Trưởng phòng CNTT / Chuyển đổi số (IT/DX Lead - Người gác cổng bảo mật & hạ tầng))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Dạy dùng AI tăng tốc mà không có quy chế phân loại dữ liệu nhạy cảm thì một vụ lộ lọt là bay cả năm lợi nhuận."* và mang về đúng giá trị kỳ vọng (*Bộ quy tắc an toàn dữ liệu và quy trình kiểm chứng 2 lớp được tích hợp sẵn trong khung đào tạo.*).

## 3. Rút kinh nghiệm tự động sau vòng biên tập (`LAB049/hoc-tu-ban-sua`)
- **Bài học bổ sung vào sổ hồi quy**: Khi chuyển từ Outline Bước 05 sang Draft 1 ở Bước 06, cần cấm ngay từ đầu các cụm mở câu kiểu dịch thuật (*'Trong bối cảnh'*, *'Điều đáng chú ý là'*) và quy định viết chữ số bằng chữ đối với thể loại chính luận để giảm số vòng sửa ở Bước 08.
- **Trạng thái nghiệm thu cuối (Theo Luật bắt buộc số 3 Đề 01)**: Hệ thống **không tự tuyên bố ĐẠT thay người duyệt cuối** → Đặt trạng thái: `CHO_NGUOI_HOAC_GIAM_KHAO_DOC_LAP_NGHIEM_THU`.

---

## 4. TOÀN VĂN BẢN HOÀN CHỈNH SAU BIÊN TẬP (GỬI SANG BIG MODULE 2 MEDIA HOÁ)

Bảy mươi tám phần trăm doanh nghiệp vừa và nhỏ tại Việt Nam đã có nhân sự sử dụng các công cụ trí tuệ nhân tạo hàng ngày trong năm 2026 [N01]. Tuy nhiên, sự thiếu vắng một hành lang bảo mật rõ ràng đang đẩy các bản hợp đồng thương mại và số liệu tài chính nội bộ vào nguy cơ rò rỉ trực tiếp qua tài khoản cá nhân miễn phí [N01].

Kết quả đối chiếu từ các cuộc kiểm toán an ninh năm 2026 của tôi cùng nhóm chuyên gia cho thấy cứ mười tương tác của người lao động với mô hình ngôn ngữ bên ngoài thì có bốn lượt chạm trực tiếp đến thông tin nhạy cảm của tổ chức [N05]. Trong đó, hơn một phần mười lượng văn bản dán vào khung trò chuyện chứa đựng mã nguồn, danh sách khách hàng trọng điểm hoặc phương án giá thầu chưa công bố [N05]. Đáng báo động hơn, bảy mươi lăm phần trăm tiện ích mở rộng tích hợp trí tuệ nhân tạo trên trình duyệt web đang đòi quyền đọc toàn bộ nội dung màn hình [N05]. Kẽ hở này tạo ra lỗ hổng thu thập thông tin ngầm vượt khỏi tầm giám sát của tường lửa truyền thống [N05].

Nhiều hội đồng quản trị lựa chọn giải pháp tình thế là ra quy chế cấm nhân viên truy cập các trang công cụ tạo sinh trên mạng nội bộ [N01]. Thực tế vận hành tại Hà Nội và TP.HCM chứng minh biện pháp ngăn chặn đơn thuần chỉ đẩy người lao động chuyển sang dùng thiết bị di động cá nhân và làm tăng mức độ mất kiểm soát [N01]. Các tổ chức chỉ ra lệnh cấm trên giấy mà không cấp công cụ thay thế an toàn vẫn ghi nhận tỷ lệ dùng chui ngoài luồng rất cao [N05]. Đồng thời, ba mươi mốt phần trăm đơn vị hoàn toàn bất lực khi cần truy vết sự cố thất thoát tài liệu mật [N05].

Để giải quyết tận gốc bài toán bảo mật mà không làm đình trệ tốc độ xử lý công việc của các phòng ban, tôi khuyến nghị ban điều hành thiết lập ngay kiến trúc quản trị thông tin hai lớp gắn liền với cổng kiểm định đầu ra [N07]. Ở lớp xanh phục vụ nghiên cứu thị trường, soạn thảo thư tín tiêu chuẩn và xây dựng khung bài giảng, công ty trang bị cổng truy cập chính danh đã khóa chức năng thu thập lịch sử huấn luyện [N05]. Giải pháp hạ tầng này giúp đơn vị giảm tám mươi chín phần trăm hành vi tự ý sử dụng phần mềm trôi nổi [N05].

Ở lớp đỏ bao gồm báo cáo tài chính, hồ sơ nhân sự và điều khoản pháp lý, mọi văn bản bắt buộc đi qua bước khử định danh tự động [N08]. Hệ thống lọc sẽ thay thế toàn bộ tên pháp nhân cùng con số nhạy cảm bằng mã tham chiếu nội bộ trước khi thực hiện thao tác phân tích cấu trúc [N08]. Việc kết hợp quy chế phân vùng hai lớp với chương trình huấn luyện thực hành tại chỗ trong chín mươi ngày đã mang lại kết quả rõ rệt [N09]. Bộ mười bảy luật kiểm tra tự động giúp các đơn vị thí điểm giảm sáu mươi tám phần trăm tỷ lệ sai sót quy trình [N09].
