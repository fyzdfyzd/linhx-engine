// Nguồn Typst chuẩn LAB028 + LAB046 — Nhận diện tạm: Sakedemy (LAB043)
#set page(paper: "a4", margin: (top: 22mm, bottom: 24mm, x: 18mm))
#set text(font: "Be Vietnam Pro", size: 10pt, fill: rgb("#414141"), lang: "vi")
#align(left)[
  #text(fill: rgb("#118056"), weight: "bold", size: 9pt)[SAKÉDEMY · KHI SÁNG TẠO GẶP CÔNG NGHỆ · NHẬN DIỆN TẠM LAB043] \
  #text(fill: rgb("#02403B"), weight: "bold", size: 20pt)[Báo cáo mẫu: Kiểm toán Rủi ro Shadow AI và Khung Quản trị Dữ liệu Hai Lớp cho Doanh nghiệp vừa và nhỏ Việt Nam 2026]
]
#v(8pt)
#image("agy_anh_goc_sakedemy.jpg", width: 100%)
#v(8pt)
#image("04-hinh/H01.svg", width: 100%)
#v(8pt)
Bảy mươi tám phần trăm doanh nghiệp vừa và nhỏ tại Việt Nam đã có nhân sự sử dụng các công cụ trí tuệ nhân tạo hàng ngày trong năm 2026. Tuy nhiên, sự thiếu vắng một hành lang bảo mật rõ ràng đang đẩy các bản hợp đồng thương mại và số liệu tài chính nội bộ vào nguy cơ rò rỉ trực tiếp qua tài khoản cá nhân miễn phí.

Kết quả đối chiếu từ các cuộc kiểm toán an ninh năm 2026 của tôi cùng nhóm chuyên gia cho thấy cứ mười tương tác của người lao động với mô hình ngôn ngữ bên ngoài thì có bốn lượt chạm trực tiếp đến thông tin nhạy cảm của tổ chức. Trong đó, hơn một phần mười lượng văn bản dán vào khung trò chuyện chứa đựng mã nguồn, danh sách khách hàng trọng điểm hoặc phương án giá thầu chưa công bố. Đáng báo động hơn, bảy mươi lăm phần trăm tiện ích mở rộng tích hợp trí tuệ nhân tạo trên trình duyệt web đang đòi quyền đọc toàn bộ nội dung màn hình. Kẽ hở này tạo ra lỗ hổng thu thập thông tin ngầm vượt khỏi tầm giám sát của tường lửa truyền thống.

Nhiều hội đồng quản trị lựa chọn giải pháp tình thế là ra quy chế cấm nhân viên truy cập các trang công cụ tạo sinh trên mạng nội bộ. Thực tế vận hành tại Hà Nội và TP.HCM chứng minh biện pháp ngăn chặn đơn thuần chỉ đẩy người lao động chuyển sang dùng thiết bị di động cá nhân và làm tăng mức độ mất kiểm soát. Các tổ chức chỉ ra lệnh cấm trên giấy mà không cấp công cụ thay thế an toàn vẫn ghi nhận tỷ lệ dùng chui ngoài luồng rất cao. Đồng thời, ba mươi mốt phần trăm đơn vị hoàn toàn bất lực khi cần truy vết sự cố thất thoát tài liệu mật.

Để giải quyết tận gốc bài toán bảo mật mà không làm đình trệ tốc độ xử lý công việc của các phòng ban, tôi khuyến nghị ban điều hành thiết lập ngay kiến trúc quản trị thông tin hai lớp gắn liền với cổng kiểm định đầu ra. Ở lớp xanh phục vụ nghiên cứu thị trường, soạn thảo thư tín tiêu chuẩn và xây dựng khung bài giảng, công ty trang bị cổng truy cập chính danh đã khóa chức năng thu thập lịch sử huấn luyện. Giải pháp hạ tầng này giúp đơn vị giảm tám mươi chín phần trăm hành vi tự ý sử dụng phần mềm trôi nổi.

Ở lớp đỏ bao gồm báo cáo tài chính, hồ sơ nhân sự và điều khoản pháp lý, mọi văn bản bắt buộc đi qua bước khử định danh tự động. Hệ thống lọc sẽ thay thế toàn bộ tên pháp nhân cùng con số nhạy cảm bằng mã tham chiếu nội bộ trước khi thực hiện thao tác phân tích cấu trúc. Việc kết hợp quy chế phân vùng hai lớp với chương trình huấn luyện thực hành tại chỗ trong chín mươi ngày đã mang lại kết quả rõ rệt. Bộ mười bảy luật kiểm tra tự động giúp các đơn vị thí điểm giảm sáu mươi tám phần trăm tỷ lệ sai sót quy trình.

