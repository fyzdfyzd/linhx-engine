# BÀI HỌC RÚT RA TỪ VÒNG 1 (`VONG/VONG_1_BAI_HOC.md`) — `01_MAY_TAO_NOI_DUNG`

- **Phiên đọc độc lập Vòng 1**: Subagent `609b5d9c-cc70-4b04-aea8-0c9ea6b1a84c` · Điểm thẩm mỹ: **`6.2 / 10`** · Lỗi: **`2` CHẶN / `3` NÊN SỬA**.
- **Mã kiến thức ghi vào `_KIEN_THUC/INDEX.md`**: `KT-01-V1`

## 3 Bài Học Cốt Lõi Cho Vòng 2

1. **Bài học 1 (Quy tắc 1 việc chính & 1 nút chính trên mỗi màn hình — Khắc phục `[V1-CHAN-01]` & `[V1-CHAN-02]`)**:
   - Không bao giờ phơi bày đồng thời cả Khung soạn bài mới lẫn danh sách 17 thẻ thư viện ấn phẩm mở bung trên màn hình đầu tiên (`80` phần tử bấm được và `18` nút `.primary` tranh chấp thị giác).
   - Giải pháp chuẩn Substack/Notion Studio: Màn hình chính chỉ giữ đúng 1 việc chính (**Chọn thể loại → Dán đề bài → Bấm 1 nút chính `Lập 3 Phương Án Dàn Ý`**). Toàn bộ *Hàng bài 7 ngày chờ Vân Anh duyệt* và *Thư viện ấn phẩm đã xuất bản* phải đóng gói gọn trong thẻ `<details>` (*Xem thêm...*) đóng mặc định.
2. **Bài học 2 (Phân cấp thị giác ở màn hình Chọn 1 trong 3 dàn ý — Khắc phục `[V1-CHAN-01]`)**:
   - Ở màn hình Bước 2 (`#khu-vuc-3-dan-y`), chỉ phương án được đề xuất tốt nhất mới được mang nút chính (`.primary-btn` nền xanh đậm `#02403B`); hai phương án còn lại phải dùng nút phụ nền trắng viền nhạt (`.secondary-btn`), đồng thời thu gọn nhận xét dài của độc giả ảo vào `<details>`.
3. **Bài học 3 (Chuẩn công thái học `>= 14px` & vùng chạm `>= 44px` — Khắc phục `[V1-NEN-01..03]`)**:
   - Mọi nhãn phụ, huy hiệu trạng thái và nút bấm trên cả `1440px` lẫn `390px` phải có `font-size >= 14px` và `min-height: 44px; min-width: 44px`. Loại bỏ ảnh vuông phụ có chữ nhỏ ở mép dưới, chỉ hiển thị ảnh bìa chính sạch 100% chữ kỹ thuật.
