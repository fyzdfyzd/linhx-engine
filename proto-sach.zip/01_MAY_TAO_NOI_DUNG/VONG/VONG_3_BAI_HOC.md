# VÒNG 3 — BÀI HỌC TỰ SỬA & NGHIỆM THU (`VONG_3_BAI_HOC.md`)

- **Bộ sản phẩm**: `01_MAY_TAO_NOI_DUNG`
- **Vòng**: 3 (`2026-10-25 17:55`)
- **Phiên đọc độc lập (`609b5d9c-cc70-4b04-aea8-0c9ea6b1a84c`)**: Chấm điểm thẩm mỹ **`9.5 / 10`** (`>= 8.0/10`), xác nhận **`0` lỗi CHẶN, `0` lỗi NÊN SỬA, `0` lỗi cũ quay lại**.

---

## 1. Kết quả kiểm chứng sau khi sửa hết lỗi Vòng 2

1. **Quy tắc "Đúng 1 nút chính trên toàn màn hình tại mọi bước" (`[V2-NEN-01]` -> ĐẠT TUYỆT ĐỐI)**:
   - Tại màn chính (`initial`): `primaryButtonCount = 1` (`✨ Lên 3 phương án dàn ý`).
   - Tại màn chọn dàn ý (`outlines`): `primaryButtonCount = 1` (`✓ Chọn Phương Án B (Đề xuất)`), nút ở Bước 1 tự động hạ xuống `.secondary-btn`.
   - Tại màn nhận bài & ấn phẩm (`result`): `primaryButtonCount = 1` (`📄 Mở Trang Đọc Tạp Chí (HTML)`), nút ở Bước 2 tự động hạ xuống `.secondary-btn`.
2. **Quy tắc "Không có chữ nào dưới `14px` kể cả trong biểu đồ SVG nhúng" (`[V2-NEN-02]` -> ĐẠT TUYỆT ĐỐI)**:
   - `smallFontCount = 0` trên cả 4 trạng thái (`initial`, `outlines`, `result`, `reader`) ở cả `1440px` và `390px`.
3. **Kỷ luật giới hạn API thật (`<= 5` lượt gọi API Gemini thật)**:
   - Toàn bộ 3 vòng (`17:26 -> 17:55`) sử dụng đúng **`5 / 5` lượt gọi Gemini 2.5 Flash thật** (`cached=false`: `4` lượt ở Vòng 1 và `1` lượt ở Vòng 3; Vòng 2 dùng `0` lượt live nhờ Semantic Ledger Cache), tổng cộng **`22,792` token API thật** (`11,491` token vào + `11,301` token ra).

---

## 2. Bài học cốt lõi rút ra sau 3 vòng (`KT-01-V3`)
- Khi thiết kế luồng nhiều bước trên cùng một trang (Single-Page Progressive Disclosure), mỗi khi mở bước `N+1` phải chủ động đổi class của nút hành động ở bước `N` từ `.primary-btn` sang `.secondary-btn` để mắt người dùng luôn chỉ nhìn thấy đúng **1 điểm nhấn hành động duy nhất** trên màn hình.
- Các tài nguyên đồ hoạ nhúng trực tiếp vào DOM (như `<svg>` inline) chịu cùng quy tắc kiểm tra kích thước chữ của trình duyệt; do đó bộ sinh SVG (`media_hoa.py`) phải đặt `font-size >= 14px` với `viewBox` đủ rộng ngay từ gốc.
