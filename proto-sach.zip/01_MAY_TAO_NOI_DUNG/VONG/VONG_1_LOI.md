# DANH SÁCH LỖI VÒNG 1 (`VONG/VONG_1_LOI.md`) — `01_MAY_TAO_NOI_DUNG`

- **Thời gian chạy Vòng 1**: `2026-10-25 17:31` → `2026-10-25 17:35`
- **Số đo tự động từ Playwright (`VONG/vong_1_metrics.json`)**:
  - Số phần tử bấm được trên màn chính (`1440px`): **`80`**
  - Số nút chính (`.primary-btn`, `.pub-btn.primary`) hiển thị cùng lúc trên màn chính: **`18`**
  - Số cú bấm cho việc chính: **`2`**
  - Số phần tử chữ `< 14px`: **`388`**
  - Số chỗ bấm `< 44px`: **`78` (`1440px`) / `80` (`390px`)**
  - Tràn ngang `1440px` / `390px`: **`0px` / `0px`**
  - Lỗi Console: **`0`**
- **Bộ ảnh chụp màn hình Vòng 1**: `BAO_CAO/anh_cong_a/vong_1/01..04_1440px_*.png` và `01..04_390px_*.png`

---

## 1. Lỗi mức `CHẶN` (`2` lỗi — Trượt mục 1 & mục 2 trong 10 tiêu chí Thẩm mỹ & Tối giản Mục 13)

### `[V1-CHAN-01]` Màn hình chính có tới `18` nút mang kiểu nút chính (`.primary-btn` & `.pub-btn.primary`) và màn hình 3 dàn ý có `3` nút chọn ngang hàng nhau
- **Mức độ**: `CHẶN` (Vi phạm tiêu chí 1 Mục 13: *"Mỗi màn hình chỉ có 1 việc chính và 1 nút chính. Nút phụ phải nhạt hơn hẳn nút chính"*).
- **Ảnh bằng chứng**:
  - `BAO_CAO/anh_cong_a/vong_1/01_1440px_man_chinh_dan_de.png`
  - `BAO_CAO/anh_cong_a/vong_1/02_1440px_xem_3_dan_y.png`
- **Mô tả chi tiết**:
  - Khi mở màn hình chính, ngoài nút `#btn-tao-dan-y` (*Lập 3 Phương Án Dàn Ý*), cả 17 thẻ trong *Thư Viện Ấn Phẩm Đã Xuất Bản* bên dưới đều hiển thị nút *Đọc Toàn Văn* với class `.pub-btn.primary` (nền xanh đậm `#02403B`, chữ trắng), tạo ra 18 nút chính tranh chấp thị giác.
  - Khi sang Bước 2 (*Xem 3 phương án dàn ý*), cả 3 nút `Chọn Phương Án A/B/C` đều tô nền xanh lá `#6EB264` giống hệt nhau, không phân biệt nút chính (phương án đề xuất tốt nhất) và 2 nút phụ (nền trắng viền nhạt).

### `[V1-CHAN-02]` Màn hình chính phơi bày `80` phần tử bấm được cùng lúc, chưa ẩn nội dung phụ sau *"Xem thêm"* (`<details>`)
- **Mức độ**: `CHẶN` (Vi phạm tiêu chí 1, 2 & 8 Mục 13: *"Mỗi màn hình chỉ có 1 việc chính... Nội dung nào không cần ngay thì ẩn sau Xem thêm"*).
- **Ảnh bằng chứng**:
  - `BAO_CAO/anh_cong_a/vong_1/01_1440px_man_chinh_dan_de.png`
  - `BAO_CAO/anh_cong_a/vong_1/01_390px_man_chinh_dan_de.png`
- **Mô tả chi tiết**:
  - Màn hình chính đang hiển thị đồng thời cả Khung soạn bài mới, 3 nút gợi ý đề mẫu, 6 nút lọc thể loại và 68 nút hành động của 17 thẻ thư viện ấn phẩm (`80` phần tử bấm được). Người mới vào bị ngợp thông tin thay vì chỉ tập trung vào 1 việc duy nhất: **Chọn thể loại → Dán đề bài → Bấm Lập 3 Phương Án Dàn Ý**.

---

## 2. Lỗi mức `NÊN SỬA` (`3` lỗi)

### `[V1-NEN-01]` Có `388` phần tử chữ `< 14px` và `78–80` chỗ bấm `< 44px`
- **Mức độ**: `NÊN SỬA` (Vi phạm tiêu chí 6 Mục 13: *"Khổ 390px không bị tràn ngang, chữ không dưới 14px, chỗ bấm không nhỏ hơn 44px"*).
- **Ảnh bằng chứng**: `BAO_CAO/anh_cong_a/vong_1/01_390px_man_chinh_dan_de.png`, `02_390px_xem_3_dan_y.png`.
- **Mô tả chi tiết**: Các class `.brand-sub`, `.step-pill`, `.chip-btn`, `.outline-badge`, `.outline-score`, `.outline-secs`, `.persona-mini`, `.pub-type-tag`, `.pub-meta`, `.quality-pill`, `.pub-btn` đang đặt `font-size` từ `12px` đến `13.5px`; chiều cao các nút `.chip-btn`, `.select-outline-btn`, `.action-link`, `.pub-btn`, `.filter-btn` chỉ đạt `30px–38px` (`< 44px`).

### `[V1-NEN-02]` Ảnh đồ hoạ vuông `sakedemy_post_1080x1080.png` hiển thị ở màn kết quả còn dòng chữ nhỏ chứa mã `LAB043` ở chân ảnh
- **Mức độ**: `NÊN SỬA` (Tiêu chí 3 Mục 13: *"Không lộ chữ kỹ thuật"*).
- **Ảnh bằng chứng**: `BAO_CAO/anh_cong_a/vong_1/03_1440px_nhan_bai_va_pdf_anh.png`.
- **Mô tả chi tiết**: Khung preview media ở Bước 3 đang hiển thị cả 2 ảnh (`sakedemy_banner_1200x630.png` và `sakedemy_post_1080x1080.png`), trong đó ảnh thứ hai còn dòng chữ nhỏ ở đáy từ bản render cũ. Chỉ cần hiển thị 1 ảnh bìa chính (`sakedemy_banner_1200x630.png` hoặc `agy_anh_goc_sakedemy.jpg`) sạch 100% chữ kỹ thuật và ẩn các tài sản phụ vào `<details>` *Xem thêm tài liệu & đồ hoạ đi kèm*.

### `[V1-NEN-03]` Màn kết quả xuất bản (`#ket-qua-xuat-ban`) hiển thị 4 nút liên kết ngang nhau và toàn văn dài chưa thu gọn hợp lý
- **Mức độ**: `NÊN SỬA` (Tiêu chí 1 & 8 Mục 13).
- **Ảnh bằng chứng**: `BAO_CAO/anh_cong_a/vong_1/03_1440px_nhan_bai_va_pdf_anh.png`.
- **Mô tả chi tiết**: Khi nhận bài hoàn chỉnh, cần làm nổi bật đúng 1 nút chính (`🖨️ Xem & Tải Bản In PDF` hoặc `📄 Mở Trang Đọc Tạp Chí`), các liên kết tải `.docx` / ảnh bìa đặt làm nút phụ viền nhạt.
