# DANH SÁCH LỖI VÒNG 2 (`VONG/VONG_2_LOI.md`) — `01_MAY_TAO_NOI_DUNG`

- **Thời gian chạy Vòng 2**: `2026-10-25 17:40` → `2026-10-25 17:45`
- **Đã đọc bài học Vòng 1 trước khi chạy**: `VONG/VONG_1_BAI_HOC.md` (`KT-01-V1`)
- **Số đo tự động từ Playwright (`VONG/vong_2_metrics.json`)**:
  - Số phần tử bấm được trên màn chính (`1440px`): **`5`** *(Giảm mạnh từ `80` ở Vòng 1 → `5` ở Vòng 2)*
  - Số nút chính (`.primary-btn`) trên màn chính: **`1`** *(Giảm từ `18` ở Vòng 1 → `1` ở Vòng 2)*
  - Số cú bấm cho việc chính: **`2`**
  - Số phần tử chữ `< 14px` trên màn chính / màn dàn ý / màn kết quả: **`0`** *(Giảm từ `388` ở Vòng 1 → `0` ở Vòng 2)*
  - Số chỗ bấm `< 44px` ở cả `1440px` và `390px`: **`0`** *(Giảm từ `78–80` ở Vòng 1 → `0` ở Vòng 2)*
  - Tràn ngang `1440px` / `390px`: **`0px` / `0px`**
  - Lỗi Console: **`0`**
  - Lỗi cũ quay lại: **`0`**
- **Bộ ảnh chụp màn hình Vòng 2**: `BAO_CAO/anh_cong_a/vong_2/01..04_1440px_*.png` và `01..04_390px_*.png`

---

## 1. Lỗi mức `CHẶN` (`0` lỗi)
- Đã khắc phục triệt để cả 2 lỗi `CHẶN` của Vòng 1 (`[V1-CHAN-01]`, `[V1-CHAN-02]`). Màn hình chính hiện chỉ còn đúng **5 phần tử bấm được** và **1 nút chính duy nhất** (`#btn-tao-dan-y`).

---

## 2. Lỗi mức `NÊN SỬA` (`2` lỗi còn lại cần tinh chỉnh cho Vòng 3)

### `[V2-NEN-01]` Khi chuyển sang Bước 2 (Xem 3 dàn ý) và Bước 3 (Nhận bài xuất bản), nút chính của bước trước vẫn giữ màu nền đậm `.primary-btn` (`primaryButtonCount: 2` ở Bước 2, `3` ở Bước 3)
- **Mức độ**: `NÊN SỬA`
- **Ảnh bằng chứng**: `BAO_CAO/anh_cong_a/vong_2/02_1440px_xem_3_dan_y.png`, `03_1440px_nhan_bai_va_pdf_anh.png`.
- **Mô tả & Hướng sửa cho Vòng 3**: Khi khu vực Bước 2 (`#khu-vuc-3-dan-y`) mở ra, cần tự động chuyển nút `#btn-tao-dan-y` của Bước 1 về kiểu nút phụ `.secondary-btn` (*"Lập lại 3 dàn ý khác"*). Khi khu vực Bước 3 (`#ket-qua-xuat-ban`) mở ra, tự động thu gọn khu vực 3 dàn ý hoặc chuyển nút `#btn-chon-B` về `.secondary-btn` để tại mọi thời điểm (`initial`, `outlines`, `result`) toàn trang luôn chỉ có **đúng `1` nút `.primary-btn` duy nhất**.

### `[V2-NEN-02]` Trang đọc tạp chí riêng (`04_1440px_trang_doc_tap_chi_html.png`) còn `20` thẻ `<text>` bên trong biểu đồ SVG có cỡ chữ `8px–8.5px` (`< 14px`)
- **Mức độ**: `NÊN SỬA`
- **Ảnh bằng chứng**: `BAO_CAO/anh_cong_a/vong_2/04_1440px_trang_doc_tap_chi_html.png`.
- **Mô tả & Hướng sửa cho Vòng 3**: Bổ sung quy tắc CSS `svg text { font-size: 14px !important; }` và chuẩn hoá cỡ chữ trong `H01.svg` / `H02.svg` trên trang đọc tạp chí để đạt `0` phần tử chữ `< 14px` trên cả trang đọc riêng.
