# BÀI HỌC RÚT RA TỪ VÒNG 2 (`VONG/VONG_2_BAI_HOC.md`) — `01_MAY_TAO_NOI_DUNG`

- **Phiên đọc độc lập Vòng 2**: Subagent `609b5d9c-cc70-4b04-aea8-0c9ea6b1a84c` · Điểm thẩm mỹ: **`8.6 / 10`** *(Tăng từ `6.2/10` ở Vòng 1)* · Lỗi: **`0` CHẶN / `2` NÊN SỬA**.
- **Mã kiến thức ghi vào `_KIEN_THUC/INDEX.md`**: `KT-01-V2`

## 2 Bài Học Tinh Chỉnh Cho Vòng 3

1. **Bài học 1 (Chuyển giao trạng thái nút chính `.primary-btn` giữa các bước trên cùng một trang — Khắc phục `[V2-NEN-01]`)**:
   - Trong luồng đa bước nối tiếp trên cùng 1 trang (`Bước 1: Dán đề` → `Bước 2: Chọn 1 trong 3 dàn ý` → `Bước 3: Nhận bài`), khi bước sau mở ra thì nút hành động của bước trước đã hoàn thành nhiệm vụ. Nếu giữ nguyên class `.primary-btn` ở bước cũ, trên màn hình sẽ có 2–3 nút nền đậm cùng lúc.
   - Giải pháp: Khi Bước 2 hiển thị, tự động hạ cấp nút `#btn-tao-dan-y` của Bước 1 về `.secondary-btn`. Khi Bước 3 hiển thị, tự động hạ cấp nút `#btn-chon-B` của Bước 2 về `.secondary-btn`, đảm bảo tại **mọi thời điểm toàn trang luôn có đúng `1` nút `.primary-btn` duy nhất** (`primaryButtonCount = 1`).
2. **Bài học 2 (Đồng bộ quy tắc `font-size >= 14px` vào cả các thẻ `<text>` bên trong biểu đồ SVG nhúng — Khắc phục `[V2-NEN-02]`)**:
   - Kiểm tra cỡ chữ không chỉ dừng ở các thẻ HTML trên giao diện chính mà phải áp dụng cả cho các nhãn `<text>` bên trong biểu đồ SVG nhúng trên trang đọc tạp chí (`svg text { font-size: 14px !important; }`), đưa số phần tử chữ `< 14px` trên cả trang đọc riêng về `0`.
