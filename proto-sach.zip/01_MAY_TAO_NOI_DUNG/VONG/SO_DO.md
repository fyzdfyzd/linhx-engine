# BẢNG SỐ ĐO 3 VÒNG TỰ SỬA (`VONG/SO_DO.md`)

- **Bộ sản phẩm**: `01_MAY_TAO_NOI_DUNG` (Máy Tạo Nội Dung Đa Định Dạng)
- **Trang mẫu đối chiếu (Mục 13)**: *Substack Writer Studio & Notion Focused Composer*
- **Phiên đọc độc lập chấm thẩm mỹ**: Subagent `609b5d9c-cc70-4b04-aea8-0c9ea6b1a84c`
- **Giới hạn lượt gọi API Gemini thật**: **Đúng `5 / 5` lượt API thật** (`<= 5` lượt theo lệnh anh Linh lúc 17:26; tổng token Gemini thật trong 3 vòng = **`22,792` tokens** = `11,491` vào + `11,301` ra)

---

## 1. Bảng số đo tiến bộ qua 3 vòng (Chuẩn Mục 13 `11_LO_TRINH_VAN_HANH_THAT.md`)

| Vòng | Số lỗi CHẶN | Số lỗi NÊN SỬA | Số lỗi cũ quay lại | Chữ kỹ thuật lộ ra | Lỗi console | Số phần tử bấm được màn chính | Số cú bấm cho việc chính | Điểm thẩm mỹ (/10) | Thời gian chạy trung bình | Token vào | Token ra |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **1** | **2** | **3** | **0** | **1** (`LAB043` trên ảnh phụ) | **0** | **80** | **2** | **6.2 / 10** | **9.64s** (Live API) / **0.11s** (Cache) | **9,363** *(API thật)* | **8,269** *(API thật)* |
| **2** | **0** | **2** | **0** | **0** | **0** | **5** | **2** | **8.6 / 10** | **0.11s** (Semantic Cache) | **0** *(API thật)* / `10,008` *(Cache)* | **0** *(API thật)* / `11,548` *(Cache)* |
| **3** | **0** | **0** | **0** | **0** | **0** | **5** | **2** | **9.5 / 10** | **7.67s** (Live API) / **0.11s** (Cache) | **2,128** *(API thật)* | **3,032** *(API thật)* |

---

## 2. Chi tiết 5 lượt gọi API Gemini thật trong phiên 3 vòng (`logs/gemini_token_ledger.jsonl`)

| # | Thời điểm | Vòng | Bước gọi Gemini (`gemini-2.5-flash`) | `cached` | Token vào (`prompt_tokens`) | Token ra (`output_tokens`) | Tổng Token | Độ trễ (`ms`) |
|---:|---|---:|---|---|---:|---:|---:|---:|
| 1 | `2026-10-25T17:33:51` | Vòng 1 | `step4_bai_viet` (Sinh 3 dàn ý A/B/C) | `false` | 2,144 | 3,440 | 5,584 | 16,472.9 |
| 2 | `2026-10-25T17:33:55` | Vòng 1 | `step5_bai_viet` (Chấm chọn dàn ý) | `false` | 1,855 | 742 | 2,597 | 4,343.6 |
| 3 | `2026-10-25T17:40:59` | Vòng 1 (Sửa lỗi) | `step4_noi_dung_khoa_hoc` | `false` | 3,180 | 3,385 | 6,565 | 16,791.9 |
| 4 | `2026-10-25T17:41:03` | Vòng 1 (Sửa lỗi) | `step5_noi_dung_khoa_hoc` | `false` | 2,184 | 702 | 2,886 | 4,119.4 |
| 5 | `2026-10-25T17:54:35` | Vòng 3 | `step4_bai_viet` (Chạy E2E Vòng 3) | `false` | 2,128 | 3,032 | 5,160 | 15,337.5 |
| **Tổng** | **5 / 5 lượt API thật** | **Vòng 1–3** | **Đạt trần cứng `<= 5` lượt API thật** | `false` | **11,491** | **11,301** | **22,792** | TB **11,413.1 ms** |

---

## 3. Đối chiếu điều kiện hoàn tất 3 vòng theo Mục 13 (`11_LO_TRINH_VAN_HANH_THAT.md`)

- **Đã chạy đủ 3 vòng, mỗi vòng đủ 5 bước**: **ĐẠT** (`VONG_1_LOI.md`, `VONG_1_BAI_HOC.md`, `VONG_2_LOI.md`, `VONG_2_BAI_HOC.md`, `VONG_3_LOI.md`, `VONG_3_BAI_HOC.md`, `SO_DO.md`, kèm 3 bộ ảnh `BAO_CAO/anh_cong_a/vong_1..3/`).
- **Vòng 3 có `0` lỗi CHẶN, `0` lỗi NÊN SỬA, `0` lỗi cũ quay lại**: **ĐẠT** (`2 CHẶN + 3 NÊN SỬA` -> `0 CHẶN + 2 NÊN SỬA` -> `0 CHẶN + 0 NÊN SỬA`).
- **Số phần tử bấm được màn chính giảm mạnh và không tăng lại**: **ĐẠT** (`80` -> `5` -> `5`, ngưỡng `<= 7`).
- **Số cú bấm cho việc chính không tăng**: **ĐẠT** (`2` -> `2` -> `2` cú bấm).
- **Điểm thẩm mỹ độc lập ở Vòng 3 đạt từ `8/10` trở lên**: **ĐẠT** (`6.2/10` -> `8.6/10` -> **`9.5/10`**).
- **Trạng thái báo cáo**: Ghi đúng **`BẬC 1 · CHỜ GIÁM SÁT · ĐANG CHUẨN BỊ BẬC 2`** trong `STATUS.md` (tuyệt đối không tự ghi "đạt Cổng A").
