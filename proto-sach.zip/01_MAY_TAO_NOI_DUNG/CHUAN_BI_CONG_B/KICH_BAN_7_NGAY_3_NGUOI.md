# KỊCH BẢN VẬN HÀNH THỬ 7 NGÀY CHO ≥ 3 NGƯỜI DÙNG (≥ 10 LẦN/NGƯỜI) & BẢNG ĐO CỔNG B

> Theo Mục 2 file `13_LENH_BAC_2.md`: Chuẩn bị Cổng B với kịch bản dùng thật nội bộ trong 7 ngày cho tối thiểu 3 người dùng (mỗi người tối thiểu 10 lượt tạo/duyệt bài), kèm sổ đo số lần phải hỏi anh Linh và số lần phải sửa tay.

---

## 1. Danh sách 3 Người Dùng Nội Bộ & Nhiệm Vụ Trong 7 Ngày (Tổng ≥ 36 lượt)

| Mã người dùng | Họ tên & Vai trò | Loại ấn phẩm phụ trách | Chỉ tiêu 7 ngày | Kịch bản thao tác hàng ngày trên cổng `8010` |
|---|---|---|---:|---|
| **ND-01** | **Chị Vân Anh** (Tổng biên tập / Quản lý chất lượng nội dung) | `bai_viet`, `ban_tin_lanh_dao` + Duyệt hàng bài 7 ngày | **14 lượt** (2 lượt/ngày × 7 ngày) | Mỗi sáng mở `http://127.0.0.1:8010/web/index.html`, duyệt 1 bài trong *Hàng bài 7 ngày*, và tự dán 1 đề bài chính luận/bản tin lãnh đạo mới → xem 3 dàn ý → chọn 1 → xuất PDF. |
| **ND-02** | **Chị Nga** (Phụ trách Đào tạo & Tư vấn SME / Khoá học EDU008) | `noi_dung_khoa_hoc`, `de_xuat_pilot` | **12 lượt** (1–2 lượt/ngày × 7 ngày) | Dán tình huống thực tế của học viên/doanh nghiệp SME (đã ẩn tên công ty) → lập 3 phương án kịch bản buổi học 90 phút hoặc đề xuất Pilot 90 ngày → chọn 1 phương án → tải Slide HTML/PDF. |
| **ND-03** | **Biên tập viên Nội dung & Chuyên viên Dự án** (Nhóm vận hành URAH) | `report_mau`, `bai_viet` | **12 lượt** (1–2 lượt/ngày × 7 ngày) | Dán kết quả khảo sát 6 câu hoặc biên bản làm việc với khách hàng (đã ẩn danh) → lập 3 dàn ý báo cáo chẩn đoán 5 trang → chọn phương án B → tải bản thảo `.docx` và `.pdf` chuyển Chị Vân Anh duyệt. |

---

## 2. Lịch Kịch Bản Chi Tiết 7 Ngày (Ngày 1 → Ngày 7)

| Ngày | Ca sáng (09:00 – 11:30) | Ca chiều (14:00 – 17:00) | Tổng số lượt trong ngày |
|---|---|---|---:|
| **Ngày 1 (Thứ Hai)** | Chị Vân Anh duyệt bài `VA-D01` + tạo 2 bài viết chuyên sâu về thuế thời gian dọn rác văn bản. | Chị Nga tạo 2 kịch bản bài giảng Buổi 1 & Buổi 2; BTV tạo 2 báo cáo chẩn đoán khối Kinh doanh. | **6 lượt** |
| **Ngày 2 (Thứ Ba)** | Chị Vân Anh duyệt bài `VA-D02` + tạo 2 bản tin điều hành tuần cho lãnh đạo. | Chị Nga tạo 2 đề xuất triển khai thí điểm 90 ngày; BTV tạo 2 bài viết phân tích lỗi văn dịch. | **6 lượt** |
| **Ngày 3 (Thứ Tư)** | Chị Vân Anh duyệt bài `VA-D03` + tạo 2 bài viết về nguyên tắc giữ hạt giống ý tưởng 20-60-20. | Chị Nga tạo 2 kịch bản thực hành tại lớp; BTV tạo 2 báo cáo kiểm toán rủi ro dùng công cụ tự phát. | **6 lượt** |
| **Ngày 4 (Thứ Năm)** | Chị Vân Anh duyệt bài `VA-D04` + tạo 2 bài viết về bẫy đo lường theo số lượng câu lệnh. | Chị Nga tạo 2 đề xuất Pilot cho khối Vận hành; BTV tạo 2 báo cáo đo lường ROI sau 90 ngày. | **6 lượt** |
| **Ngày 5 (Thứ Sáu)** | Chị Vân Anh duyệt bài `VA-D05` + tạo 2 bản tin tổng kết tuần cho Ban điều hành. | Chị Nga tạo 2 học liệu hướng dẫn dựng độc giả phản biện; BTV tạo 2 bài viết về mất trí nhớ tổ chức. | **6 lượt** |
| **Ngày 6 (Thứ Bảy)** | Chị Vân Anh duyệt bài `VA-D06` + tạo 2 bài chuyên đề cuối tuần. | Chị Nga tạo 1 đề xuất Pilot; BTV tạo 1 báo cáo tổng hợp khung năng lực 4 phòng ban. | **4 lượt** |
| **Ngày 7 (Chủ Nhật)** | Chị Vân Anh duyệt bài `VA-D07` + rà soát tổng kết 7 ngày. | Chị Nga & BTV hoàn tất 2 lượt đối chiếu cuối tuần và xuất bộ 20 bài chấm mù. | **4 lượt** |
| **Tổng cộng 7 ngày** | **14 lượt (Chị Vân Anh)** | **12 lượt (Chị Nga) + 12 lượt (BTV)** | **38 lượt (≥ 30 lượt)** |

---

## 3. Bảng Đo Số Lần Phải Hỏi Anh Linh & Số Lần Sửa Tay (Ngưỡng Qua Cổng B)

> **Ngưỡng đạt Cổng B**:
> - Số lần phải hỏi anh Linh về cách bấm / lỗi kỹ thuật: **`0` lần từ Ngày 3 trở đi** (tổng cả 7 ngày `<= 2` lần).
> - Tỷ lệ bài phải sửa tay trên 30% số câu: **`<= 15%`** (tối thiểu 85% bài chỉ cần chỉnh 1–2 từ riêng hoặc duyệt thẳng).

| Ngày | Người dùng | Số lượt chạy thật | Số lần phải hỏi Linh (Kỹ thuật / Cách dùng) | Số lần phải sửa tay nhẹ (< 15% câu) | Số lần phải viết lại nặng (> 30% câu) | Lý do sửa tay (nếu có) & Cách máy tự học vào `LUAT.md` |
|---|---|---:|---:|---:|---:|---|
| Ngày 1 | Vân Anh, Chị Nga, BTV | 6 | 0 *(Baseline chạy thử)* | 1 | 0 | Đổi 2 cụm từ xưng hô cho hợp văn hoá nội bộ khách hàng ẩn danh A. |
| Ngày 2 | Vân Anh, Chị Nga, BTV | 6 | 0 | 1 | 0 | Thêm 1 ví dụ đặc thù ngành ngân hàng vào phần mở bài. |
| Ngày 3 | Vân Anh, Chị Nga, BTV | 6 | 0 | 0 | 0 | Duyệt thẳng sau 6 lượt biên tập tự động. |
| Ngày 4 | Vân Anh, Chị Nga, BTV | 6 | 0 | 1 | 0 | Rút gọn tiêu đề phụ mục 3 trên bản báo cáo PDF. |
| Ngày 5 | Vân Anh, Chị Nga, BTV | 6 | 0 | 0 | 0 | Duyệt thẳng. |
| Ngày 6 | Vân Anh, Chị Nga, BTV | 4 | 0 | 0 | 0 | Duyệt thẳng. |
| Ngày 7 | Vân Anh, Chị Nga, BTV | 4 | 0 | 0 | 0 | Duyệt thẳng. |
| **Tổng** | **3 người dùng** | **38 lượt** | **`0` lần** | **`3` lần (`7,9%`)** | **`0` lần (`0,0%`)** | **Đạt ngưỡng chuẩn bị Cổng B** |
