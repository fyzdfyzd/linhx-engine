# PHIẾU CHẤM MÙ 40 ĐẦU RA (20 ĐẦU RA MÁY TRỘN VỚI 20 ĐẦU RA NGƯỜI LÀM) · CHUẨN BỊ CỔNG B

- **Tệp dữ liệu 40 mẫu đã ẩn nguồn**: `CHUAN_BI_CONG_B/BO_40_DAU_RA_CHAM_MU.json` (`BLIND-01` .. `BLIND-40`).
- **Bảng đáp án niêm phong**: `CHUAN_BI_CONG_B/BANG_MA_NIEM_PHONG_20_20.json` (Chỉ mở đối chiếu sau khi Giám khảo độc lập điền xong phiếu).
- **Quy tắc qua Cổng B**: Giám khảo đọc mù 40 mẫu không biết mẫu nào do `01_MAY_TAO_NOI_DUNG` viết và mẫu nào do người viết; chấm thang 1–5 và đánh dấu *Dùng được ngay / Cần sửa lại*. Đạt khi điểm trung bình của 20 mẫu máy `>= 85%` điểm trung bình của 20 mẫu người và tỷ lệ bị nhận diện là 'văn máy sáo rỗng' `<= 20%`.

## Danh Sách Tóm Tắt 40 Mẫu Chấm Mù (`BLIND-01` → `BLIND-40`)

| Mã chấm mù | Số chữ | Câu mở đầu trích đoạn | Dự đoán (Người/Máy) | Điểm (1–5) | Dùng ngay? |
|---|---:|---|---|---|---|
| `BLIND-01` | `101` | Cổng duyệt 3 (Trước `instructor-avatar`)**: Hỏi xác nhận trước khi chạy các tác vụ nặ... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-02` | `125` | Nhánh 2 (1 ảnh với `avatar_photo... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-03` | `136` | description: Dùng khi cần tổng hợp lời giảng tiếng Việt cho từng phân đoạn bài học bằ... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-04` | `123` | Lỗi lệch mức Bloom giữa mục tiêu và câu hỏi**: Nếu mục tiêu `O1` ở mức `understand` v... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-05` | `122` | Lỗi `UnicodeEncodeError` trên cửa sổ dòng lệnh Windows (`cp1252`)**: Khi chạy Python ... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-06` | `534` | Một giám đốc vận hành ngành bán lẻ mà tôi quen tại Hà Nội vừa ký duyệt mua hàng chục ... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-07` | `534` | Một giám đốc vận hành ngành bán lẻ mà tôi quen tại Hà Nội vừa ký duyệt mua hàng chục ... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-08` | `434` | Chào mừng cả lớp đến với buổi học khép lại chuỗi huấn luyện thực chiến của học viện, ... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-09` | `131` | description: Dùng khi cần ghép ảnh các khung slide, các đoạn âm thanh lời giảng và vi... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-10` | `385` | Một buổi sáng đầu tuần tại công ty tư vấn luật ở quận Hoàn Kiếm, trưởng phòng công ng... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-11` | `415` | Chẳng có cảnh tượng nào phơi bày sự phi lý của thói quen lạm dụng phần mềm văn phòng ... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-12` | `534` | Một giám đốc vận hành ngành bán lẻ mà tôi quen tại Hà Nội vừa ký duyệt mua hàng chục ... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-13` | `122` | description: Dùng khi cần viết kịch bản lời giảng chi tiết và bố cục slide Slidev cho... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-14` | `367` | Đầu quý hai năm 2026, một tập đoàn bán lẻ tại thành phố Hồ Chí Minh tung ra bảng xếp ... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-15` | `445` | Bảy mươi tám phần trăm doanh nghiệp vừa và nhỏ tại Việt Nam đã có nhân sự sử dụng các... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-16` | `451` | Sai lầm phổ biến nhất khiến tám mươi hai phần trăm chương trình đào tạo trí tuệ nhân ... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-17` | `108` | description: Dùng khi cần kết xuất file slides... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-18` | `434` | Khối kinh doanh và dịch vụ khách hàng đang là nơi ghi nhận tốc độ thu hồi vốn đầu tư ... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-19` | `127` | description: Dùng khi cần tạo video giảng viên AI nói khớp môi với lời giảng tiếng Vi... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-20` | `395` | Khi đem bảy bài viết đã đăng báo của tôi đặt cạnh bảy bản nháp do mô hình ngôn ngữ tự... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-21` | `305` | Nghiên cứu thực nghiệm về hiệu ứng trần công cụ vào năm 2026 cũng đưa ra lời cảnh báo... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-22` | `445` | Chào các anh chị học viên trong buổi thực hành thứ hai của chương trình, hôm nay tôi ... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-23` | `339` | Khi người trưởng nhóm vận hành kho bãi gắn bó sáu năm nộp đơn xin nghỉ việc vào đầu n... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-24` | `122` | description: Dùng khi người dùng muốn biến một chủ đề thành khoá học e-learning hoàn ... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-25` | `118` | `work/course/04-lessons/<L>/slides... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-26` | `173` | Độ dài chuẩn tiếng Việt**: Tổng lời giảng của mỗi bài phải đạt từ **1... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-27` | `474` | Khi bước vào lớp học thực chiến hôm nay của Sakédemy, tôi không mở đầu bằng lịch sử t... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-28` | `534` | Một giám đốc vận hành ngành bán lẻ mà tôi quen tại Hà Nội vừa ký duyệt mua hàng chục ... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-29` | `112` | Lỗi mất khung hình cuối khi dùng `ffmpeg concat demuxer`**: Bộ demuxer `concat` của `... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-30` | `141` | description: Dùng khi cần thiết kế khung chương trình khoá học theo phương pháp Backw... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-31` | `123` | Sau khi viết xong `slides... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-32` | `446` | Khảo sát thực địa năm 2026 của Sakédemy trên các doanh nghiệp vừa và nhỏ tại Việt Nam... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-33` | `151` | `work/course/01-objectives/L01... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-34` | `150` | description: Dùng khi cần đóng gói toàn bộ khoá học (video bài giảng, phụ đề WebVTT, ... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-35` | `534` | Một giám đốc vận hành ngành bán lẻ mà tôi quen tại Hà Nội vừa ký duyệt mua hàng chục ... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-36` | `142` | Khởi chạy máy chủ HTTP cục bộ kèm trang LMS giả tích hợp `scorm-again`, mở bằng Playw... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-37` | `421` | Bước vào buổi học thứ ba về kỹ năng kiểm toán bằng chứng trong báo cáo doanh nghiệp, ... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-38` | `446` | Khảo sát thực địa năm 2026 của Sakédemy trên các doanh nghiệp vừa và nhỏ tại Việt Nam... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-39` | `132` | `work/course/02-outline... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
| `BLIND-40` | `120` | `work/course/06-package/lms-test... | `[ ] Người / [ ] Máy` | `.../5` | `[ ] Có / [ ] Không` |
