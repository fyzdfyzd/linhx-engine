# HƯỚNG DẪN DÙNG NHANH 1 TRANG (DÀNH CHO BIÊN TẬP VIÊN & QUẢN LÝ KHÔNG KỸ THUẬT)

> **Bàn Biên Tập Ấn Phẩm Số Sakédemy** (`http://127.0.0.1:8010/web/index.html`) giúp anh/chị biến một đề bài hoặc tình huống thực tế tại công ty thành bài viết chuyên sâu, báo cáo tư vấn hoặc bài giảng 90 phút đã qua 6 lượt biên tập độc lập chỉ với **2 cú bấm chuột**.

---

## 1. Cách mở phần mềm trên máy tính văn phòng (Máy MSI)
- Bấm đúp chuột vào tệp **`chay.bat`** trong thư mục `01_MAY_TAO_NOI_DUNG`.
- Mở trình duyệt web (Edge hoặc Chrome) và truy cập địa chỉ: **`http://127.0.0.1:8010/web/index.html`**.

---

## 2. Ba bước tạo ấn phẩm mới (Chỉ mất 2 cú bấm)

### Bước 1: Chọn thể loại & Dán đề bài
1. Ở ô **Thể loại ấn phẩm** (bên trái), chọn loại tài liệu anh/chị cần làm:
   - *Bài viết chuyên sâu (Báo chí / Tạp chí kinh tế - công nghệ)*
   - *Báo cáo mẫu chẩn đoán & tư vấn chiến lược*
   - *Nội dung khoá học thực chiến (1 buổi · Kịch bản lời giảng + Bộ Slide 16:9)*
   - *Đề xuất triển khai thí điểm 90 ngày*
   - *Bản tin điều hành hàng tuần cho lãnh đạo*
2. Ở ô **Đề bài hoặc tình huống thực tế cần biên soạn** (bên phải), dán câu hỏi, bối cảnh phòng ban hoặc yêu cầu của khách hàng (tối thiểu 15 ký tự).
3. Bấm nút màu xanh đậm **Lập 3 Phương Án Dàn Ý (A / B / C)** *(Cú bấm thứ 1)*.

### Bước 2: Xem 3 phương án dàn ý & phản hồi độc giả
- Hệ thống sẽ thiết kế **3 hướng tiếp cận khác nhau (Phương án A, B, C)** và cho 3 nhóm người đọc mục tiêu (Lãnh đạo, Quản lý cấp trung, Chuyên viên) đọc thử.
- Phương án phù hợp nhất sẽ có nhãn **★ Đề xuất tốt nhất** và nút bấm màu xanh đậm nổi bật.
- Nếu muốn đọc kỹ nhận xét của từng độc giả, bấm vào dòng *Xem thêm phản hồi độc giả mục tiêu ▾*.

### Bước 3: Chọn 1 phương án & Nhận trọn bộ bài + PDF/ảnh
- Bấm nút **Chọn Phương Án B & Xuất Bản Ấn Phẩm** (hoặc chọn A / C tuỳ ý anh/chị) *(Cú bấm thứ 2)*.
- Ngay lập tức, khung kết quả hiện ra với:
  - Nút chính **📄 Mở Trang Đọc Tạp Chí (HTML)** để xem trang dàn chuẩn thương hiệu.
  - Nút **🖨️ Xem & Tải Bản In (PDF)** để tải tệp PDF gửi trình ký hoặc in ấn.
  - Mục *Xem thêm toàn văn ấn phẩm & tải bản thảo (.DOCX) ▾* để tải tệp Word về chỉnh sửa thêm nếu cần.

---

## 3. Cách duyệt Hàng bài 7 ngày (Dành riêng cho Chị Vân Anh)
1. Cuộn xuống dưới khung soạn bài, bấm vào thanh **Xem thêm: Hàng bài 7 ngày chờ Chị Vân Anh duyệt (7 bài)**.
2. Đọc từng bài (tên khách hàng/doanh nghiệp đã được ẩn danh an toàn), bấm **Xem Trang Đọc** hoặc **Bản In PDF**, sau đó bấm nút **Bấm Duyệt Bài** để xác nhận hoàn tất duyệt.

---

## 4. Khi gặp thông báo nhắc nhở thì làm gì?
- **"Đề bài đang để trống / quá ngắn"**: Vui lòng viết rõ hơn tình huống (ít nhất 1 câu hoàn chỉnh).
- **"Từ chối thực hiện..."**: Đề bài đang chứa thông tin nhạy cảm (số tài khoản, CCCD, yêu cầu báo giá/cam kết hoàn tiền). Hãy xoá thông tin cá nhân/nhạy cảm rồi bấm lại.
- **"Dịch vụ tạm thời phản hồi chậm"**: Đề bài của anh/chị vẫn được giữ nguyên trên màn hình, chỉ cần đợi 5 giây rồi bấm lại nút **Lập 3 Phương Án Dàn Ý**.
