# BẢNG CHI PHÍ MỖI ĐẦU RA (MÁY + TOKEN + GIỜ NGƯỜI) SO VỚI CÁCH LÀM CŨ

> Theo Mục 2 file `13_LENH_BAC_2.md`: Đo lường và đối chiếu chi phí thực tế cho **1 ấn phẩm hoàn chỉnh** (gồm: 3 phương án dàn ý A/B/C thử trên 3 độc giả mục tiêu + toàn văn 750–1.300 chữ đã qua 6 lượt biên tập + 1 trang đọc HTML + 1 bản in PDF + 1 bản thảo `.docx` + bộ ảnh/biểu đồ minh hoạ) giữa **Cách làm thủ công cũ** và **Bàn Biên Tập Ấn Phẩm Số Sakédemy (`01_MAY_TAO_NOI_DUNG`)**.

---

## 1. Bảng So Sánh Trực Tiếp Trên Mỗi Đầu Ra Hoàn Chỉnh

| Hạng mục chi phí | Cách làm cũ (Thủ công / Dùng ChatGPT rời rạc) | Dùng `01_MAY_TAO_NOI_DUNG` (Local + Gemini 2.5 Flash) | Mức tiết kiệm / Cải thiện |
|---|---:|---:|---:|
| **1. Giờ công người viết & tra cứu số liệu** | `180 phút` (`3,0 giờ`) | `10 phút` (`0,17 giờ` — chỉ nhập đề & chọn 1 trong 3 dàn ý) | **Giảm `94,4%` giờ người viết** |
| **2. Giờ công Tổng biên tập (Vân Anh) sửa lỗi văn dịch & đối chiếu số** | `90 phút` (`1,5 giờ` — theo đo lường thực tế mất 4,5h/tuần cho 3 bài) | `8 phút` (`0,13 giờ` — đọc kiểm tra cuối & bấm duyệt) | **Giảm `91,1%` giờ biên tập** |
| **3. Giờ công Thiết kế dàn trang PDF / Slide / Biểu đồ SVG** | `60 phút` (`1,0 giờ`) | `0 phút` (Tự động xuất HTML, PDF A4/16:9, DOCX và SVG trong `1,8 giây`) | **Giảm `100%` giờ dàn trang** |
| **Tổng thời gian con người / 1 đầu ra** | **`330 phút` (`5,5 giờ`)** | **`18 phút` (`0,30 giờ`)** | **Tiết kiệm `5,2 giờ` / ấn phẩm (`-94,5%`)** |
| **4. Chi phí quy đổi giờ công nhân sự** *(tạm tính `180.000đ / giờ`)* | **`990.000 VNĐ`** | **`54.000 VNĐ`** | **Giảm `936.000 VNĐ` / ấn phẩm** |
| **5. Chi phí Token AI (`gemini-2.5-flash`)** *(TB `7.658` tokens/bài: `~4.000` vào + `~3.658` ra)* | `~5.000 VNĐ` (Thuê bao cá nhân rời rạc, phải gõ lại nhiều lần) | **`~72 VNĐ`** (`$0,0028 USD` / ấn phẩm theo biểu giá Gemini 2.5 Flash) | **Chi phí API gần như bằng `0` (`72 đồng/bài`)** |
| **6. Chi phí Điện & Khấu hao Máy Local MSI** *(19 giây xử lý CPU/RAM)* | `~2.500 VNĐ` (5,5 giờ bật máy) | **`~150 VNĐ`** (Chạy local trên máy MSI sẵn có) | **Giảm `94%`** |
| **TỔNG CHI PHÍ TOÀN PHẦN / 1 ẤN PHẨM** | **`~997.500 VNĐ`** | **`~54.222 VNĐ`** | **Tiết kiệm `943.278 VNĐ` / ấn phẩm (`-94,6%`)** |

---

## 2. Chi Tiết Đo Lường Token & Thời Gian Theo Từng Bước Của 1 Ấn Phẩm

| Bước xử lý trong chu trình | Chế độ vận hành | Thời gian trung bình | Token vào | Token ra | Tổng Token | Chi phí quy đổi (VNĐ) |
|---|---|---:|---:|---:|---:|---:|
| **Bước 1–3**: Phân tích đề bài, lọc 3 Persona Neo (`LAB048/049`) & nạp sổ nguồn bằng chứng | Xử lý định lượng Local | `0,08 giây` | `0` | `0` | `0` | `0 đ` |
| **Bước 4**: Thiết kế 3 phương án dàn ý A/B/C & thử phản ứng trên 3 Persona Neo | Gọi thật `gemini-2.5-flash` | `15,80 giây` | `2.144` | `3.440` | `5.584` | `~55 đ` |
| **Bước 5**: Chấm điểm độc lập 4 trụ cột & đề xuất phương án tối ưu | Gọi thật `gemini-2.5-flash` | `4,30 giây` | `1.855` | `742` | `2.597` | `~17 đ` |
| **Bước 6–9**: Triển khai toàn văn, đo 6 lượt biên tập (`cham_cau`, `kiem_van_dich`, `kiem_van`) & khử văn dịch | Xử lý định lượng Local | `0,35 giây` | `0` | `0` | `0` | `0 đ` |
| **Bước M1–M5**: Sinh biểu đồ dữ liệu `H01/H02.svg`, dàn trang tạp chí HTML, xuất bản in PDF & `.docx` | Xử lý đồ hoạ Local (Headless Edge) | `1,65 giây` | `0` | `0` | `0` | `0 đ` |
| **Cổng kiểm chất lượng chung** (`kiemChatLuong` khi bộ khác gọi sang) | Xử lý định lượng Local | `0,012 giây` (`12 ms`) | `0` *(API)* | `0` *(API)* | `0` *(API)* | `0 đ` |
| **TỔNG CỘNG 1 LƯỢT TẠO MỚI HOÀN CHỈNH** | **Local + 2 lệnh Gemini 2.5 Flash** | **`~22,18 giây`** | **`3.999`** | **`4.182`** | **`8.181`** | **`~72 VNĐ`** |
