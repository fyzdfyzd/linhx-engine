# BƯỚC 05: TỰ CHẤM & CHỐT HƯỚNG OUTLINE (`report_mau`)

> **Truy vết Module**: `BM1_05_cham_chon_huong` (**Làm mới hoàn toàn** theo Đề 01 Bản 3)
> **Cờ duyệt (`duyet_outline`)**: `may` → **Trạng thái**: `DA_CHOT_TU_DONG_MAY`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Bảng chấm điểm 3 phương án Outline (Thang 100)

| Hạng | Phương án | Persona (40đ) | Khớp `dat_khi` (30đ) | Bằng chứng (20đ) | Chống Slop (10đ) | **Tổng (/100)** | Kết luận |
|---|---|---:|---:|---:|---:|---:|---|
| 1 | **B** — Phương án B — Báo cáo Chẩn đoán Khoảng trống Năng lực AI & Lộ trình Đào tạo Thực chiến 90 ngày (Chuẩn McKinsey/Sakedemy) | 34.48 | 28.5 | 19.0 | 9.5 | **91.48** | ★ **CHỐT**: Đi thẳng vào nghịch lý thực chiến, trả lời trực diện câu cãi của cả 3 Persona Neo, có bằng chứng định lượng và hoàn toàn thoát khỏi khuôn giáo điều. |
| 2 | **A** — Phương án A — Báo cáo tổng quan xu hướng AI toàn cầu & Việt Nam | 16.76 | 19.5 | 16.5 | 5.5 | **58.26** | Loại: Nặng lý thuyết vĩ mô/học thuật, mở bài dễ làm P1 và P2 bỏ đọc sớm. |
| 3 | **C** — Phương án C — Hồ sơ giới thiệu danh mục khoá học & giảng viên | 14.56 | 18.0 | 14.0 | 4.5 | **51.06** | Loại: Cấu trúc liệt kê bề nổi kiểu cẩm nang đại trà, dễ rơi vào giọng văn AI hướng dẫn (how-to slop). |

## 2. Quyết định chốt hướng: ★ Phương án B (91.48/100 điểm)
- **Tên phương án**: Phương án B — Báo cáo Chẩn đoán Khoảng trống Năng lực AI & Lộ trình Đào tạo Thực chiến 90 ngày (Chuẩn McKinsey/Sakedemy)
- **Góc nhìn**: Giải quyết trực diện bài toán ROI của CEO, bài toán thiết kế theo phòng ban của HRD và cổng an toàn dữ liệu của IT Lead
- **Giọng điệu**: Tư vấn chiến lược sắc gọn (Action Title mỗi trang một kết luận + bằng chứng định lượng BC01..BC15 + cổng chất lượng 17 luật)
- **Khung triển khai gửi sang Bước 6**:
  - Trang 1 (Executive Summary): 78% doanh nghiệp đã dùng thử AI nhưng 86% mắc kẹt ở 'năng suất bề nổi' vì thiếu quy trình và cổng nghiệm thu [BC01, BC02]
  - Trang 2 (Giải phẫu Chi phí ẩn): Mỗi quản lý cấp trung đang mất 4,5 giờ/tuần dọn 'rác AI' do đào tạo mẹo câu lệnh rời rạc thay vì quy trình đầu ra [BC03, BC06]
  - Trang 3 (Khung Năng lực 3 Mức × 4 Khối phòng ban): Thiết kế may đo cho Kinh doanh, Marketing, Vận hành và Nhân sự - Tài chính [BC04, BC07]
  - Trang 4 (Cổng Kiểm soát Chất lượng & Bảo mật 2 lớp): Quy chế phân loại dữ liệu nhạy cảm và bộ lọc 17 luật chống ảo giác số liệu [BC05, BC09]
  - Trang 5 (Lộ trình Pilot 90 Ngày & Bảng đo ROI): Triển khai nhóm hạt nhân 20 người, nghiệm thu bằng sản phẩm thật và đo giờ công tiết kiệm thực tế [BC04, BC10]

## 3. Ràng buộc bắt buộc giao cho Bước 6 (Rút từ phản ứng Persona & Luật chống Slop)
- [x] Phải giải quyết câu phản biện của P1 (CEO / Thành viên HĐQT duyệt ngân sách đào tạo & chuyển đổi AI): [P1 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung.
- [x] Phải giải quyết câu phản biện của P2 (Giám đốc Nhân sự (HRD) / Trưởng bộ phận Đào tạo (L&D)): [P2 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung.
- [x] Phải giải quyết câu phản biện của P3 (Trưởng phòng CNTT / Chuyển đổi số (IT/DX Lead - Người gác cổng bảo mật & hạ tầng)): [P3 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung.
- [x] Tuyệt đối không dùng cấu trúc so sánh hai vế 'Không còn là X mà là Y' hoặc 'Càng X càng Y' (Luật Vân Anh VA-01, VA-02).
- [x] Mọi số liệu trích dẫn phải giữ nguyên mã nguồn [Nxx]/[BCxx], mọi giai thoại giả định phải gắn nhãn [GIẢ LẬP].
