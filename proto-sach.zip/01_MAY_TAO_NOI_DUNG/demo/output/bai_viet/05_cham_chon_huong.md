# BƯỚC 05: TỰ CHẤM & CHỐT HƯỚNG OUTLINE (`bai_viet`)

> **Truy vết Module**: `BM1_05_cham_chon_huong` (**Làm mới hoàn toàn** theo Đề 01 Bản 3)
> **Cờ duyệt (`duyet_outline`)**: `may` → **Trạng thái**: `DA_CHOT_TU_DONG_MAY`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Bảng chấm điểm 3 phương án Outline (Thang 100)

| Hạng | Phương án | Persona (40đ) | Khớp `dat_khi` (30đ) | Bằng chứng (20đ) | Chống Slop (10đ) | **Tổng (/100)** | Kết luận |
|---|---|---:|---:|---:|---:|---:|---|
| 1 | **B** — Phương án B — Giải phẫu nghịch lý vận hành & Chi phí sửa rác AI (Thực chiến doanh nghiệp) | 34.48 | 28.5 | 19.0 | 9.5 | **91.48** | ★ **CHỐT**: Đi thẳng vào nghịch lý thực chiến, trả lời trực diện câu cãi của cả 3 Persona Neo, có bằng chứng định lượng và hoàn toàn thoát khỏi khuôn giáo điều. |
| 2 | **A** — Phương án A — Hàn lâm / Giải phẫu công nghệ | 16.76 | 19.5 | 16.5 | 5.5 | **58.26** | Loại: Nặng lý thuyết vĩ mô/học thuật, mở bài dễ làm P1 và P2 bỏ đọc sớm. |
| 3 | **C** — Phương án C — Cẩm nang 10 bước hướng dẫn kỹ năng cá nhân | 14.56 | 18.0 | 14.0 | 4.5 | **51.06** | Loại: Cấu trúc liệt kê bề nổi kiểu cẩm nang đại trà, dễ rơi vào giọng văn AI hướng dẫn (how-to slop). |

## 2. Quyết định chốt hướng: ★ Phương án B (91.48/100 điểm)
- **Tên phương án**: Phương án B — Giải phẫu nghịch lý vận hành & Chi phí sửa rác AI (Thực chiến doanh nghiệp)
- **Góc nhìn**: Đi thẳng vào nỗi đau thật giữa Sếp - Trưởng phòng - Nhân viên: Tưởng dùng AI để nhàn đi, nhưng thực tế cả công ty đang làm thêm giờ để dọn rác AI cho nhau
- **Giọng điệu**: Sắc lạnh, tỉnh táo, đi từ chuyện đời thực trong văn phòng Việt Nam đến quy tắc cầm cân nảy mực (đúng giọng Linh + kỷ luật biên tập Vân Anh)
- **Khung triển khai gửi sang Bước 6**:
  - 1. Mở bài: Căn phòng họp lúc 8 giờ tối và bản kế hoạch 15 trang sinh ra trong 30 giây nhưng mất 3 ngày để đoán xem nhân viên định nói gì
  - 2. Tầng 1 - Ảo giác tốc độ: Khi khẩu hiệu 'hỏi ChatGPT đi' biến người làm chuyên môn thành thợ sửa lỗi văn dịch
  - 3. Tầng 2 - Vì sao bài máy tự viết từ đầu không cứu được: Bài học từ bàn biên tập (chỉ lấy được ý, hỏng toàn bộ diễn đạt vì thiếu nháp gốc của người làm)
  - 4. Tầng 3 - Giữ chốt ở đâu: Máy tìm tư liệu và soi lỗi theo luật cứng; người giữ hạt giống, trải nghiệm thật và quyền gạch bỏ cuối cùng

## 3. Ràng buộc bắt buộc giao cho Bước 6 (Rút từ phản ứng Persona & Luật chống Slop)
- [x] Phải giải quyết câu phản biện của P1 (Chủ doanh nghiệp SME / Giám đốc vận hành (Độc giả mục tiêu chính)): [P1 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung.
- [x] Phải giải quyết câu phản biện của P2 (Trưởng phòng chuyên môn / Team Lead (Người trực tiếp chịu trận giữa sếp và nhân viên)): [P2 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung.
- [x] Phải giải quyết câu phản biện của P3 (Chuyên gia / Quản lý kỹ thuật hoài nghi (Độc giả khó tính hay bắt bẻ số liệu)): [P3 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung.
- [x] Tuyệt đối không dùng cấu trúc so sánh hai vế 'Không còn là X mà là Y' hoặc 'Càng X càng Y' (Luật Vân Anh VA-01, VA-02).
- [x] Mọi số liệu trích dẫn phải giữ nguyên mã nguồn [Nxx]/[BCxx], mọi giai thoại giả định phải gắn nhãn [GIẢ LẬP].
