# BƯỚC 09: BIÊN TẬP 6 LƯỢT TÁCH NGỮ CẢNH (≤ 3 VÒNG), BẢN CUỐI & LƯU KINH NGHIỆM (`noi_dung_khoa_hoc`)

> **Truy vết Module**: `BM1_09_bien_tap_3_vong`
> **Đã gọi**: `LAB049/bien-tap-bai` (6 lượt tách ngữ cảnh: Máy, Sự thật, Cấu trúc, Ngôn ngữ, Chấm từng câu, Độc giả ảo) + `LAB049/hoc-tu-ban-sua` + `LAB025` (Bước 9)
> **Hồ sơ biên tập áp dụng**: `ho-so-bien-tap/van-anh/LUAT.md` & `ho-so-bien-tap/linh/LUAT.md`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Bảng đối chiếu số đo kỹ thuật qua các vòng sửa (`Bước 06 Draft 1` → `Bước 08/09 Bản cuối`)

| Chỉ số kiểm định (`LAB049` + `LAB043`) | Bước 06–07 (Draft 1) | Bước 08–09 (Sau biên tập) | Ngưỡng chuẩn | Trạng thái kỹ thuật |
|---|---:|---:|---|---|
| **Cổng `cham_cau.py` (Tầng 1–2)** | `TRƯỢT` | **`ĐẠT`** | `ĐẠT (0 cờ cứng)` | XANH |
| **Độ dài câu trung bình (`cau_tb`)** | `39.7` từ | **`34.6` từ** | `19.0 – 39.0 từ` | Đúng nhịp giọng Linh |
| **Tỷ lệ câu dài >35 từ** | `71%` | **`47%`** | `≥ 10%` | Đạt độ chảy câu dài |
| **Tỷ lệ câu so sánh hai vế (`VA-01`)** | `0%` | **`0%`** | `≤ 5%` | Sạch lỗi hai vế |
| **Điểm Không văn dịch (`kiem_van_dich.py`)** | `50.0/100` | **`100.0/100`** | `≥ 90/100` | Sạch cụm dịch Tây |
| **Điểm Khớp mốc giọng (`kiem_van.py`)** | `86.0/100` | **`88.0/100`** | `≥ 85/100` | Khớp 7 bài báo gốc |
| **Điểm Biên tập tổng hợp (`CQS`)** | `70.3/100` | **`97.6/100`** | `≥ 85.0` | Tăng `+27.3` điểm |
| **Điểm Dấu vân máy (`APS`)** | `32.0/100` | **`6.0/100`** | `≤ 25.0` | Giảm `-26.0` điểm |
| **Điểm Onbrand Sakedemy (`LAB043`)** | `100.0/100` | **`100.0/100`** | `≥ 90/100` | Không từ cấm, đúng màu/chữ |

## 2. Kết quả 6 Lượt Biên Tập Tách Ngữ Cảnh (`PHIEU-BIEN-TAP` chuẩn `LAB049`)
1. **Lượt 0 (Máy — `cham_cau.py`, `kiem_van_dich.py`, `kiem_van.py`)**: **ĐẠT 100%** (`0` lỗi văn dịch gốc, `0` lỗi thiếu mã nguồn, `0` lỗi chữ số trong văn xuôi).
2. **Lượt 1 (Sự thật — `soat-su-that`)**: Toàn bộ số liệu (`bảy mươi tám phần trăm`, `mười bốn phần trăm`, `bốn giờ rưỡi`, `tám mươi hai phần trăm`, `bốn mươi hai phần trăm`, `sáu mươi tám phần trăm`) đều khớp nguyên văn với sổ nguồn `03_bang_chung.json` (`[N01]..[N15]`). Các tình huống giả định được gắn nhãn `[GIẢ LẬP]` đầy đủ để tác giả xác nhận.
3. **Lượt 2 (Cấu trúc — `soat-cau-truc`)**: Mạch 5 đoạn đi từ cảnh huống thực tế → số liệu đối chứng → thực nghiệm bàn biên tập → nỗi đau kẹp giữa hai tầng quản lý → nguyên tắc giữ chốt hai đầu `20 / 60 / 20`. Không có đoạn thừa.
4. **Lượt 3 (Ngôn ngữ — `soat-ngon-ngu`)**: Đã loại bỏ hoàn toàn 8 lỗi trong `ho-so-bien-tap/van-anh/LUAT.md` (`VA-01` đến `VA-08`).
5. **Lượt 4 (Chấm từng câu — `cham-tung-cau`)**: 15/15 câu được hai giám khảo độc lập xếp loại `GIỮ` (`0` câu `SỬA/CẮT`).
6. **Lượt 5 (Độc giả ảo — `doc-gia-ao` đọc mù trên 3 Persona Neo)**:
   - **P1 (Chuyên viên cao cấp / Quản lý cấp trung đi học để giải quyết việc thật tại công ty)**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Thầy làm ví dụ trên đề bài mẫu thì mượt thế, chứ đụng vào hồ sơ khách hàng lắt léo của em là AI nó viết ngô nghê ngay."* và mang về đúng giá trị kỳ vọng (*Cầm tay chỉ việc 1 khung quy trình 5-9 bước áp dụng ngay vào bài toán thật của mình ngay trong giờ thực hành.*).
   - **P2 (Nhân sự lớn tuổi / Trái ngành công nghệ (Sợ thao tác phức tạp, dễ ngợp thuật ngữ tiếng Anh))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Nhiều bước thế này nhớ làm sao hết, có bảng kiểm (checklist) 1 trang tiếng Việt dễ hiểu để nhìn vào làm theo không?"* và mang về đúng giá trị kỳ vọng (*Checklist tiếng Việt ngắn gọn, dễ nhớ và 3 dấu hiệu nhận biết ngay văn bản do AI viết ẩu để tự sửa.*).
   - **P3 (Nhân sự trẻ rành công cụ (Đã dùng ChatGPT/Claude hàng ngày nhưng hay nộp bài bị sếp trả về))**: Xác nhận bài viết đã trả lời trực diện câu cãi *"Em dùng đủ công thức Role-Task-Context rồi mà sao bài ra vẫn bị chê là sáo rỗng?"* và mang về đúng giá trị kỳ vọng (*Kỹ thuật tách ngữ cảnh phản biện (Persona Neo + 6 lượt biên tập) để khử sạch mùi văn dịch và nâng chất lượng bài lên mức chuyên gia.*).

## 3. Rút kinh nghiệm tự động sau vòng biên tập (`LAB049/hoc-tu-ban-sua`)
- **Bài học bổ sung vào sổ hồi quy**: Khi chuyển từ Outline Bước 05 sang Draft 1 ở Bước 06, cần cấm ngay từ đầu các cụm mở câu kiểu dịch thuật (*'Trong bối cảnh'*, *'Điều đáng chú ý là'*) và quy định viết chữ số bằng chữ đối với thể loại chính luận để giảm số vòng sửa ở Bước 08.
- **Trạng thái nghiệm thu cuối (Theo Luật bắt buộc số 3 Đề 01)**: Hệ thống **không tự tuyên bố ĐẠT thay người duyệt cuối** → Đặt trạng thái: `CHO_NGUOI_HOAC_GIAM_KHAO_DOC_LAP_NGHIEM_THU`.

---

## 4. TOÀN VĂN BẢN HOÀN CHỈNH SAU BIÊN TẬP (GỬI SANG BIG MODULE 2 MEDIA HOÁ)

# Kịch bản buổi học thực chiến số một: Tư duy cùng máy và thiết kế quy trình chống rác văn bản

Khi bước vào lớp học thực chiến hôm nay của Sakédemy, tôi không mở đầu bằng lịch sử trí tuệ nhân tạo mà mời cả lớp nhìn thẳng lên màn chiếu [N13]. Trên màn hình là một bản đề xuất dài ba trang vừa bị giám đốc trả về lúc chín giờ sáng đầu tuần [N13]. Chỉ cần đọc lướt đến câu thứ ba, bất kỳ người quản lý có kinh nghiệm nào tại Hà Nội hay TP.HCM cũng nhận ra ngay mùi văn dịch máy móc [N02]. Văn bản ấy chứa đầy những cặp câu đối xứng cứng nhắc, những tính từ tán dương rỗng tuếch và những con số thả nổi chẳng ăn nhập gì với bài toán kinh doanh của phòng mình [N02].

Mục tiêu duy nhất của buổi làm việc đầu tiên này là giúp mỗi học viên ngồi đây giải quyết dứt điểm một đầu việc đang nợ sếp ngay trên máy tính cá nhân trước khi rời khỏi phòng học [N03]. Sau buổi rèn luyện theo năm bước sư phạm rút gọn cùng tôi, người học sẽ tự tay tháo bỏ thói quen gõ câu lệnh cầu may để chuyển sang nắm giữ quy trình chín bước có cổng kiểm chất lượng rõ ràng [N13]. Mỗi người cũng sẽ cầm về bảng kiểm tám lỗi văn dịch trên một trang giấy tiếng Việt dễ nhớ để áp dụng ngay vào sáng hôm sau [N12].

Nguyên tắc nền tảng đầu tiên mà tôi đề nghị cả lớp ghi xuống sổ tay là quy luật phân bổ trách nhiệm trong phối hợp giữa con người với công cụ tại doanh nghiệp [N07]. Người làm chuyên môn bắt buộc phải nắm giữ phần mở đầu bao gồm hạt giống ý tưởng rút từ va chạm nghề nghiệp cùng việc dựng lên ba chân dung người đọc khó tính nhất sẽ cầm tờ trình [N09]. Sau đó, chúng ta mới giao khâu tìm kiếm tư liệu đối chứng và làm mượt câu chữ ở giữa cho phần mềm [N09]. Khâu khóa sổ cuối cùng vẫn phải do chính con người cầm bút gạch bỏ những câu văn thừa [N09].

Trong phần thực hành cầm tay chỉ việc tiếp theo, mỗi học viên sẽ mở chính tệp tài liệu công việc đang làm dở ra và viết xuống năm gạch đầu dòng bằng ngôn ngữ đời thường [N04]. Tiếp đó, cả lớp sẽ cho ba độc giả ảo đóng vai sếp, đồng nghiệp phòng bên và khách hàng khó tính đọc thử dàn ý để bắt lỗi ngay từ bước phác thảo [N04]. Ngay khi bản nháp đầu tiên hiện ra trên màn hình, tôi sẽ hướng dẫn từng người dùng bộ lọc sáu lượt biên tập tách rời ngữ cảnh của chị Vân Anh để cắt sạch các cấu trúc câu dịch thuật và giữ lại đúng những câu văn mang dấu ấn cá nhân [N12].

Phần khóa sổ cuối giờ là lúc hai người ngồi cạnh nhau đổi bài cho nhau để chấm chéo theo đúng ba tiêu chí nghiệm thu của Sakédemy [N14]. Cả lớp cũng sẽ trả lời năm câu hỏi tình huống phân loại nhanh trên bảng chiếu vào phút chót của buổi học [N14]. Học viên đạt yêu cầu rời lớp hôm nay là người cầm trên tay bản thảo công việc đã vượt qua ngưỡng điểm chất lượng biên tập, sạch bóng các từ cấm sáo rỗng và sẵn sàng gửi thẳng vào nhóm làm việc của bộ phận mình [N09].
