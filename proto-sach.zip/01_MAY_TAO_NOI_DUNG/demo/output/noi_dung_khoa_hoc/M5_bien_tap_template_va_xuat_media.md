# BƯỚC M5: BIÊN TẬP TEMPLATE 3 VÒNG (PDCA), QUẢN LÝ PHIÊN BẢN & XUẤT MEDIA (`noi_dung_khoa_hoc`)

> **Truy vết Big Module 2**: `BM2_M1_chu_trinh_template` (Bước 5/5) + `BM2_M2_media_hoa`
> **Đã gọi**: `AGY image-generator + AGY search_web + LAB027 (linhx-deck: dung-deck, hinh-anh) + LAB017 (linhx-course: lesson-slides) + LAB032 (anh-sang-slide) + LAB043 (thiet_ke.py, onbrand.py) + LAB028 (hinh.py) + LAB066 + LAB042`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Phiên bản Template khoá sổ**: `v1.2-chot` · **Trạng thái mẫu**: chạy không mẫu

## 1. Nhật ký 3 vòng biên tập Template & Media thực chất (PDCA theo chuẩn `LAB043` v2)

| Phiên bản | Phát hiện khi kiểm bằng mắt, `onbrand.py cham` & `check_onbrand_sakedemy` | Hành động sửa trên file khuôn & ấn phẩm | Điểm Onbrand (/100) |
|---|---|---|---:|
| `v1.0` | Khuôn gốc `slide-169.html` của LAB043 đặt chữ trắng `var(--trang)` lên ô số `.so` nền `#6EB264` (tương phản 2,56:1, vi phạm LUAT-ONBRAND.md dòng 8); nhãn phụ trên nền trắng dùng `#1CA571` (3,15:1). | Vá `.so` sang chữ Xanh Rêu Đậm `#02403B` (tương phản 4,57:1) trong `khuon_v1_2_slide_169.html`; đổi nhãn xanh nhỏ trên nền trắng sang `#118056` (4,95:1). | **91.0** |
| `v1.1` | Ghép ảnh thực tế AGY (`agy_anh_goc_sakedemy.jpg`) vào khung hình lá cần sinh mặt nạ `.mask.png` tô `#FF00FF` để `onbrand.py cham` không chấm nhầm sắc độ ảnh chụp vào đồ hoạ phẳng; bổ sung 2 biểu đồ SVG `LAB028/hinh.py`. | Chạy `thiet_ke.py dung` sinh cặp `.png` + `.mask.png` và `LAB028/hinh.py` sinh `H01.svg`, `H02.svg` với font `Be Vietnam Pro`. | **96.5** |
| `v1.2-chot` | Chạy `onbrand.py cham` + `gop` đạt 99.0/100 (ĐẠT CHUẨN, độ phủ màu 100.0%); điểm ảnh AGY theo LAB066 đạt 8.45/10. | Khoá bản `v1.2-chot`, nhúng toàn bộ ảnh AGY + Banner PNG + Biểu đồ H01/H02 SVG vào HTML và in PDF màu bằng Headless Edge. | **100** |

## 2. Kết quả kiểm định Onbrand Sakedemy cuối cùng (`check_onbrand_sakedemy` + `onbrand.py`)
- **Tổng điểm Onbrand nội quy**: **100/100** (`ĐẠT: True`)
- **Điểm đo CIEDE2000 & Rubric (`onbrand.py`)**: **99.0/100** (`ĐẠT CHUẨN`, độ phủ màu thương hiệu `100.0%`)
- **Chi tiết điểm 5 trụ cột**: `{"mau": 30, "chu": 20, "logo": 25, "hinh_bo_cuc": 15, "noi_dung": 10}`
- **Số lỗi vi phạm còn tồn đọng**: `0`

## 3. Danh mục File Media thật đã đóng gói trong Run này (`15 files`)
- `tham_chieu_agy_json`: `media/tham_chieu_agy.json`
- `agy_anh_goc_jpg`: `media/agy_anh_goc_sakedemy.jpg`
- `agy_anh_prompt_json`: `media/agy_anh_goc_sakedemy.prompt.json`
- `character_anchor_lab066`: `media/character_anchor_lab066.json`
- `video_khung_lab042`: `media/video_khung_muc1_lab042.json`
- `exhibit_h01_svg_lab028`: `media/04-hinh/H01.svg`
- `exhibit_h02_svg_lab028`: `media/04-hinh/H02.svg`
- `sakedemy_banner_png`: `media/sakedemy_banner_1920x600.png`
- `sakedemy_visual_png`: `media/sakedemy_slide_1920x1080.png`
- `onbrand_ket_qua_json`: `media/onbrand_ket_qua_visual.json`
- `onbrand_bao_cao_html`: `media/onbrand_bao_cao.html`
- `slidev_slides_md`: `media/slides.md`
- `deck_json_lab027`: `media/10-deck.json`
- `slide_html_16x9`: `media/slide_deck_sakedemy_16x9.html`
- `slide_pdf_16x9`: `media/slide_deck_sakedemy_16x9.pdf`
