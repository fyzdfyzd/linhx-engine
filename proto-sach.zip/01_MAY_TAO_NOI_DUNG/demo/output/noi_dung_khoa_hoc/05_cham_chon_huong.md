# BƯỚC 05: TỰ CHẤM & CHỐT HƯỚNG OUTLINE (`noi_dung_khoa_hoc`)

> **Truy vết Module**: `BM1_05_cham_chon_huong` (**Làm mới hoàn toàn** theo Đề 01 Bản 3)
> **Cờ duyệt (`duyet_outline`)**: `may` → **Trạng thái**: `DA_CHOT_TU_DONG_MAY`
> **Nhận diện tạm**: Sakedemy (LAB043) · **Trạng thái mẫu**: chạy không mẫu

## 1. Bảng chấm điểm 3 phương án Outline (Thang 100)

| Hạng | Phương án | Persona (40đ) | Khớp `dat_khi` (30đ) | Bằng chứng (20đ) | Chống Slop (10đ) | **Tổng (/100)** | Kết luận |
|---|---|---:|---:|---:|---:|---:|---|
| 1 | **B** — Phương án B — Buổi học Thực chiến Gagné 5 Bước: Từ 'Hạt giống Ý tưởng' đến 'Bản nháp Sạch Mùi AI' ngay tại lớp | 34.48 | 28.5 | 19.0 | 9.5 | **91.48** | ★ **CHỐT**: Đi thẳng vào nghịch lý thực chiến, trả lời trực diện câu cãi của cả 3 Persona Neo, có bằng chứng định lượng và hoàn toàn thoát khỏi khuôn giáo điều. |
| 2 | **A** — Phương án A — Bài giảng Lý thuyết Nền tảng về AI & Prompt Engineering | 16.76 | 19.5 | 16.5 | 5.5 | **58.26** | Loại: Nặng lý thuyết vĩ mô/học thuật, mở bài dễ làm P1 và P2 bỏ đọc sớm. |
| 3 | **C** — Phương án C — Workshop biểu diễn 15 công cụ AI tự động hoá đa phương tiện | 14.56 | 18.0 | 14.0 | 4.5 | **51.06** | Loại: Cấu trúc liệt kê bề nổi kiểu cẩm nang đại trà, dễ rơi vào giọng văn AI hướng dẫn (how-to slop). |

## 2. Quyết định chốt hướng: ★ Phương án B (91.48/100 điểm)
- **Tên phương án**: Phương án B — Buổi học Thực chiến Gagné 5 Bước: Từ 'Hạt giống Ý tưởng' đến 'Bản nháp Sạch Mùi AI' ngay tại lớp
- **Góc nhìn**: Học viên mang đúng 1 việc đang nợ sếp vào lớp; đi qua 5 sự kiện Gagné rút gọn, tự tay dựng Persona Neo, viết nháp gạch đầu dòng và dùng bảng kiểm 8 lỗi Vân Anh để khử sạch mùi văn máy
- **Giọng điệu**: Giảng viên Linh: Thực chiến, sắc sảo, không dùng thuật ngữ Tây khi có từ Việt tương đương, cầm tay chỉ việc trên bài thật
- **Khung triển khai gửi sang Bước 6**:
  - Slide 01-03 [Gagné 1 - Chạm nỗi đau]: Giải phẫu trực tiếp 1 đoạn văn AI 300 chữ vừa bị sếp trả về lúc 9h sáng — Vì sao đọc 3 câu đã biết máy viết?
  - Slide 04-05 [Gagné 2 - Cam kết đầu ra]: Sau 90 phút hôm nay, mỗi học viên cầm về 1 sản phẩm thật của phòng mình và 1 Bảng kiểm 1 trang tiếng Việt
  - Slide 06-09 [Gagné 3 - Nguyên lý Cốt lõi]: Luật 80/20 (Người giữ 20% Hạt giống + 20% Chốt cuối) & Cách dựng 3 Độc giả ảo hay cãi để thử dàn ý trước khi viết
  - Slide 10-14 [Gagné 4 - Cầm tay chỉ việc]: Thực hành tách bước trên bài thật của học viên + Quét sạch 8 lỗi văn dịch (so sánh 2 vế, láy câu, thả số liệu, chủ thể mơ hồ)
  - Slide 15-18 [Gagné 5 - Nghiệm thu tại lớp & Quiz]: Chấm chéo sản phẩm theo 3 tiêu chí Đạt/Sửa + 5 câu hỏi tình huống phân loại nhanh

## 3. Ràng buộc bắt buộc giao cho Bước 6 (Rút từ phản ứng Persona & Luật chống Slop)
- [x] Phải giải quyết câu phản biện của P1 (Chuyên viên cao cấp / Quản lý cấp trung đi học để giải quyết việc thật tại công ty): [P1 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung.
- [x] Phải giải quyết câu phản biện của P2 (Nhân sự lớn tuổi / Trái ngành công nghệ (Sợ thao tác phức tạp, dễ ngợp thuật ngữ tiếng Anh)): [P2 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung.
- [x] Phải giải quyết câu phản biện của P3 (Nhân sự trẻ rành công cụ (Đã dùng ChatGPT/Claude hàng ngày nhưng hay nộp bài bị sếp trả về)): [P3 hỏi xoáy để làm dày phương án B] Đã gọi đúng bệnh rồi, nhưng ở phần giải pháp phải ghi rõ ai làm bước nào và mất bao nhiêu phút, đừng nói chung chung.
- [x] Tuyệt đối không dùng cấu trúc so sánh hai vế 'Không còn là X mà là Y' hoặc 'Càng X càng Y' (Luật Vân Anh VA-01, VA-02).
- [x] Mọi số liệu trích dẫn phải giữ nguyên mã nguồn [Nxx]/[BCxx], mọi giai thoại giả định phải gắn nhãn [GIẢ LẬP].
